import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "10mb" }));

  // AI Chat Support API Endpoint
  app.post("/api/ai-chat", async (req, res) => {
    try {
      const { prompt } = req.body;
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        const textPrompt = prompt.toLowerCase();
        let fallbackReply = "Welcome to FF Esports AI Support! How can I help you today?";
        if (textPrompt.includes("room") || textPrompt.includes("id") || textPrompt.includes("password")) {
          fallbackReply = "🔑 Room ID & Password are published 15 minutes before match start in 'My Matches' tab. You will also receive SMS/WhatsApp alerts!";
        } else if (textPrompt.includes("withdraw") || textPrompt.includes("upi") || textPrompt.includes("code") || textPrompt.includes("redeem")) {
          fallbackReply = "💸 Withdraw money or redeem Google Play Codes starting from ₹10 in the Wallet tab. Requests are processed within 15-30 minutes!";
        } else if (textPrompt.includes("proof") || textPrompt.includes("screenshot")) {
          fallbackReply = "📸 Upload clear end-game match scoreboard screenshots in 'Proofs' tab right after the match so admins can credit your kill rewards!";
        } else if (textPrompt.includes("deposit") || textPrompt.includes("add money")) {
          fallbackReply = "💳 Go to Wallet tab -> Deposit, scan the official Admin UPI QR code, and submit payment proof for instant verification!";
        } else if (textPrompt.includes("rule") || textPrompt.includes("hack") || textPrompt.includes("ban")) {
          fallbackReply = "⚠️ Hacks, third-party apps, or teaming up are strictly forbidden and will lead to an immediate ban!";
        }
        return res.json({ reply: fallbackReply });
      }

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });

      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: prompt,
        config: {
          systemInstruction: `You are FF BOT, the official AI Support Assistant for "FF TOURNAMENT ESPORTS".
Help players with Free Fire custom room IDs & passwords, registration, deposits, withdrawals (UPI and Google Play Codes), screenshot proof uploads, squad rules, VIP passes, and fair play policies.
Be encouraging, helpful, gamer-friendly, and concise with clean bullet points or emojis.`,
        },
      });

      return res.json({ reply: response.text || "Thank you for contacting FF Esports AI Support!" });
    } catch (error: any) {
      console.error("AI Chat Error:", error);
      return res.json({
        reply: "🎮 FF Esports AI Support is active. For direct human support, check the Support tab to contact Admin on WhatsApp!",
      });
    }
  });

  // Vite development middleware or static production serving
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
