export type ActiveTab =
  | 'dashboard'
  | 'tournaments'
  | 'matches'
  | 'registrations'
  | 'payments'
  | 'wallet'
  | 'deposits'
  | 'withdrawals'
  | 'transactions'
  | 'rooms'
  | 'leaderboard'
  | 'results'
  | 'users'
  | 'coupons'
  | 'referrals'
  | 'banners'
  | 'notifications'
  | 'support'
  | 'homepage'
  | 'settings'
  | 'reports'
  | 'logs'
  | 'admins';

export type User = AppUser;
export type AppNotification = NotificationItem;

export interface Banner {
  id: string;
  title: string;
  imageUrl: string;
  linkUrl?: string;
  isActive: boolean;
  order?: number;
  createdAt?: number;
}

export type AdminRole = 'SUPER_ADMIN' | 'TOURNAMENT_ADMIN' | 'PAYMENT_ADMIN' | 'RESULT_ADMIN' | 'SUPPORT_ADMIN' | 'PLAYER';


export interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: AdminRole;
  isActive: boolean;
  createdAt: number;
  lastLoginAt?: number;
  createdBy?: string;
}

export type TournamentType = 'Solo' | 'Duo' | 'Squad';
export type TournamentStatus = 'Draft' | 'Registration Open' | 'Registration Closed' | 'Live' | 'Completed' | 'Cancelled';
export type GameMap = 'Bermuda' | 'Purgatory' | 'Kalahari' | 'Alpine' | 'NexTerra' | 'Random';
export type GameMode = 'Battle Royale' | 'Clash Squad' | 'Custom Classic' | 'Hardcore';

export interface Tournament {
  id: string;
  name: string;
  description: string;
  bannerUrl?: string;
  type: TournamentType;
  entryFee: number;
  prizePool: number;
  firstPrize: number;
  secondPrize: number;
  thirdPrize: number;
  perKillPrize: number;
  maxTeams: number;
  currentRegistrations: number;
  date: string;
  time: string;
  registrationClosingTime: string;
  map: GameMap;
  mode: GameMode;
  matchCount: number;
  rules: string;
  status: TournamentStatus;
  isFeatured?: boolean;
  liveStreamUrl?: string;
  discordLink?: string;
  telegramLink?: string;
  createdAt: number;
  updatedAt: number;
  createdBy?: string;
}

export type MatchStatus = 'Scheduled' | 'Live' | 'Completed' | 'Cancelled';

export interface Match {
  id: string;
  tournamentId: string;
  tournamentName?: string;
  matchNumber: number;
  matchDate: string;
  matchTime: string;
  map: GameMap;
  mode: GameMode;
  roomId?: string;
  roomPassword?: string;
  isRoomPublished: boolean;
  liveStreamUrl?: string;
  status: MatchStatus;
  notes?: string;
  createdAt: number;
  updatedAt: number;
}

export type RegistrationStatus = 'Pending' | 'Approved' | 'Rejected';
export type PaymentStatus = 'Pending' | 'Approved' | 'Rejected' | 'Wallet';

export interface PlayerInfo {
  name: string;
  ffUid: string;
  ign: string;
  phone?: string;
}

export interface Registration {
  id: string;
  tournamentId: string;
  tournamentName: string;
  teamName: string;
  captainName: string;
  captainEmail: string;
  captainPhone: string;
  captainFfUid: string;
  captainIgn: string;
  userId?: string;
  userEmail?: string;
  players: PlayerInfo[];
  type: TournamentType;
  entryFee: number;
  paidAmount: number;
  couponCode?: string;
  discountAmount?: number;
  paymentMethod: 'UPI' | 'QR' | 'WALLET' | 'MANUAL';
  paymentId?: string;
  utrNumber?: string;
  paymentScreenshotUrl?: string;
  paymentStatus: PaymentStatus;
  status: RegistrationStatus;
  rejectionReason?: string;
  registeredAt: number;
  createdAt?: number;
  updatedAt?: number;
  slotNumber?: number;
  approvedAt?: number;
  approvedBy?: string;
}

export interface PaymentSubmission {
  id: string;
  userId: string;
  userEmail: string;
  userName?: string;
  tournamentId?: string;
  tournamentName?: string;
  registrationId?: string;
  amount: number;
  utrNumber: string;
  screenshotUrl?: string;
  paymentMethod: 'UPI' | 'QR' | 'BANK';
  status: 'Pending' | 'Approved' | 'Rejected';
  adminNote?: string;
  createdAt: number;
  processedAt?: number;
  processedBy?: string;
}

export interface UserWallet {
  userId: string;
  userEmail: string;
  userName: string;
  phone?: string;
  availableBalance: number;
  pendingBalance: number;
  totalDeposited: number;
  totalWinnings: number;
  totalWithdrawn: number;
  updatedAt: number;
}

export type TransactionType =
  | 'Deposit'
  | 'Tournament Entry'
  | 'Winnings'
  | 'Refund'
  | 'Withdrawal'
  | 'Admin Adjustment';

export interface WalletTransaction {
  id: string;
  userId: string;
  userEmail?: string;
  amount: number;
  type: TransactionType;
  previousBalance: number;
  newBalance: number;
  status: 'Completed' | 'Pending' | 'Failed' | 'Reversed';
  description: string;
  tournamentId?: string;
  tournamentName?: string;
  referenceId?: string;
  adminId?: string;
  adminEmail?: string;
  timestamp: number;
}

export type WithdrawalStatus = 'Pending' | 'Processing' | 'Approved' | 'Rejected' | 'Paid';

export interface WithdrawalRequest {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  phone: string;
  requestedAmount: number;
  feeAmount: number;
  netAmount: number;
  payoutMethod: 'UPI' | 'BANK' | 'PAYTM' | 'GPAY' | 'PHONEPE' | 'REDEEM_CODE';
  payoutDetails: {
    upiId?: string;
    accountNumber?: string;
    ifscCode?: string;
    bankName?: string;
    holderName?: string;
    mobileNumber?: string;
    redeemCodeAmount?: number;
  };
  status: WithdrawalStatus;
  adminNote?: string;
  transactionRef?: string;
  createdAt: number;
  updatedAt: number;
  processedBy?: string;
}

export interface DepositRequest {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  amount: number;
  utrNumber: string;
  screenshotUrl?: string;
  upiUsed?: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  adminNote?: string;
  createdAt: number;
  processedAt?: number;
  processedBy?: string;
}

export interface LeaderboardEntry {
  id: string;
  tournamentId: string;
  matchId?: string;
  matchNumber?: number;
  rank: number;
  teamName: string;
  playerNames?: string[];
  captainFfUid?: string;
  kills: number;
  killPoints: number;
  placementPoints: number;
  totalPoints: number;
  prizeAmount: number;
  isPublished: boolean;
  updatedAt: number;
}

export interface TournamentResult {
  id: string;
  tournamentId: string;
  tournamentName: string;
  rank: number;
  teamName: string;
  captainName: string;
  captainEmail: string;
  captainFfUid: string;
  players: string[];
  totalKills: number;
  totalPoints: number;
  prizeMoney: number;
  isPrizeCredited: boolean;
  creditedAt?: number;
  creditedBy?: string;
  isPublished: boolean;
  updatedAt: number;
}

export interface AppUser {
  id: string;
  email: string;
  name: string;
  phone?: string;
  ffUid?: string;
  ign?: string;
  status?: 'Active' | 'Banned';
  isActive: boolean;
  walletBalance: number;
  totalTournamentsJoined: number;
  totalWinnings: number;
  totalWins?: number;
  totalKills?: number;
  kdRatio?: number;
  winRate?: number;
  rankTier?: 'Bronze' | 'Silver' | 'Gold' | 'Platinum' | 'Diamond' | 'Heroic' | 'Grandmaster';
  badgeIcon?: string;
  isVip?: boolean;
  vipExpiryDate?: number;
  vipPlan?: 'WEEKLY' | 'MONTHLY';
  referralCode?: string;
  referredBy?: string;
  totalReferrals?: number;
  totalReferralEarnings?: number;
  createdAt: number;
  lastLoginAt?: number;
}

export interface ReferralRecord {
  id: string;
  referrerUserId: string;
  referredUserId: string;
  referredUserEmail: string;
  referredUserName: string;
  bonusAmount: number;
  milestoneBonusAwarded?: number;
  timestamp: number;
}

export interface MatchProof {
  id: string;
  tournamentId: string;
  tournamentName: string;
  matchId?: string;
  matchNumber?: number;
  userId: string;
  userEmail: string;
  userName: string;
  teamName: string;
  claimedKills: number;
  claimedRank: number;
  screenshotUrl: string;
  status: 'Pending' | 'Verified' | 'Rejected';
  adminNotes?: string;
  submittedAt: number;
  verifiedAt?: number;
  verifiedBy?: string;
}

export interface SquadMember {
  name: string;
  ign: string;
  ffUid: string;
  role?: 'Captain' | 'Assaulter' | 'Sniper' | 'Flanker' | 'Support';
  phone?: string;
}

export interface PlayerSquad {
  id: string;
  ownerUserId: string;
  teamName: string;
  teamTag?: string;
  logoUrl?: string;
  squadCode: string;
  members: SquadMember[];
  createdAt: number;
  updatedAt: number;
}

export interface VipSubscription {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  planType: 'WEEKLY' | 'MONTHLY';
  pricePaid: number;
  discountPercent: number;
  startDate: number;
  expiryDate: number;
  isActive: boolean;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'PERCENTAGE' | 'FLAT';
  discountAmount: number;
  discountValue?: number;
  minEntryFee: number;
  maxDiscount?: number;
  expiryDate: string;
  maxUses: number;
  usedCount: number;
  tournamentId?: string;
  tournamentName?: string;
  status: 'Active' | 'Inactive' | 'Expired';
  isActive?: boolean;
  createdAt: number;
}

export interface ReferralSettings {
  isEnabled: boolean;
  rewardPerReferral: number;
  minDepositRequired: number;
  rules: string;
  updatedAt: number;
  updatedBy?: string;
}

export interface ReferralRecord {
  id: string;
  referrerUserId: string;
  referrerEmail: string;
  referredUserId: string;
  referredEmail: string;
  rewardAmount: number;
  isRewardCredited: boolean;
  createdAt: number;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'Registration' | 'Payment' | 'Tournament' | 'Room' | 'Result' | 'Wallet' | 'Announcement' | string;
  target?: 'ALL' | 'SPECIFIC' | 'TOURNAMENT_PARTICIPANTS' | string;
  targetAudience?: 'ALL' | 'SPECIFIC' | 'TOURNAMENT_PARTICIPANTS' | string;
  targetUserId?: string;
  targetTournamentId?: string;
  isPublished?: boolean;
  createdAt: number;
  createdBy?: string;
  sentBy?: string;
}

export type TicketStatus = 'Open' | 'In Progress' | 'Resolved' | 'Closed';

export interface TicketMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: 'USER' | 'ADMIN';
  message: string;
  createdAt: number;
}

export interface SupportTicket {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  subject: string;
  category: 'Wallet' | 'Tournament' | 'Payment' | 'Account' | 'Other';
  status: TicketStatus;
  assignedToAdminId?: string;
  assignedToAdminName?: string;
  messages: TicketMessage[];
  createdAt: number;
  updatedAt: number;
}

export interface WebsiteSettings {
  id: string;
  websiteName: string;
  tagline: string;
  logoUrl?: string;
  faviconUrl?: string;
  contactGmail: string;
  instagramHandle: string;
  whatsAppNumber: string;
  supportPhone: string;
  discordUrl?: string;
  telegramUrl?: string;
  youtubeChannelUrl?: string;
  footerText: string;
  aboutText: string;
  rulesText: string;
  faqList: { question: string; answer: string }[];
  termsText: string;
  privacyPolicyText: string;
  // Payment controls
  isUpiEnabled: boolean;
  upiId: string;
  upiAccountHolder: string;
  isQrEnabled: boolean;
  qrCodeUrl?: string;
  paymentInstructions: string;
  minDepositAmount?: number;
  maxDepositAmount?: number;
  minWithdrawAmount?: number;
  maxWithdrawAmount?: number;
  updatedAt: number;
  updatedBy?: string;
}

export interface HomepageSettings {
  id: string;
  heroHeadline: string;
  heroSubheadline: string;
  heroBannerUrl?: string;
  ctaButtonText: string;
  ctaButtonLink: string;
  featuredTournamentIds: string[];
  showUpcomingSection: boolean;
  showLiveSection: boolean;
  showCompletedSection: boolean;
  showLeaderboardPreview: boolean;
  promotionalBanners: {
    id: string;
    title: string;
    imageUrl: string;
    linkUrl?: string;
    isActive: boolean;
  }[];
  updatedAt: number;
}

export interface AdminLog {
  id: string;
  adminId: string;
  adminEmail: string;
  adminRole: AdminRole;
  action: string;
  targetResource: string;
  targetId?: string;
  description: string;
  details?: Record<string, any>;
  timestamp: number;
}

export interface DashboardStats {
  totalUsers: number;
  totalTournaments: number;
  upcomingTournaments: number;
  liveTournaments: number;
  completedTournaments: number;
  totalRegistrations: number;
  pendingRegistrations: number;
  approvedRegistrations: number;
  pendingPayments: number;
  approvedPayments: number;
  pendingWithdrawals: number;
  totalDeposits: number;
  totalWithdrawals: number;
  totalEntryFees: number;
  totalPrizeDistributed: number;
  totalRevenue: number;
}
