import React, { useEffect, useState } from 'react';
import { Menu, RefreshCw, Wifi, Grid, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  onToggleMobileMenu: () => void;
  onRefreshData?: () => void;
  isRefreshing?: boolean;
  onOpenMasterMenu?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onToggleMobileMenu,
  onRefreshData,
  isRefreshing = false,
  onOpenMasterMenu,
}) => {
  const { adminProfile, role, currentUser } = useAuth();
  const [time, setTime] = useState<string>('');

  useEffect(() => {
    const update = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header
      id="admin-navbar"
      className="sticky top-0 z-30 h-16 bg-zinc-950/80 backdrop-blur-md border-b border-zinc-800/80 px-4 sm:px-6 flex items-center justify-between"
    >
      <div className="flex items-center gap-3">
        <button
          id="btn-mobile-menu-toggle"
          onClick={onToggleMobileMenu}
          className="lg:hidden p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-900 border border-zinc-800 transition cursor-pointer"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Master Control Menu Trigger in Navbar */}
        {onOpenMasterMenu && (
          <button
            id="btn-navbar-master-menu"
            onClick={onOpenMasterMenu}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs shadow-md shadow-amber-500/20 transition active:scale-95 cursor-pointer"
          >
            <Grid className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">ALL FEATURES MENU</span>
            <span className="sm:hidden">MENU</span>
          </button>
        )}

        <div className="hidden md:flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-mono">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-semibold">Firebase Live: Real Firestore</span>
        </div>

        <div className="md:hidden flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-300 text-xs">
          <Wifi className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-[11px] font-mono font-medium">Live</span>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Real-time Clock */}
        <div className="hidden md:flex items-center gap-1.5 text-xs text-zinc-400 font-mono bg-zinc-900/60 px-3 py-1.5 rounded-lg border border-zinc-800">
          <span>{time}</span>
        </div>

        {/* Refresh button */}
        {onRefreshData && (
          <button
            id="btn-navbar-refresh"
            onClick={onRefreshData}
            title="Refresh Live Data"
            disabled={isRefreshing}
            className="p-2 rounded-xl text-zinc-400 hover:text-amber-400 hover:bg-zinc-900 border border-zinc-800 transition cursor-pointer active:scale-95"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-amber-400' : ''}`} />
          </button>
        )}

        {/* Role Pill */}
        <div className="flex items-center gap-2 pl-2 border-l border-zinc-800">
          <div className="text-right hidden sm:block">
            <p className="text-xs font-bold text-zinc-200 leading-tight">
              {adminProfile?.name || currentUser?.email?.split('@')[0]}
            </p>
            <p className="text-[10px] font-mono text-amber-400 uppercase tracking-wide">
              {role.replace('_', ' ')}
            </p>
          </div>
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center font-bold text-zinc-950 text-xs shadow-md shadow-amber-500/20">
            {adminProfile?.name ? adminProfile.name[0].toUpperCase() : 'A'}
          </div>
        </div>
      </div>
    </header>
  );
};

