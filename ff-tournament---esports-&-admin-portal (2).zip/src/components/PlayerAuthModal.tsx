import React, { useState } from 'react';
import { X, Mail, Lock, User, Phone, Gamepad2, AlertCircle, CheckCircle2, Shield, ArrowRight, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface PlayerAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'signup' | 'admin';
  onAdminLoginSuccess?: () => void;
}

export const PlayerAuthModal: React.FC<PlayerAuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'login',
  onAdminLoginSuccess,
}) => {
  const { login, loginWithGoogle, signupWithEmail, resetPassword } = useAuth();
  const [mode, setMode] = useState<'login' | 'signup' | 'admin' | 'forgot'>(initialMode);
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [name, setName] = useState<string>('');
  const [ign, setIgn] = useState<string>('');
  const [ffUid, setFfUid] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [referralCodeInput, setReferralCodeInput] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  // Sync mode when modal opens
  React.useEffect(() => {
    if (isOpen) {
      setMode(initialMode);
      setError('');
      setSuccess('');
      setEmail('');
      setPassword('');
      const savedRef = localStorage.getItem('ff_pending_ref_code') || '';
      setReferralCodeInput(savedRef);
    }
  }, [isOpen, initialMode]);

  if (!isOpen) return null;

  const handleGoogleSignIn = async () => {
    setError('');
    setLoading(true);
    try {
      await loginWithGoogle();
      onClose();
    } catch (err: any) {
      console.error('Google sign in error:', err);
      setError(err.message || 'Google sign-in was cancelled or failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      if (mode === 'admin') {
        const cleanEmail = email.trim();
        if (!cleanEmail || !password) {
          throw new Error('Please enter email and password');
        }
        await login(cleanEmail, password);
        setSuccess('Admin verified successfully!');
        setTimeout(() => {
          onClose();
          if (onAdminLoginSuccess) onAdminLoginSuccess();
        }, 500);
      } else if (mode === 'login') {
        const cleanEmail = email.trim();
        if (!cleanEmail || !password) {
          throw new Error('Please enter your email and password');
        }
        await login(cleanEmail, password);
        onClose();
      } else if (mode === 'signup') {
        const cleanEmail = email.trim();
        if (!cleanEmail || !password || !name.trim()) {
          throw new Error('Please enter Name, Email, and Password');
        }
        if (password.length < 6) {
          throw new Error('Password must be at least 6 characters');
        }
        await signupWithEmail({
          email: cleanEmail,
          pass: password,
          name: name.trim(),
          ign: ign.trim() || name.trim(),
          ffUid: ffUid.trim(),
          phone: phone.trim(),
          referralCode: referralCodeInput.trim(),
        });
        onClose();
      } else if (mode === 'forgot') {
        if (!email.trim()) {
          throw new Error('Please enter your registered email');
        }
        await resetPassword(email.trim());
        setSuccess('Password reset link sent to ' + email);
      }
    } catch (err: any) {
      console.error('Auth error:', err);
      let msg = err.message || 'Authentication failed';
      if (err.code === 'auth/invalid-credential' || err.code === 'auth/wrong-password') {
        msg = 'Invalid email or password. Please check your credentials.';
      } else if (err.code === 'auth/email-already-in-use') {
        msg = 'An account with this email already exists. Please log in.';
      } else if (err.code === 'auth/user-not-found') {
        msg = 'No account found with this email.';
      } else if (err.code === 'auth/operation-not-allowed') {
        msg = 'This sign-in provider is disabled in Firebase Console. Local instant session activated.';
      }
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      id="modal-player-auth-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="modal-player-auth-card"
        className="w-full max-w-md bg-[#0F1115] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden text-white"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Glow effects */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          id="btn-close-auth-modal"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-600 p-0.5 shadow-lg shadow-amber-500/20 mb-3">
            <div className="w-full h-full bg-zinc-950 rounded-[14px] flex items-center justify-center">
              {mode === 'admin' ? (
                <Shield className="w-6 h-6 text-amber-400" />
              ) : (
                <Gamepad2 className="w-6 h-6 text-amber-400" />
              )}
            </div>
          </div>
          <h3 className="text-xl font-black tracking-tight text-white font-mono uppercase">
            {mode === 'admin' && '🌐 Admin Control Portal'}
            {mode === 'login' && 'Player Sign In'}
            {mode === 'signup' && 'Create Player Account'}
            {mode === 'forgot' && 'Reset Password'}
          </h3>
          <p className="text-xs text-zinc-400 mt-1">
            {mode === 'admin' && 'Authorized personnel only. Enter credentials to manage platform.'}
            {mode === 'login' && 'Log in to join tournaments, manage wallet, and claim prizes.'}
            {mode === 'signup' && 'Join Free Fire esports tournaments and win real cash rewards.'}
            {mode === 'forgot' && 'Enter your registered email to receive a recovery link.'}
          </p>
        </div>

        {/* Feedback messages */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
            <span>{success}</span>
          </div>
        )}

        {/* Google Sign In for Players */}
        {mode !== 'admin' && mode !== 'forgot' && (
          <div className="mb-5 space-y-3">
            <button
              id="btn-google-sign-in"
              type="button"
              onClick={handleGoogleSignIn}
              disabled={loading}
              className="w-full py-3 px-4 rounded-2xl bg-white hover:bg-zinc-100 text-zinc-900 font-bold text-xs flex items-center justify-center gap-3 transition shadow-md cursor-pointer disabled:opacity-50 active:scale-98"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Continue with Google</span>
            </button>

            <div className="flex items-center gap-3 my-4">
              <div className="flex-1 h-px bg-zinc-800" />
              <span className="text-[11px] font-semibold text-zinc-500 uppercase tracking-wider">Or with email</span>
              <div className="flex-1 h-px bg-zinc-800" />
            </div>
          </div>
        )}

        {/* Form with AUTOFILL DISABLED */}
        <form onSubmit={handleSubmit} autoComplete="off" className="space-y-3.5">
          {/* Fake fields to prevent aggressive Chrome auto-fill */}
          <input type="text" name="prevent_autofill_user" className="hidden" aria-hidden="true" />
          <input type="password" name="prevent_autofill_pass" className="hidden" aria-hidden="true" />

          {mode === 'signup' && (
            <>
              <div>
                <label className="block text-[11px] font-semibold uppercase text-zinc-400 mb-1">
                  Full Name / Player Name *
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Wajid Khan"
                    autoComplete="off"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white placeholder-zinc-600 focus:border-amber-500 focus:outline-none transition"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-semibold uppercase text-zinc-400 mb-1">
                    Free Fire IGN
                  </label>
                  <input
                    type="text"
                    value={ign}
                    onChange={(e) => setIgn(e.target.value)}
                    placeholder="In-Game Name"
                    autoComplete="off"
                    className="w-full px-3 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white placeholder-zinc-600 focus:border-amber-500 focus:outline-none transition"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold uppercase text-zinc-400 mb-1">
                    Free Fire UID
                  </label>
                  <input
                    type="text"
                    value={ffUid}
                    onChange={(e) => setFfUid(e.target.value)}
                    placeholder="e.g. 198273921"
                    autoComplete="off"
                    className="w-full px-3 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white placeholder-zinc-600 focus:border-amber-500 focus:outline-none transition"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold uppercase text-amber-400 mb-1 flex items-center justify-between">
                  <span>Referral Code (Optional)</span>
                  <span className="text-[10px] text-emerald-400 font-bold">Get ₹10 Bonus</span>
                </label>
                <input
                  type="text"
                  value={referralCodeInput}
                  onChange={(e) => setReferralCodeInput(e.target.value.toUpperCase())}
                  placeholder="Enter Referral Code (e.g. FF8X92)"
                  autoComplete="off"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-amber-500/30 text-xs text-amber-300 font-mono font-bold placeholder-zinc-600 focus:border-amber-500 focus:outline-none transition uppercase"
                />
              </div>
            </>
          )}

          <div>
            <label className="block text-[11px] font-semibold uppercase text-zinc-400 mb-1">
              {mode === 'admin' ? 'Admin Email' : 'Email Address *'}
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter email address"
                autoComplete="off"
                name={`user_email_noautofill_${mode}`}
                className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white placeholder-zinc-600 focus:border-amber-500 focus:outline-none transition"
              />
            </div>
          </div>

          {mode !== 'forgot' && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-[11px] font-semibold uppercase text-zinc-400">
                  Password *
                </label>
                {mode === 'login' && (
                  <button
                    type="button"
                    onClick={() => {
                      setMode('forgot');
                      setError('');
                      setSuccess('');
                    }}
                    className="text-[11px] text-amber-400 hover:underline cursor-pointer"
                  >
                    Forgot?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  autoComplete="new-password"
                  name={`user_pass_noautofill_${mode}`}
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white placeholder-zinc-600 focus:border-amber-500 focus:outline-none transition"
                />
              </div>
            </div>
          )}

          <button
            id="btn-auth-submit"
            type="submit"
            disabled={loading}
            className="w-full mt-3 py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition shadow-lg shadow-amber-500/20 active:scale-98 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {loading ? (
              <span>Connecting to Firebase...</span>
            ) : mode === 'admin' ? (
              <>
                <span>Access Admin Panel</span>
                <ArrowRight className="w-4 h-4" />
              </>
            ) : mode === 'login' ? (
              <>
                <span>Sign In to Play</span>
                <ArrowRight className="w-4 h-4" />
              </>
            ) : mode === 'signup' ? (
              <>
                <span>Create Account</span>
                <Sparkles className="w-4 h-4" />
              </>
            ) : (
              <span>Send Recovery Link</span>
            )}
          </button>
        </form>

        {/* Modal Switchers & Links */}
        <div className="mt-5 pt-4 border-t border-zinc-800/80 flex flex-col gap-2.5 text-center text-xs">
          {mode === 'login' && (
            <p className="text-zinc-400">
              Don't have an account?{' '}
              <button
                type="button"
                onClick={() => {
                  setMode('signup');
                  setError('');
                }}
                className="text-amber-400 font-bold hover:underline cursor-pointer"
              >
                Sign Up
              </button>
            </p>
          )}

          {mode === 'signup' && (
            <p className="text-zinc-400">
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError('');
                }}
                className="text-amber-400 font-bold hover:underline cursor-pointer"
              >
                Sign In
              </button>
            </p>
          )}

          {mode === 'forgot' && (
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setError('');
              }}
              className="text-amber-400 hover:underline cursor-pointer"
            >
              ← Back to Sign In
            </button>
          )}

          {/* Admin Switcher Icon */}
          <div className="pt-2 flex justify-center">
            {mode !== 'admin' ? (
              <button
                id="btn-switch-to-admin-login"
                type="button"
                onClick={() => {
                  setMode('admin');
                  setError('');
                  setSuccess('');
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-zinc-900 border border-zinc-800 text-[11px] font-semibold text-zinc-400 hover:text-amber-400 hover:border-amber-500/30 transition cursor-pointer"
              >
                <span>🌐</span>
                <span>Admin Login Portal</span>
              </button>
            ) : (
              <button
                id="btn-switch-to-player-login"
                type="button"
                onClick={() => {
                  setMode('login');
                  setError('');
                  setSuccess('');
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-zinc-900 border border-zinc-800 text-[11px] font-semibold text-zinc-400 hover:text-amber-400 transition cursor-pointer"
              >
                <span>🎮</span>
                <span>Back to Player Login</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
