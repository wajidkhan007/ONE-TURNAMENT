import React from 'react';
import {
  LayoutDashboard,
  Trophy,
  Swords,
  Users,
  CreditCard,
  Wallet,
  ArrowDownCircle,
  ArrowUpCircle,
  ReceiptText,
  KeyRound,
  BarChart3,
  Award,
  UserCheck,
  Tag,
  Share2,
  Bell,
  HelpCircle,
  Globe,
  Settings,
  FileSpreadsheet,
  History,
  ShieldCheck,
  LogOut,
  X,
  Sparkles,
  Grid,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ActiveTab, AdminRole } from '../types';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isOpenMobile?: boolean;
  setIsOpenMobile?: (open: boolean) => void;
  isMobileOpen?: boolean;
  setIsMobileOpen?: (open: boolean) => void;
  onOpenMasterMenu?: () => void;
}

interface NavItem {
  id: ActiveTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  roles: AdminRole[];
}

interface NavGroup {
  title: string;
  items: NavItem[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  isOpenMobile,
  setIsOpenMobile,
  isMobileOpen,
  setIsMobileOpen,
  onOpenMasterMenu,
}) => {
  const isMobile = isOpenMobile !== undefined ? isOpenMobile : !!isMobileOpen;
  const setMobile = (val: boolean) => {
    if (setIsOpenMobile) setIsOpenMobile(val);
    if (setIsMobileOpen) setIsMobileOpen(val);
  };
  const { role, isSuperAdmin, logout, adminProfile, currentUser } = useAuth();

  const navGroups: NavGroup[] = [
    {
      title: 'OVERVIEW',
      items: [
        {
          id: 'dashboard',
          label: 'Dashboard',
          icon: LayoutDashboard,
          roles: ['SUPER_ADMIN', 'TOURNAMENT_ADMIN', 'PAYMENT_ADMIN', 'RESULT_ADMIN', 'SUPPORT_ADMIN'],
        },
      ],
    },
    {
      title: 'TOURNAMENTS',
      items: [
        {
          id: 'tournaments',
          label: 'Tournaments',
          icon: Trophy,
          roles: ['SUPER_ADMIN', 'TOURNAMENT_ADMIN'],
        },
        {
          id: 'matches',
          label: 'Matches',
          icon: Swords,
          roles: ['SUPER_ADMIN', 'TOURNAMENT_ADMIN'],
        },
        {
          id: 'registrations',
          label: 'Registrations',
          icon: Users,
          roles: ['SUPER_ADMIN', 'TOURNAMENT_ADMIN', 'PAYMENT_ADMIN'],
        },
      ],
    },
    {
      title: 'FINANCE & WALLET',
      items: [
        {
          id: 'payments',
          label: 'Payments',
          icon: CreditCard,
          roles: ['SUPER_ADMIN', 'PAYMENT_ADMIN'],
        },
        {
          id: 'wallet',
          label: 'User Wallets',
          icon: Wallet,
          roles: ['SUPER_ADMIN', 'PAYMENT_ADMIN'],
        },
        {
          id: 'deposits',
          label: 'Deposits',
          icon: ArrowDownCircle,
          roles: ['SUPER_ADMIN', 'PAYMENT_ADMIN'],
        },
        {
          id: 'withdrawals',
          label: 'Withdrawals',
          icon: ArrowUpCircle,
          roles: ['SUPER_ADMIN', 'PAYMENT_ADMIN'],
        },
        {
          id: 'transactions',
          label: 'Transactions Ledger',
          icon: ReceiptText,
          roles: ['SUPER_ADMIN', 'PAYMENT_ADMIN'],
        },
      ],
    },
    {
      title: 'ROOMS & RESULTS',
      items: [
        {
          id: 'rooms',
          label: 'Room Distribution',
          icon: KeyRound,
          roles: ['SUPER_ADMIN', 'TOURNAMENT_ADMIN'],
        },
        {
          id: 'leaderboard',
          label: 'Leaderboard',
          icon: BarChart3,
          roles: ['SUPER_ADMIN', 'TOURNAMENT_ADMIN', 'RESULT_ADMIN'],
        },
        {
          id: 'results',
          label: 'Results & Prizes',
          icon: Award,
          roles: ['SUPER_ADMIN', 'TOURNAMENT_ADMIN', 'RESULT_ADMIN'],
        },
      ],
    },
    {
      title: 'COMMUNITY & USERS',
      items: [
        {
          id: 'users',
          label: 'User Management',
          icon: UserCheck,
          roles: ['SUPER_ADMIN', 'SUPPORT_ADMIN'],
        },
        {
          id: 'coupons',
          label: 'Coupons',
          icon: Tag,
          roles: ['SUPER_ADMIN', 'PAYMENT_ADMIN', 'TOURNAMENT_ADMIN'],
        },
        {
          id: 'referrals',
          label: 'Referrals',
          icon: Share2,
          roles: ['SUPER_ADMIN'],
        },
        {
          id: 'notifications',
          label: 'Notifications',
          icon: Bell,
          roles: ['SUPER_ADMIN', 'SUPPORT_ADMIN', 'TOURNAMENT_ADMIN'],
        },
        {
          id: 'support',
          label: 'Support Tickets',
          icon: HelpCircle,
          roles: ['SUPER_ADMIN', 'SUPPORT_ADMIN'],
        },
      ],
    },
    {
      title: 'PLATFORM & CMS',
      items: [
        {
          id: 'homepage',
          label: 'Homepage Control',
          icon: Globe,
          roles: ['SUPER_ADMIN'],
        },
        {
          id: 'banners',
          label: 'Banner Graphics',
          icon: Sparkles,
          roles: ['SUPER_ADMIN'],
        },
        {
          id: 'settings',
          label: 'Website & UPI Settings',
          icon: Settings,
          roles: ['SUPER_ADMIN'],
        },
      ],
    },
    {
      title: 'SYSTEM & SECURITY',
      items: [
        {
          id: 'reports',
          label: 'Reports & Analytics',
          icon: FileSpreadsheet,
          roles: ['SUPER_ADMIN', 'PAYMENT_ADMIN'],
        },
        {
          id: 'logs',
          label: 'Activity Logs',
          icon: History,
          roles: ['SUPER_ADMIN'],
        },
        {
          id: 'admins',
          label: 'Admin Management',
          icon: ShieldCheck,
          roles: ['SUPER_ADMIN'],
        },
      ],
    },
  ];

  const handleSelectTab = (tab: ActiveTab) => {
    setActiveTab(tab);
    setMobile(false);
  };

  return (
    <>
      {/* Mobile overlay */}
      {isMobile && (
        <div
          onClick={() => setMobile(false)}
          className="fixed inset-0 bg-black/80 z-40 lg:hidden backdrop-blur-sm"
        />
      )}

      <aside
        id="admin-sidebar"
        className={`fixed top-0 left-0 bottom-0 z-50 w-72 bg-zinc-950 border-r border-zinc-800/80 flex flex-col transition-transform duration-200 lg:translate-x-0 ${
          isMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="h-16 px-5 flex items-center justify-between border-b border-zinc-800/80 bg-zinc-950">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-600 to-amber-400 flex items-center justify-center font-black text-zinc-950 text-base shadow-lg shadow-amber-500/20">
              FF
            </div>
            <div>
              <h1 className="font-extrabold text-white text-base tracking-wide flex items-center gap-1.5 font-mono">
                FF TOURNAMENT
              </h1>
              <span className="text-[10px] uppercase font-bold tracking-widest text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
                PROD ADMIN
              </span>
            </div>
          </div>
          <button
            onClick={() => setMobile(false)}
            className="lg:hidden text-zinc-400 hover:text-white p-1 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Master Control Menu Trigger Button */}
        {onOpenMasterMenu && (
          <div className="p-3 bg-zinc-900/60 border-b border-zinc-800/80">
            <button
              id="btn-sidebar-open-master-menu"
              onClick={onOpenMasterMenu}
              className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-zinc-950 font-black text-xs shadow-lg shadow-amber-500/20 transition active:scale-98 cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <Grid className="w-4 h-4" />
                <span>ALL FEATURES MENU</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-950/20 text-zinc-950 font-extrabold">
                24 MODS
              </span>
            </button>
          </div>
        )}

        {/* Admin info badge */}
        <div className="px-4 py-3 border-b border-zinc-800/60 bg-zinc-900/40">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center text-xs font-bold text-amber-400">
              {adminProfile?.name ? adminProfile.name[0].toUpperCase() : 'A'}
            </div>
            <div className="overflow-hidden">
              <p className="text-xs font-bold text-zinc-200 truncate">
                {adminProfile?.name || currentUser?.email?.split('@')[0] || 'Admin'}
              </p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-[10px] font-semibold text-amber-400 uppercase tracking-wider">
                  {role.replace('_', ' ')}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation List */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6 scrollbar-thin scrollbar-thumb-zinc-800">
          {navGroups.map((group) => {
            // Filter items by role
            const visibleItems = group.items.filter((item) => isSuperAdmin || item.roles.includes(role));
            if (visibleItems.length === 0) return null;

            return (
              <div key={group.title}>
                <p className="px-3 text-[10px] font-bold tracking-wider text-zinc-400 uppercase mb-2">
                  {group.title}
                </p>
                <div className="space-y-1">
                  {visibleItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        id={`nav-item-${item.id}`}
                        onClick={() => handleSelectTab(item.id)}
                        className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
                          isActive
                            ? 'bg-amber-500 text-zinc-950 font-bold shadow-lg shadow-amber-500/20'
                            : 'text-zinc-400 hover:text-white hover:bg-zinc-900/80'
                        }`}
                      >
                        <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-zinc-950' : 'text-zinc-400'}`} />
                        <span className="truncate">{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer with Logout */}
        <div className="p-3 border-t border-zinc-800/80 bg-zinc-950">
          <button
            id="btn-sidebar-logout"
            onClick={logout}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-bold text-rose-400 hover:text-white hover:bg-rose-500/20 border border-rose-500/20 transition cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>
    </>
  );
};
