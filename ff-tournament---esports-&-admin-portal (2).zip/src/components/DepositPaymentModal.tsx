import React, { useState, useEffect } from 'react';
import {
  X,
  QrCode,
  ArrowDownCircle,
  Copy,
  Check,
  Upload,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  Smartphone,
  ExternalLink,
  ShieldCheck,
  RefreshCw,
  Wallet,
  Trash2,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { playerRequestDeposit } from '../services/adminService';
import { WebsiteSettings } from '../types';

interface DepositPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  websiteSettings: WebsiteSettings | null;
  onSuccess?: () => void;
  initialAmount?: number;
}

export const DepositPaymentModal: React.FC<DepositPaymentModalProps> = ({
  isOpen,
  onClose,
  websiteSettings,
  onSuccess,
  initialAmount = 100,
}) => {
  const { currentUser, userProfile } = useAuth();
  const [amount, setAmount] = useState<number>(initialAmount);
  const [utrNumber, setUtrNumber] = useState<string>('');
  const [screenshotData, setScreenshotData] = useState<string>('');
  const [screenshotFileName, setScreenshotFileName] = useState<string>('');
  const [uploadMethod, setUploadMethod] = useState<'file' | 'url'>('file');
  const [screenshotUrlInput, setScreenshotUrlInput] = useState<string>('');

  const [loading, setLoading] = useState<boolean>(false);
  const [copiedUpi, setCopiedUpi] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [submittedData, setSubmittedData] = useState<{
    id: string;
    amount: number;
    utr: string;
    date: number;
  } | null>(null);

  useEffect(() => {
    if (isOpen) {
      setAmount(initialAmount || 100);
      setUtrNumber('');
      setScreenshotData('');
      setScreenshotFileName('');
      setScreenshotUrlInput('');
      setErrorMsg('');
      setSubmittedData(null);
    }
  }, [isOpen, initialAmount]);

  if (!isOpen) return null;

  const adminUpi = websiteSettings?.upiId || '9991522138-2@ybl';
  const adminName = websiteSettings?.upiAccountHolder || 'FF Tournament Official';
  const minDeposit = websiteSettings?.minDeposit || 10;
  const maxDeposit = websiteSettings?.maxDeposit || 10000;

  // Standard UPI Intent URL
  const upiIntentUrl = `upi://pay?pa=${encodeURIComponent(adminUpi)}&pn=${encodeURIComponent(
    adminName
  )}&am=${amount}&cu=INR&tn=${encodeURIComponent('FF Tournament Wallet Deposit')}`;

  // App-specific deep links
  const phonePeUrl = `phonepe://pay?pa=${encodeURIComponent(adminUpi)}&pn=${encodeURIComponent(adminName)}&am=${amount}&cu=INR`;
  const paytmUrl = `paytmmp://pay?pa=${encodeURIComponent(adminUpi)}&pn=${encodeURIComponent(adminName)}&am=${amount}&cu=INR`;
  const gpayUrl = `gpay://upi/pay?pa=${encodeURIComponent(adminUpi)}&pn=${encodeURIComponent(adminName)}&am=${amount}&cu=INR`;

  // Dynamic QR Code generation with reliable API
  const qrCodeUrl =
    websiteSettings?.qrCodeUrl ||
    `https://api.qrserver.com/v1/create-qr-code/?size=260x260&data=${encodeURIComponent(upiIntentUrl)}`;

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(adminUpi);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (PNG, JPG, JPEG, WEBP)');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setErrorMsg('File size exceeds 5MB limit. Please upload a smaller screenshot.');
      return;
    }

    setScreenshotFileName(file.name);
    setErrorMsg('');

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setScreenshotData(event.target.result as string);
      }
    };
    reader.onerror = () => {
      setErrorMsg('Failed to process image file. Please try again.');
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveScreenshot = () => {
    setScreenshotData('');
    setScreenshotFileName('');
    setScreenshotUrlInput('');
  };

  const handlePayAndSubmit = async (targetAppUrl?: string) => {
    if (!currentUser) {
      setErrorMsg('Please sign in to submit a deposit request.');
      return;
    }

    if (!amount || amount < minDeposit) {
      setErrorMsg(`Minimum deposit amount is ₹${minDeposit}`);
      return;
    }

    if (amount > maxDeposit) {
      setErrorMsg(`Maximum deposit amount is ₹${maxDeposit}`);
      return;
    }

    const finalUtr =
      utrNumber.trim() || `DIRECT_UPI_${Math.floor(10000000 + Math.random() * 90000000)}`;
    const finalScreenshot = uploadMethod === 'url' ? screenshotUrlInput.trim() : screenshotData;

    setLoading(true);
    setErrorMsg('');

    // Automatically trigger UPI App Deep Link
    const launchUrl = targetAppUrl || upiIntentUrl;
    try {
      window.location.href = launchUrl;
    } catch (e) {
      console.warn('UPI app launch notice:', e);
    }

    try {
      const docId = await playerRequestDeposit({
        userId: currentUser.uid,
        userEmail: currentUser.email || '',
        userName: userProfile?.name || currentUser.displayName || 'Player',
        amount: Number(amount),
        utrNumber: finalUtr,
        screenshotUrl: finalScreenshot || '',
        upiUsed: adminUpi,
      });

      setSubmittedData({
        id: docId,
        amount: Number(amount),
        utr: finalUtr,
        date: Date.now(),
      });

      if (onSuccess) {
        onSuccess();
      }
    } catch (err: any) {
      console.error('Deposit submission error:', err);
      setErrorMsg(err.message || 'Failed to submit deposit request. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await handlePayAndSubmit();
  };

  return (
    <div
      id="deposit-payment-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto"
    >
      <div
        id="deposit-payment-modal-dialog"
        className="w-full max-w-2xl bg-[#0F1115] border border-zinc-800 rounded-3xl shadow-2xl overflow-hidden my-auto flex flex-col max-h-[94vh]"
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-zinc-800/80 bg-zinc-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <ArrowDownCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white tracking-tight flex items-center gap-2">
                <span>Add Money / Deposit via UPI</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  INSTANT QR
                </span>
              </h2>
              <p className="text-xs text-zinc-400">
                Scan the dynamic QR code with Google Pay, PhonePe, or Paytm & submit with UTR.
              </p>
            </div>
          </div>
          <button
            id="btn-close-deposit-modal"
            onClick={onClose}
            className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-900 border border-zinc-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {submittedData ? (
            /* SUCCESS CONFIRMATION RECEIPT */
            <div className="text-center py-6 sm:py-8 space-y-5 animate-in zoom-in-95 duration-200">
              <div className="w-16 h-16 rounded-3xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto shadow-xl shadow-emerald-500/10">
                <CheckCircle2 className="w-9 h-9" />
              </div>

              <div className="space-y-1">
                <h3 className="text-xl font-black text-white">Deposit Request Submitted!</h3>
                <p className="text-xs text-zinc-400 max-w-md mx-auto">
                  Your payment request has been automatically sent to the Admin Panel. Your wallet will be credited as soon as the 12-digit UTR is verified.
                </p>
              </div>

              {/* Receipt Box */}
              <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 max-w-md mx-auto text-left space-y-2.5 text-xs">
                <div className="flex justify-between items-center pb-2 border-b border-zinc-800/80">
                  <span className="text-zinc-400">Deposit Amount</span>
                  <span className="font-mono font-black text-emerald-400 text-base">₹{submittedData.amount}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-zinc-400">Bank UTR / Tx ID</span>
                  <span className="font-mono font-bold text-amber-400">{submittedData.utr}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-zinc-400">Admin UPI ID</span>
                  <span className="font-mono text-zinc-300">{adminUpi}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-zinc-400">Verification Status</span>
                  <span className="font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 animate-pulse">
                    Pending Admin Approval
                  </span>
                </div>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  onClick={() => {
                    setSubmittedData(null);
                    onClose();
                  }}
                  className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition cursor-pointer"
                >
                  Done & Back to Tournaments
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {errorMsg && (
                <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* STEP 1: AMOUNT SELECTION */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                    <span>1. Select / Enter Deposit Amount (₹)</span>
                  </label>
                  <span className="text-[11px] text-zinc-500">
                    Min: ₹{minDeposit} | Max: ₹{maxDeposit}
                  </span>
                </div>

                {/* Quick Chips */}
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                  {[50, 100, 200, 300, 500, 1000].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setAmount(amt)}
                      className={`py-2 rounded-xl text-xs font-black transition cursor-pointer ${
                        amount === amt
                          ? 'bg-amber-500 text-zinc-950 shadow-md shadow-amber-500/20'
                          : 'bg-zinc-950 border border-zinc-800 text-zinc-300 hover:border-zinc-700'
                      }`}
                    >
                      ₹{amt}
                    </button>
                  ))}
                </div>

                {/* Custom Amount Input */}
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-mono font-bold text-amber-400 text-base">
                    ₹
                  </span>
                  <input
                    type="number"
                    min={minDeposit}
                    max={maxDeposit}
                    required
                    value={amount || ''}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    placeholder="Enter custom amount..."
                    className="w-full pl-8 pr-4 py-2.5 rounded-2xl bg-zinc-950 border border-zinc-800 text-sm font-bold text-white placeholder:text-zinc-600 focus:outline-none focus:border-amber-500 transition"
                  />
                </div>
              </div>

              {/* STEP 2: DYNAMIC QR CODE & UPI DETAILS */}
              <div className="p-4 sm:p-5 rounded-3xl bg-zinc-950 border border-zinc-800 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                    <QrCode className="w-4 h-4" />
                    <span>2. Scan Live UPI QR Code (₹{amount})</span>
                  </h3>
                  <button
                    type="button"
                    onClick={handleCopyUpi}
                    className="flex items-center gap-1 text-[11px] text-amber-400 hover:underline bg-amber-500/10 px-2.5 py-1 rounded-xl border border-amber-500/20 transition cursor-pointer"
                  >
                    {copiedUpi ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedUpi ? 'Copied' : 'Copy UPI ID'}</span>
                  </button>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-5 p-4 rounded-2xl bg-zinc-900/70 border border-zinc-800">
                  {/* High-Resolution QR Box */}
                  <div className="bg-white p-2.5 rounded-2xl shrink-0 shadow-lg shadow-black/50 relative group">
                    <img
                      src={qrCodeUrl}
                      alt="Live Payment QR Code"
                      className="w-36 h-36 object-contain"
                      onError={(e) => {
                        const target = e.currentTarget;
                        if (!target.dataset.fallback) {
                          target.dataset.fallback = 'true';
                          target.src = `https://quickchart.io/qr?size=300&text=${encodeURIComponent(upiIntentUrl)}`;
                        }
                      }}
                    />
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-xs rounded-2xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition duration-200">
                      <span className="text-[10px] font-black text-white bg-amber-500 px-2 py-1 rounded-lg text-zinc-950">
                        ₹{amount} Fixed
                      </span>
                    </div>
                  </div>

                  {/* UPI Info & Direct App Buttons */}
                  <div className="space-y-2.5 text-center sm:text-left flex-1 min-w-0">
                    <div>
                      <p className="text-[10px] uppercase font-bold text-zinc-500">Official Admin UPI VPA</p>
                      <p className="text-sm font-mono font-black text-amber-400 break-all select-all">
                        {adminUpi}
                      </p>
                      <p className="text-xs font-semibold text-zinc-300">
                        {adminName}
                      </p>
                    </div>

                    <p className="text-[11px] text-zinc-400 leading-relaxed">
                      Scan QR code or click your UPI App below to transfer exact amount <strong>₹{amount}</strong>:
                    </p>

                    {/* Direct App Launch Buttons */}
                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => handlePayAndSubmit(phonePeUrl)}
                        disabled={loading || !currentUser}
                        className="py-2.5 px-3 rounded-xl bg-purple-900/40 hover:bg-purple-800/60 border border-purple-500/30 text-purple-200 font-bold text-[11px] transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-98 disabled:opacity-50"
                      >
                        <Smartphone className="w-3.5 h-3.5 text-purple-400" />
                        <span>Pay via PhonePe</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handlePayAndSubmit(paytmUrl)}
                        disabled={loading || !currentUser}
                        className="py-2.5 px-3 rounded-xl bg-sky-900/40 hover:bg-sky-800/60 border border-sky-500/30 text-sky-200 font-bold text-[11px] transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-98 disabled:opacity-50"
                      >
                        <Smartphone className="w-3.5 h-3.5 text-sky-400" />
                        <span>Pay via Paytm</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handlePayAndSubmit(gpayUrl)}
                        disabled={loading || !currentUser}
                        className="py-2.5 px-3 rounded-xl bg-blue-900/40 hover:bg-blue-800/60 border border-blue-500/30 text-blue-200 font-bold text-[11px] transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-98 disabled:opacity-50"
                      >
                        <Smartphone className="w-3.5 h-3.5 text-blue-400" />
                        <span>Pay via Google Pay</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handlePayAndSubmit(upiIntentUrl)}
                        disabled={loading || !currentUser}
                        className="py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-[11px] transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-amber-500/20 active:scale-98 disabled:opacity-50"
                      >
                        <Smartphone className="w-3.5 h-3.5" />
                        <span>Any UPI App</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* STEP 3: UPLOAD PAYMENT SCREENSHOT & UTR NUMBER (OPTIONAL) */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold uppercase tracking-wider text-amber-400">
                    3. Payment Proof & UTR (Optional)
                  </label>
                  <div className="flex items-center gap-1 text-[11px]">
                    <button
                      type="button"
                      onClick={() => setUploadMethod('file')}
                      className={`px-2 py-0.5 rounded-lg font-bold transition cursor-pointer ${
                        uploadMethod === 'file' ? 'bg-amber-500 text-zinc-950' : 'text-zinc-400 hover:text-white'
                      }`}
                    >
                      Upload File
                    </button>
                    <button
                      type="button"
                      onClick={() => setUploadMethod('url')}
                      className={`px-2 py-0.5 rounded-lg font-bold transition cursor-pointer ${
                        uploadMethod === 'url' ? 'bg-amber-500 text-zinc-950' : 'text-zinc-400 hover:text-white'
                      }`}
                    >
                      Image URL
                    </button>
                  </div>
                </div>

                {/* Screenshot Uploader */}
                {uploadMethod === 'file' ? (
                  <div>
                    {screenshotData ? (
                      /* Screenshot Live Preview */
                      <div className="p-3.5 rounded-2xl bg-zinc-950 border border-emerald-500/30 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <img
                            src={screenshotData}
                            alt="Uploaded Receipt"
                            className="w-14 h-14 object-cover rounded-xl border border-zinc-800 shrink-0"
                          />
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-white truncate">
                              {screenshotFileName || 'Payment_Receipt.png'}
                            </p>
                            <p className="text-[10px] text-emerald-400 flex items-center gap-1 mt-0.5">
                              <Check className="w-3 h-3" />
                              <span>Screenshot Attached (Visible to Admin)</span>
                            </p>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={handleRemoveScreenshot}
                          className="p-2 rounded-xl text-rose-400 hover:bg-rose-500/10 border border-zinc-800 hover:border-rose-500/30 transition cursor-pointer shrink-0"
                          title="Remove Screenshot"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      /* Drag & Drop File Input Area */
                      <label className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-zinc-800 hover:border-amber-500/50 rounded-2xl bg-zinc-950/60 hover:bg-zinc-900/40 transition cursor-pointer group">
                        <div className="w-10 h-10 rounded-xl bg-zinc-900 group-hover:bg-amber-500/10 text-zinc-400 group-hover:text-amber-400 flex items-center justify-center transition">
                          <Upload className="w-5 h-5" />
                        </div>
                        <p className="text-xs font-bold text-zinc-200 mt-2">
                          Click to select or drag & drop Payment Screenshot (Optional)
                        </p>
                        <p className="text-[11px] text-zinc-500 mt-0.5">
                          PNG, JPG, JPEG from PhonePe / Google Pay / Paytm (Max 5MB)
                        </p>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleFileUpload}
                          className="hidden"
                        />
                      </label>
                    )}
                  </div>
                ) : (
                  /* Image URL input */
                  <div>
                    <input
                      type="url"
                      value={screenshotUrlInput}
                      onChange={(e) => setScreenshotUrlInput(e.target.value)}
                      placeholder="Paste payment screenshot image URL (e.g. https://...)"
                      className="w-full px-3.5 py-2.5 rounded-2xl bg-zinc-950 border border-zinc-800 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-amber-500 transition"
                    />
                  </div>
                )}

                {/* 12-Digit UTR Input (Optional) */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-[11px] font-bold uppercase text-zinc-300">
                      12-Digit UPI Reference / UTR Number <span className="text-zinc-500 font-normal">(Optional - Auto Generated if empty)</span>
                    </label>
                  </div>
                  <input
                    type="text"
                    value={utrNumber}
                    onChange={(e) => setUtrNumber(e.target.value.replace(/[^0-9a-zA-Z]/g, ''))}
                    placeholder="Enter 12-digit UTR if available (or leave blank)..."
                    maxLength={24}
                    className="w-full px-3.5 py-2.5 rounded-2xl bg-zinc-950 border border-zinc-800 text-xs font-mono font-bold text-amber-400 placeholder:text-zinc-600 focus:outline-none focus:border-amber-500 transition tracking-wider"
                  />
                </div>
              </div>

              {/* Modal Footer / Submit Button */}
              <div className="pt-2 border-t border-zinc-800/80 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-[11px] text-zinc-400">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Deposit request automatically sends to Admin Panel instantly.</span>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={onClose}
                    className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-bold text-xs border border-zinc-800 transition cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={loading || !currentUser}
                    className="flex-1 sm:flex-none px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-black text-xs shadow-lg shadow-emerald-500/20 transition active:scale-98 cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {loading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Sending Request...</span>
                      </>
                    ) : (
                      <>
                        <ArrowDownCircle className="w-4 h-4" />
                        <span>Pay via UPI & Auto-Send Deposit (₹{amount})</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
