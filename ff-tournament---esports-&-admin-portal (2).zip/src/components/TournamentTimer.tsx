import React, { useState, useEffect } from 'react';
import { Clock, Flame, CheckCircle2 } from 'lucide-react';
import { Tournament } from '../types';

interface TournamentTimerProps {
  tournament: Tournament;
  variant?: 'card' | 'banner' | 'modal';
  themeColor?: 'amber' | 'emerald' | 'cyan' | 'purple' | 'rose';
}

// Utility to parse tournament time reliably
export function parseTournamentTime(dateStr?: string, timeStr?: string, fallbackOffsetMs = 3600000): number {
  if (!dateStr) return Date.now() + fallbackOffsetMs;

  try {
    // If dateStr is full ISO
    if (dateStr.includes('T')) {
      const parsed = Date.parse(dateStr);
      if (!isNaN(parsed)) return parsed;
    }

    // Combine dateStr and timeStr (e.g. "2026-08-14" + "18:00")
    const formattedTime = timeStr ? (timeStr.length === 5 ? `${timeStr}:00` : timeStr) : '18:00:00';
    const combinedStr = `${dateStr.trim()}T${formattedTime.trim()}`;
    const parsedCombined = Date.parse(combinedStr);

    if (!isNaN(parsedCombined)) return parsedCombined;

    // Direct Date parse attempt
    const directDate = new Date(`${dateStr} ${timeStr || ''}`);
    if (!isNaN(directDate.getTime())) return directDate.getTime();
  } catch (err) {
    console.warn('Date parse error, fallback applied:', err);
  }

  return Date.now() + fallbackOffsetMs;
}

export const TournamentTimer: React.FC<TournamentTimerProps> = ({
  tournament,
  variant = 'card',
  themeColor = 'amber',
}) => {
  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
    isRegExpired: boolean;
    isMatchStarted: boolean;
    label: string;
  }>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
    isRegExpired: false,
    isMatchStarted: false,
    label: 'Registration Closing',
  });

  useEffect(() => {
    const calculateTime = () => {
      const now = Date.now();

      // Determine match start time
      const matchStartMs = parseTournamentTime(tournament.date, tournament.time, 2 * 3600 * 1000);

      // Determine registration closing time (defaults to 15 mins before match start)
      let regCloseMs = matchStartMs - 15 * 60 * 1000;
      if (tournament.registrationClosingTime) {
        if (tournament.registrationClosingTime.includes(':')) {
          regCloseMs = parseTournamentTime(tournament.date, tournament.registrationClosingTime, 1.75 * 3600 * 1000);
        }
      }

      let targetMs = regCloseMs;
      let label = 'Registration Closes In';
      let isRegExpired = now >= regCloseMs;
      let isMatchStarted = now >= matchStartMs;

      if (tournament.status === 'Completed' || tournament.status === 'Cancelled') {
        setTimeLeft({
          days: 0,
          hours: 0,
          minutes: 0,
          seconds: 0,
          isRegExpired: true,
          isMatchStarted: true,
          label: tournament.status === 'Completed' ? 'Tournament Finished' : 'Tournament Cancelled',
        });
        return;
      }

      if (tournament.status === 'Live' || isMatchStarted) {
        label = 'Match Live Now 🔴';
        targetMs = matchStartMs;
      } else if (isRegExpired) {
        label = 'Match Starts In';
        targetMs = matchStartMs;
      } else {
        label = 'Registration Closes In';
        targetMs = regCloseMs;
      }

      const diff = Math.max(0, targetMs - now);

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((diff / 1000 / 60) % 60);
      const seconds = Math.floor((diff / 1000) % 60);

      setTimeLeft({
        days,
        hours,
        minutes,
        seconds,
        isRegExpired,
        isMatchStarted,
        label,
      });
    };

    calculateTime();
    const timer = setInterval(calculateTime, 1000);
    return () => clearInterval(timer);
  }, [tournament]);

  // Color mappings
  const themeStyles = {
    amber: {
      bg: 'bg-amber-500/10',
      border: 'border-amber-500/30',
      text: 'text-amber-400',
      boxBg: 'bg-amber-500/20',
      badge: 'bg-amber-500 text-black',
    },
    emerald: {
      bg: 'bg-emerald-500/10',
      border: 'border-emerald-500/30',
      text: 'text-emerald-400',
      boxBg: 'bg-emerald-500/20',
      badge: 'bg-emerald-500 text-black',
    },
    cyan: {
      bg: 'bg-cyan-500/10',
      border: 'border-cyan-500/30',
      text: 'text-cyan-400',
      boxBg: 'bg-cyan-500/20',
      badge: 'bg-cyan-500 text-black',
    },
    purple: {
      bg: 'bg-purple-500/10',
      border: 'border-purple-500/30',
      text: 'text-purple-400',
      boxBg: 'bg-purple-500/20',
      badge: 'bg-purple-500 text-white',
    },
    rose: {
      bg: 'bg-rose-500/10',
      border: 'border-rose-500/30',
      text: 'text-rose-400',
      boxBg: 'bg-rose-500/20',
      badge: 'bg-rose-500 text-white',
    },
  }[themeColor] || {
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/30',
    text: 'text-amber-400',
    boxBg: 'bg-amber-500/20',
    badge: 'bg-amber-500 text-black',
  };

  if (tournament.status === 'Completed' || tournament.status === 'Cancelled') {
    return (
      <div className="flex items-center gap-2 p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 text-xs justify-center">
        <CheckCircle2 className="w-3.5 h-3.5 text-zinc-500" />
        <span className="font-bold">{timeLeft.label}</span>
      </div>
    );
  }

  if (tournament.status === 'Live') {
    return (
      <div className="flex items-center justify-between p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-400 animate-pulse">
        <div className="flex items-center gap-2">
          <Flame className="w-4 h-4 text-rose-500 animate-bounce" />
          <span className="text-xs font-black uppercase tracking-wider">MATCH IS LIVE NOW!</span>
        </div>
        <span className="px-2 py-0.5 rounded bg-rose-500 text-white font-extrabold text-[10px] uppercase">
          IN ROOM
        </span>
      </div>
    );
  }

  // Formatting zero pad
  const pad = (n: number) => String(n).padStart(2, '0');

  // Compact variant for cards
  if (variant === 'card') {
    return (
      <div className={`p-2.5 rounded-2xl ${themeStyles.bg} border ${themeStyles.border} space-y-1.5`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-zinc-300">
            <Clock className={`w-3.5 h-3.5 ${themeStyles.text} animate-pulse`} />
            <span className="uppercase tracking-wider text-[10px]">{timeLeft.label}</span>
          </div>
          {timeLeft.isRegExpired && (
            <span className="text-[9px] font-extrabold px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
              CLOSED
            </span>
          )}
        </div>

        {/* Digital Clock display optimized for Phone, Tablet, Laptop */}
        <div className="flex items-center justify-center gap-1.5 font-mono text-xs sm:text-sm font-black">
          {timeLeft.days > 0 && (
            <>
              <div className="flex flex-col items-center">
                <span className={`px-2 py-1 rounded-lg ${themeStyles.boxBg} ${themeStyles.text} border border-white/10 shadow-inner`}>
                  {pad(timeLeft.days)}
                </span>
                <span className="text-[8px] text-zinc-400 font-sans uppercase mt-0.5">Days</span>
              </div>
              <span className={`${themeStyles.text} font-bold text-sm -mt-3`}>:</span>
            </>
          )}

          <div className="flex flex-col items-center">
            <span className={`px-2 py-1 rounded-lg ${themeStyles.boxBg} ${themeStyles.text} border border-white/10 shadow-inner`}>
              {pad(timeLeft.hours)}
            </span>
            <span className="text-[8px] text-zinc-400 font-sans uppercase mt-0.5">Hrs</span>
          </div>

          <span className={`${themeStyles.text} font-bold text-sm -mt-3`}>:</span>

          <div className="flex flex-col items-center">
            <span className={`px-2 py-1 rounded-lg ${themeStyles.boxBg} ${themeStyles.text} border border-white/10 shadow-inner`}>
              {pad(timeLeft.minutes)}
            </span>
            <span className="text-[8px] text-zinc-400 font-sans uppercase mt-0.5">Min</span>
          </div>

          <span className={`${themeStyles.text} font-bold text-sm -mt-3`}>:</span>

          <div className="flex flex-col items-center">
            <span className={`px-2 py-1 rounded-lg bg-rose-500/20 text-rose-400 border border-rose-500/30 shadow-inner animate-pulse`}>
              {pad(timeLeft.seconds)}
            </span>
            <span className="text-[8px] text-zinc-400 font-sans uppercase mt-0.5">Sec</span>
          </div>
        </div>
      </div>
    );
  }

  // Modal / Detail view larger timer
  return (
    <div className={`p-4 rounded-3xl ${themeStyles.bg} border ${themeStyles.border} space-y-2.5 text-center shadow-lg`}>
      <div className="flex items-center justify-center gap-2 text-xs sm:text-sm font-bold text-zinc-200 uppercase tracking-widest">
        <Clock className={`w-4 h-4 ${themeStyles.text} animate-spin`} style={{ animationDuration: '4s' }} />
        <span>⏱️ {timeLeft.label}</span>
      </div>

      <div className="flex items-center justify-center gap-2 sm:gap-3 font-mono">
        {timeLeft.days > 0 && (
          <>
            <div className="flex flex-col items-center">
              <div className={`w-12 h-12 sm:w-14 sm:h-14 rounded-2xl ${themeStyles.boxBg} border border-white/10 flex items-center justify-center text-lg sm:text-2xl font-black ${themeStyles.text} shadow-md`}>
                {pad(timeLeft.days)}
              </div>
              <span className="text-[10px] text-zinc-400 font-sans uppercase font-bold mt-1">Days</span>
            </div>
            <span className={`text-xl font-bold ${themeStyles.text} -mt-5`}>:</span>
          </>
        )}

        <div className="flex flex-col items-center">
          <div className={`w-12 h-12 sm:w-14 sm:h-14 rounded-2xl ${themeStyles.boxBg} border border-white/10 flex items-center justify-center text-lg sm:text-2xl font-black ${themeStyles.text} shadow-md`}>
            {pad(timeLeft.hours)}
          </div>
          <span className="text-[10px] text-zinc-400 font-sans uppercase font-bold mt-1">Hours</span>
        </div>

        <span className={`text-xl font-bold ${themeStyles.text} -mt-5`}>:</span>

        <div className="flex flex-col items-center">
          <div className={`w-12 h-12 sm:w-14 sm:h-14 rounded-2xl ${themeStyles.boxBg} border border-white/10 flex items-center justify-center text-lg sm:text-2xl font-black ${themeStyles.text} shadow-md`}>
            {pad(timeLeft.minutes)}
          </div>
          <span className="text-[10px] text-zinc-400 font-sans uppercase font-bold mt-1">Minutes</span>
        </div>

        <span className={`text-xl font-bold ${themeStyles.text} -mt-5`}>:</span>

        <div className="flex flex-col items-center">
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-rose-500/25 border border-rose-500/40 flex items-center justify-center text-lg sm:text-2xl font-black text-rose-400 shadow-md animate-pulse">
            {pad(timeLeft.seconds)}
          </div>
          <span className="text-[10px] text-rose-400/80 font-sans uppercase font-bold mt-1">Seconds</span>
        </div>
      </div>
    </div>
  );
};
