import React from 'react';
import { Loader2 } from 'lucide-react';

interface LoadingSpinnerProps {
  text?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ text = 'Loading real Firebase data...', size = 'md' }) => {
  const sizeClasses = {
    sm: 'w-5 h-5',
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
  };

  return (
    <div className="flex flex-col items-center justify-center p-12 space-y-4">
      <div className="relative">
        <div className="w-12 h-12 rounded-full border-2 border-amber-500/20 animate-ping absolute inset-0" />
        <Loader2 className={`${sizeClasses[size]} text-amber-500 animate-spin relative z-10`} />
      </div>
      {text && <p className="text-sm font-medium text-zinc-400 tracking-wide">{text}</p>}
    </div>
  );
};
