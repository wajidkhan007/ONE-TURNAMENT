import React from 'react';
import { LucideIcon, Inbox } from 'lucide-react';

interface EmptyStateProps {
  icon?: LucideIcon;
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon: Icon = Inbox,
  title,
  description,
  actionLabel,
  onAction,
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-12 text-center rounded-2xl border border-zinc-800/80 bg-zinc-950/60 my-6">
      <div className="w-16 h-16 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mb-4 text-zinc-500 shadow-inner">
        <Icon className="w-8 h-8 text-amber-500/80" />
      </div>
      <h3 className="text-lg font-semibold text-zinc-200 tracking-tight mb-1">{title}</h3>
      {description && <p className="text-sm text-zinc-400 max-w-md mb-6">{description}</p>}
      {actionLabel && onAction && (
        <button
          id={`btn-empty-action-${title.toLowerCase().replace(/\s+/g, '-')}`}
          onClick={onAction}
          className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-semibold text-sm transition shadow-lg shadow-amber-500/20 active:scale-95 cursor-pointer"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
};
