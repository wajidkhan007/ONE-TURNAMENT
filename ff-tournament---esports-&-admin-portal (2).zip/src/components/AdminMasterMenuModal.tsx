import React, { useState } from 'react';
import {
  X,
  Search,
  Trophy,
  Swords,
  Users,
  CreditCard,
  Wallet,
  ArrowDownCircle,
  ArrowUpCircle,
  ReceiptText,
  KeyRound,
  BarChart3,
  Award,
  UserCheck,
  Tag,
  Share2,
  Bell,
  HelpCircle,
  Globe,
  Settings,
  FileSpreadsheet,
  History,
  ShieldCheck,
  Sparkles,
  QrCode,
  Radio,
  Plus,
  LayoutDashboard,
  CheckCircle2,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { ActiveTab, AdminRole } from '../types';
import { useAuth } from '../context/AuthContext';

interface AdminMasterMenuModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTab: (tab: ActiveTab) => void;
  activeTab: ActiveTab;
}

interface FeatureItem {
  id: ActiveTab;
  title: string;
  hindiTitle: string;
  description: string;
  category: 'esports' | 'finance' | 'rooms' | 'users' | 'cms' | 'security';
  icon: React.ComponentType<{ className?: string }>;
  accentColor: string;
  badge: string;
  keyControls: string[];
  roles: AdminRole[];
}

export const AdminMasterMenuModal: React.FC<AdminMasterMenuModalProps> = ({
  isOpen,
  onClose,
  onSelectTab,
  activeTab,
}) => {
  const { role, isSuperAdmin } = useAuth();
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  if (!isOpen) return null;

  const features: FeatureItem[] = [
    // ESPORTS & TOURNAMENTS
    {
      id: 'dashboard',
      title: 'Admin Master Overview',
      hindiTitle: 'डैशबोर्ड एवं लाइव मेट्रिक्स',
      description: 'Global real-time overview of revenue, player registrations, active matches, and pending requests.',
      category: 'esports',
      icon: LayoutDashboard,
      accentColor: 'from-amber-500/20 to-amber-600/10 text-amber-400 border-amber-500/30',
      badge: 'REAL-TIME METRICS',
      keyControls: ['Live Revenue Counters', 'Pending Queue Alerts', 'Match Status Breakdown', 'Quick Actions'],
      roles: ['SUPER_ADMIN', 'TOURNAMENT_ADMIN', 'PAYMENT_ADMIN', 'RESULT_ADMIN', 'SUPPORT_ADMIN'],
    },
    {
      id: 'tournaments',
      title: 'Tournament Creation & Management',
      hindiTitle: 'टूर्नामेंट बनाएं एवं एडिट करें',
      description: 'Create Free Fire tournaments, set entry fees, prize pool distributions, maps, slots, and schedules.',
      category: 'esports',
      icon: Trophy,
      accentColor: 'from-amber-500/20 to-amber-600/10 text-amber-400 border-amber-500/30',
      badge: 'FULL CRUD & SLOTS',
      keyControls: ['Add New Tournaments', 'Edit Entry Fees & Prizes', 'Set Bermuda/Purgatory/Kalahari Maps', 'Duplicate Tournaments'],
      roles: ['SUPER_ADMIN', 'TOURNAMENT_ADMIN'],
    },
    {
      id: 'matches',
      title: 'Matches & Custom Schedules',
      hindiTitle: 'मैच शेड्यूल एवं राउंड्स',
      description: 'Schedule match rounds, timing, assign custom match slots, and monitor live match statuses.',
      category: 'esports',
      icon: Swords,
      accentColor: 'from-orange-500/20 to-orange-600/10 text-orange-400 border-orange-500/30',
      badge: 'SCHEDULE HUB',
      keyControls: ['Match Time & Date', 'Round Automation', 'Status Switch (Live/Completed)', 'Bracket Management'],
      roles: ['SUPER_ADMIN', 'TOURNAMENT_ADMIN'],
    },
    {
      id: 'registrations',
      title: 'Registrations & Team Rosters',
      hindiTitle: 'प्लेयर रजिस्ट्रेशन एवं टीम अप्रूवल',
      description: 'Review joined teams, verify Free Fire in-game names and UIDs, manage slot allocations, and handle approvals.',
      category: 'esports',
      icon: Users,
      accentColor: 'from-blue-500/20 to-blue-600/10 text-blue-400 border-blue-500/30',
      badge: 'TEAM & UID AUDIT',
      keyControls: ['Verify Player UIDs & IGNs', 'Manual Slot Re-assignment', 'Approve/Cancel Registrations', 'Export Player Lists'],
      roles: ['SUPER_ADMIN', 'TOURNAMENT_ADMIN', 'PAYMENT_ADMIN'],
    },

    // ROOMS & RESULTS
    {
      id: 'rooms',
      title: 'Room ID & Password Distribution',
      hindiTitle: 'कस्टम रूम आईडी एवं पासवर्ड रिलीज',
      description: 'Instant publish or update custom room credentials directly visible to all registered players.',
      category: 'rooms',
      icon: KeyRound,
      accentColor: 'from-yellow-500/20 to-yellow-600/10 text-yellow-400 border-yellow-500/30',
      badge: 'INSTANT BROADCAST',
      keyControls: ['Enter Room ID & Password', 'One-Click Publish/Hide', 'Auto Reveal 15 Min Before Match', 'Copy Room Info'],
      roles: ['SUPER_ADMIN', 'TOURNAMENT_ADMIN'],
    },
    {
      id: 'results',
      title: 'Results, Kills & Prize Distribution',
      hindiTitle: 'मैच परिणाम एवं विनिंग प्राइज क्रेडिट',
      description: 'Enter match rankings, kill points, and automatically disburse winning cash directly to player wallets.',
      category: 'rooms',
      icon: Award,
      accentColor: 'from-emerald-500/20 to-emerald-600/10 text-emerald-400 border-emerald-500/30',
      badge: 'AUTO CASH DISTRIBUTION',
      keyControls: ['Enter Player Kills & Rank', 'Auto Calculate Winnings', '1-Click Direct Wallet Payout', 'Declare Official Winners'],
      roles: ['SUPER_ADMIN', 'TOURNAMENT_ADMIN', 'RESULT_ADMIN'],
    },
    {
      id: 'leaderboard',
      title: 'Leaderboards & Top Champions',
      hindiTitle: 'लीडरबोर्ड एवं टॉप प्लेयर्स',
      description: 'Showcase top earners, highest kill records, MVP rankings, and season leaderboards to all users.',
      category: 'rooms',
      icon: BarChart3,
      accentColor: 'from-purple-500/20 to-purple-600/10 text-purple-400 border-purple-500/30',
      badge: 'RANKINGS & STATS',
      keyControls: ['Weekly/Monthly Rankings', 'Highest Kill Masters', 'Top Winning Players', 'Highlight MVP Profiles'],
      roles: ['SUPER_ADMIN', 'TOURNAMENT_ADMIN', 'RESULT_ADMIN'],
    },

    // FINANCE & GATEWAYS
    {
      id: 'settings',
      title: 'Admin Official UPI & QR Setup',
      hindiTitle: 'एडमिन UPI ID एवं QR कोड कंट्रोल',
      description: 'Set your official Admin UPI ID, VPA holder name, dynamic QR code generator, and deposit/withdrawal limits.',
      category: 'finance',
      icon: QrCode,
      accentColor: 'from-amber-500/20 to-amber-600/10 text-amber-400 border-amber-500/30',
      badge: 'PRIMARY UPI GATEWAY',
      keyControls: ['Set Admin UPI ID (VPA)', 'Account Holder Name', 'Live Auto Dynamic QR', 'Min/Max Deposit & Payout Limits'],
      roles: ['SUPER_ADMIN'],
    },
    {
      id: 'deposits',
      title: 'Deposit Requests & UTR Verification',
      hindiTitle: 'डिपॉजिट रिक्वेस्ट एवं UTR वेरिफिकेशन',
      description: 'Review manual UPI payment screenshots, 12-digit UTR numbers, and approve instant balance credits.',
      category: 'finance',
      icon: ArrowDownCircle,
      accentColor: 'from-emerald-500/20 to-emerald-600/10 text-emerald-400 border-emerald-500/30',
      badge: 'UTR AUDIT & APPROVE',
      keyControls: ['View Payment Screenshots', 'Verify 12-Digit UTR Number', '1-Click Approve & Credit Wallet', 'Reject Fake Requests'],
      roles: ['SUPER_ADMIN', 'PAYMENT_ADMIN'],
    },
    {
      id: 'withdrawals',
      title: 'Withdrawals & UPI Payouts',
      hindiTitle: 'विथड्रॉल रिक्वेस्ट एवं तुरंत भुगतान',
      description: 'Process player withdrawal requests to UPI / Bank, mark payouts completed, or reject with reason.',
      category: 'finance',
      icon: ArrowUpCircle,
      accentColor: 'from-rose-500/20 to-rose-600/10 text-rose-400 border-rose-500/30',
      badge: 'INSTANT PAYOUTS',
      keyControls: ['Pay to Player UPI ID', 'Bank Transfer Payouts', '1-Click Mark Completed', 'Reject & Auto-Refund'],
      roles: ['SUPER_ADMIN', 'PAYMENT_ADMIN'],
    },
    {
      id: 'wallet',
      title: 'User Wallets & Manual Balance Control',
      hindiTitle: 'यूजर वॉलेट एवं मैन्युअल बैलेंस एडिट',
      description: 'View any player wallet balance, manually add or deduct cash, freeze accounts, and inspect passbooks.',
      category: 'finance',
      icon: Wallet,
      accentColor: 'from-cyan-500/20 to-cyan-600/10 text-cyan-400 border-cyan-500/30',
      badge: 'MANUAL BALANCE ADJUST',
      keyControls: ['Manual Add Money (+₹)', 'Manual Deduct Money (-₹)', 'View Complete User Passbook', 'Wallet Audit Trail'],
      roles: ['SUPER_ADMIN', 'PAYMENT_ADMIN'],
    },
    {
      id: 'payments',
      title: 'Payment Gateway Logs',
      hindiTitle: 'पेमेंट गेटवे लॉग्स एवं स्टेट्स',
      description: 'Consolidated view of all incoming payments, gateway logs, and transaction status breakdown.',
      category: 'finance',
      icon: CreditCard,
      accentColor: 'from-indigo-500/20 to-indigo-600/10 text-indigo-400 border-indigo-500/30',
      badge: 'GATEWAY LOGS',
      keyControls: ['Filter by Payment Type', 'Verify Gateway Callback', 'Success/Failure Rate', 'Export Payment Excel/CSV'],
      roles: ['SUPER_ADMIN', 'PAYMENT_ADMIN'],
    },
    {
      id: 'transactions',
      title: 'Transactions Ledger & Audit',
      hindiTitle: 'सभी लेनदेन का वित्तीय लेजर',
      description: 'Global immutable ledger of all tournament entry deductions, winnings, refunds, and bonus distributions.',
      category: 'finance',
      icon: ReceiptText,
      accentColor: 'from-teal-500/20 to-teal-600/10 text-teal-400 border-teal-500/30',
      badge: 'FULL AUDIT LEDGER',
      keyControls: ['Search by Transaction ID', 'Filter Deposits vs Withdrawals', 'Trace Specific User Activity', 'Date Range Query'],
      roles: ['SUPER_ADMIN', 'PAYMENT_ADMIN'],
    },

    // PLAYERS & COMMUNITY
    {
      id: 'users',
      title: 'User & Player Management',
      hindiTitle: 'यूजर एवं प्लेयर अकाउंट कंट्रोल',
      description: 'Search registered players, inspect Free Fire UIDs, phone numbers, ban/unban cheaters, or verify profiles.',
      category: 'users',
      icon: UserCheck,
      accentColor: 'from-sky-500/20 to-sky-600/10 text-sky-400 border-sky-500/30',
      badge: 'PLAYER ACCOUNT CONTROL',
      keyControls: ['Search Player by Name/UID', 'Block / Unblock Accounts', 'Edit Player Details', 'View Match History'],
      roles: ['SUPER_ADMIN', 'SUPPORT_ADMIN'],
    },
    {
      id: 'coupons',
      title: 'Coupons & Promo Codes',
      hindiTitle: 'डिस्काउंट कूपन एवं प्रोमो कोड',
      description: 'Create discount vouchers for entry fees, flat rupee discounts, percentage off, and set usage limits.',
      category: 'users',
      icon: Tag,
      accentColor: 'from-pink-500/20 to-pink-600/10 text-pink-400 border-pink-500/30',
      badge: 'PROMO CODES',
      keyControls: ['Create New Promo Code', 'Set Flat ₹ or % Discount', 'Usage Limits per User', 'Expiry Dates'],
      roles: ['SUPER_ADMIN', 'PAYMENT_ADMIN', 'TOURNAMENT_ADMIN'],
    },
    {
      id: 'referrals',
      title: 'Refer & Earn System',
      hindiTitle: 'रेफरल प्रोग्राम एवं बोनस सेटिंग्स',
      description: 'Configure referral signup bonus amount, referrer cash rewards, and track successful player invitations.',
      category: 'users',
      icon: Share2,
      accentColor: 'from-emerald-500/20 to-emerald-600/10 text-emerald-400 border-emerald-500/30',
      badge: 'REFERRAL COMMISSION',
      keyControls: ['Set Referrer Reward (₹)', 'Set New User Welcome Bonus (₹)', 'Track Top Referrers', 'Toggle Referral Active'],
      roles: ['SUPER_ADMIN'],
    },
    {
      id: 'notifications',
      title: 'Broadcast Notifications & Alerts',
      hindiTitle: 'पुश नोटिफिकेशन एवं लाइव अनाउंसमेंट',
      description: 'Send instant broadcast alerts to all players regarding tournament registrations, room releases, or maintenance.',
      category: 'users',
      icon: Bell,
      accentColor: 'from-amber-500/20 to-amber-600/10 text-amber-400 border-amber-500/30',
      badge: 'LIVE PUSH ALERTS',
      keyControls: ['Send System Announcement', 'Target Specific Tournament Players', 'Set Priority Notice', 'Schedule Alerts'],
      roles: ['SUPER_ADMIN', 'SUPPORT_ADMIN', 'TOURNAMENT_ADMIN'],
    },
    {
      id: 'support',
      title: 'Live Support Tickets & Queries',
      hindiTitle: 'कस्टमर सपोर्ट टिकट्स एवं समाधान',
      description: 'Manage player help requests, resolve payment queries, answer game rules, and provide instant resolutions.',
      category: 'users',
      icon: HelpCircle,
      accentColor: 'from-violet-500/20 to-violet-600/10 text-violet-400 border-violet-500/30',
      badge: 'TICKET RESOLUTION',
      keyControls: ['Reply to User Tickets', 'Mark Resolved / Closed', 'Filter Pending Queries', 'Direct WhatsApp Routing'],
      roles: ['SUPER_ADMIN', 'SUPPORT_ADMIN'],
    },

    // CMS & PLATFORM
    {
      id: 'homepage',
      title: 'Homepage CMS & Featured Items',
      hindiTitle: 'होमपेज लेआउट एवं फीचर्स',
      description: 'Customize featured tournaments, highlight grand events, manage banners, and adjust homepage layout.',
      category: 'cms',
      icon: Globe,
      accentColor: 'from-cyan-500/20 to-cyan-600/10 text-cyan-400 border-cyan-500/30',
      badge: 'HOMEPAGE CMS',
      keyControls: ['Feature Top Tournaments', 'Banner Slide Orders', 'Notice Ticker Text', 'Hero Taglines'],
      roles: ['SUPER_ADMIN'],
    },
    {
      id: 'banners',
      title: 'Banners & Visual Announcements',
      hindiTitle: 'बैनर एवं प्रमोशनल ग्राफिक्स',
      description: 'Add, update, or toggle visual notice banners and promotional esports campaign graphics.',
      category: 'cms',
      icon: Sparkles,
      accentColor: 'from-fuchsia-500/20 to-fuchsia-600/10 text-fuchsia-400 border-fuchsia-500/30',
      badge: 'BANNER MANAGER',
      keyControls: ['Upload/Link Banners', 'Set Target Destination URLs', 'Enable / Disable Live Banner', 'Re-order Slides'],
      roles: ['SUPER_ADMIN'],
    },

    // SYSTEM & SECURITY
    {
      id: 'reports',
      title: 'Reports & Revenue Analytics',
      hindiTitle: 'वित्तीय रिपोर्ट्स एवं प्रॉफिट एनालिटिक्स',
      description: 'Analyze net platform revenue, total entry fees collected, total prize payouts, and user growth charts.',
      category: 'security',
      icon: FileSpreadsheet,
      accentColor: 'from-emerald-500/20 to-emerald-600/10 text-emerald-400 border-emerald-500/30',
      badge: 'FINANCIAL ANALYTICS',
      keyControls: ['Gross Tournament Revenue', 'Net Admin Commission', 'Monthly Payout Trends', 'Export Reports'],
      roles: ['SUPER_ADMIN', 'PAYMENT_ADMIN'],
    },
    {
      id: 'logs',
      title: 'Security & Admin Activity Logs',
      hindiTitle: 'सिस्टम ऑडिट एवं एडमिन एक्टिविटी लॉग्स',
      description: 'Complete immutable audit trail of every single admin action, wallet adjustment, room release, and status change.',
      category: 'security',
      icon: History,
      accentColor: 'from-slate-500/20 to-slate-600/10 text-slate-300 border-slate-500/30',
      badge: 'SECURITY AUDIT TRAIL',
      keyControls: ['Trace Admin Modifications', 'Timestamped Action Log', 'IP / Role Tracking', 'Security Inspection'],
      roles: ['SUPER_ADMIN'],
    },
    {
      id: 'admins',
      title: 'Admin Roles & Sub-Admin Staff',
      hindiTitle: 'एडमिन रोल्स एवं स्टाफ मैनेजमेंट',
      description: 'Add sub-admins, assign role permissions (Tournament Admin, Payment Admin, Result Admin, Support Admin).',
      category: 'security',
      icon: ShieldCheck,
      accentColor: 'from-amber-500/20 to-amber-600/10 text-amber-400 border-amber-500/30',
      badge: 'ROLE-BASED ACCESS',
      keyControls: ['Create Sub-Admin Accounts', 'Assign Specific Permissions', 'Deactivate Staff Access', 'Super Admin Override'],
      roles: ['SUPER_ADMIN'],
    },
  ];

  // Filter based on search & category & roles
  const filteredFeatures = features.filter((item) => {
    // Role check
    if (!isSuperAdmin && !item.roles.includes(role)) {
      return false;
    }
    // Category check
    if (selectedCategory !== 'all' && item.category !== selectedCategory) {
      return false;
    }
    // Search check
    if (searchTerm.trim() !== '') {
      const q = searchTerm.toLowerCase();
      const matchTitle = item.title.toLowerCase().includes(q);
      const matchHindi = item.hindiTitle.toLowerCase().includes(q);
      const matchDesc = item.description.toLowerCase().includes(q);
      const matchControls = item.keyControls.some((c) => c.toLowerCase().includes(q));
      return matchTitle || matchHindi || matchDesc || matchControls;
    }
    return true;
  });

  const categories = [
    { id: 'all', label: 'All Modules (24)', count: features.length },
    { id: 'esports', label: '🏆 Esports & Tournaments', count: features.filter((f) => f.category === 'esports').length },
    { id: 'finance', label: '💰 UPI, Wallets & Money', count: features.filter((f) => f.category === 'finance').length },
    { id: 'rooms', label: '🔑 Rooms & Results', count: features.filter((f) => f.category === 'rooms').length },
    { id: 'users', label: '👥 Players & Community', count: features.filter((f) => f.category === 'users').length },
    { id: 'cms', label: '🌐 CMS & Banners', count: features.filter((f) => f.category === 'cms').length },
    { id: 'security', label: '🛡️ Security & Admins', count: features.filter((f) => f.category === 'security').length },
  ];

  const handleSelect = (tab: ActiveTab) => {
    onSelectTab(tab);
    onClose();
  };

  return (
    <div
      id="admin-master-menu-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div
        id="admin-master-menu-dialog"
        className="w-full max-w-6xl max-h-[92vh] flex flex-col rounded-3xl bg-[#0F1115] border border-zinc-800 shadow-2xl overflow-hidden"
      >
        {/* Modal Top Header */}
        <div className="p-4 sm:p-6 border-b border-zinc-800/80 bg-zinc-950 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-600 to-amber-400 flex items-center justify-center text-zinc-950 font-black shadow-lg shadow-amber-500/20">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base sm:text-lg font-black text-white tracking-tight">
                    Admin Master Menu & Feature Controller
                  </h2>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
                    FULL ACCESS
                  </span>
                </div>
                <p className="text-xs text-zinc-400">
                  Direct access and 100% control over all tournament, money, UPI, rooms, and player modules.
                </p>
              </div>
            </div>

            <button
              id="btn-close-master-menu"
              onClick={onClose}
              className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-900 border border-zinc-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Action Shortcuts Bar */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs">
            <span className="text-[10px] uppercase font-bold text-zinc-500 shrink-0">Quick Jumps:</span>
            <button
              onClick={() => handleSelect('settings')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 whitespace-nowrap font-bold transition cursor-pointer"
            >
              <QrCode className="w-3.5 h-3.5" />
              <span>Set Admin UPI ID</span>
            </button>
            <button
              onClick={() => handleSelect('rooms')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-yellow-500/10 hover:bg-yellow-500/20 text-yellow-300 border border-yellow-500/30 whitespace-nowrap font-bold transition cursor-pointer"
            >
              <Radio className="w-3.5 h-3.5" />
              <span>Release Room ID & Pass</span>
            </button>
            <button
              onClick={() => handleSelect('tournaments')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700 whitespace-nowrap font-bold transition cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-amber-400" />
              <span>+ Create Tournament</span>
            </button>
            <button
              onClick={() => handleSelect('deposits')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 whitespace-nowrap font-bold transition cursor-pointer"
            >
              <ArrowDownCircle className="w-3.5 h-3.5" />
              <span>Verify Deposit UTRs</span>
            </button>
            <button
              onClick={() => handleSelect('withdrawals')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 whitespace-nowrap font-bold transition cursor-pointer"
            >
              <ArrowUpCircle className="w-3.5 h-3.5" />
              <span>Process Withdrawals</span>
            </button>
            <button
              onClick={() => handleSelect('wallet')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 whitespace-nowrap font-bold transition cursor-pointer"
            >
              <Wallet className="w-3.5 h-3.5" />
              <span>Adjust User Cash</span>
            </button>
          </div>

          {/* Search Bar & Category Filter Pills */}
          <div className="flex flex-col md:flex-row md:items-center gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search any admin feature (e.g. UPI, Room, Deposit, User Balance, Tournament, Results)..."
                className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-zinc-900 border border-zinc-800 text-xs text-white placeholder:text-zinc-500 focus:outline-none focus:border-amber-500 transition"
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white text-xs"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Category Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                    selectedCategory === cat.id
                      ? 'bg-amber-500 text-zinc-950 shadow-md shadow-amber-500/20'
                      : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Feature Cards Grid (Scrollable) */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredFeatures.map((item) => {
              const Icon = item.icon;
              const isCurrent = activeTab === item.id;

              return (
                <div
                  key={item.id}
                  id={`feature-card-${item.id}`}
                  onClick={() => handleSelect(item.id)}
                  className={`group p-5 rounded-2xl border transition duration-150 cursor-pointer flex flex-col justify-between ${
                    isCurrent
                      ? 'bg-zinc-900/90 border-amber-500/60 shadow-lg shadow-amber-500/10'
                      : 'bg-zinc-950/70 hover:bg-zinc-900/60 border-zinc-800/80 hover:border-zinc-700'
                  }`}
                >
                  <div className="space-y-3">
                    {/* Top Row: Icon + Badge */}
                    <div className="flex items-center justify-between">
                      <div
                        className={`w-11 h-11 rounded-xl flex items-center justify-center bg-gradient-to-br border ${item.accentColor}`}
                      >
                        <Icon className="w-5 h-5" />
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-zinc-900 text-zinc-300 border border-zinc-800">
                        {item.badge}
                      </span>
                    </div>

                    {/* Titles */}
                    <div>
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-black text-white group-hover:text-amber-400 transition">
                          {item.title}
                        </h3>
                        {isCurrent && (
                          <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded bg-amber-500 text-zinc-950">
                            ACTIVE
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] font-semibold text-amber-500/90 mt-0.5">
                        {item.hindiTitle}
                      </p>
                      <p className="text-xs text-zinc-400 mt-1 leading-relaxed line-clamp-2">
                        {item.description}
                      </p>
                    </div>

                    {/* Key Controls Bullets */}
                    <div className="pt-2 border-t border-zinc-900 space-y-1">
                      <p className="text-[10px] uppercase font-bold text-zinc-500">Includes:</p>
                      <div className="grid grid-cols-1 gap-1">
                        {item.keyControls.slice(0, 3).map((control, idx) => (
                          <div key={idx} className="flex items-center gap-1.5 text-[11px] text-zinc-300">
                            <span className="w-1 h-1 rounded-full bg-amber-400 shrink-0" />
                            <span className="truncate">{control}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Bottom Action Row */}
                  <div className="mt-4 pt-3 border-t border-zinc-800/60 flex items-center justify-between text-xs">
                    <span className="text-[11px] font-bold text-zinc-400 group-hover:text-white transition">
                      Launch Controller
                    </span>
                    <div className="w-7 h-7 rounded-lg bg-zinc-900 group-hover:bg-amber-500 group-hover:text-zinc-950 text-zinc-400 flex items-center justify-center transition shadow-sm">
                      <ChevronRight className="w-4 h-4" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredFeatures.length === 0 && (
            <div className="p-12 text-center rounded-2xl bg-zinc-950 border border-zinc-800 space-y-2">
              <Search className="w-8 h-8 text-zinc-600 mx-auto" />
              <p className="text-sm font-bold text-white">No matching admin features found</p>
              <p className="text-xs text-zinc-400">Try searching for keywords like "UPI", "Room", "Wallet", "Prize", or "Tournament".</p>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-zinc-800/80 bg-zinc-950 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-zinc-400">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Admin Mode: Every action persists instantly to live Cloud Firestore database.</span>
          </div>
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-5 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-white font-bold text-xs border border-zinc-700 transition cursor-pointer"
          >
            Close Menu
          </button>
        </div>
      </div>
    </div>
  );
};
