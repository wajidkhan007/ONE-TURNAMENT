import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  addDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  runTransaction,
  serverTimestamp,
  Timestamp,
} from 'firebase/firestore';
import { db } from '../firebase';
import {
  Tournament,
  Match,
  Registration,
  PaymentSubmission,
  UserWallet,
  WalletTransaction,
  WithdrawalRequest,
  DepositRequest,
  LeaderboardEntry,
  TournamentResult,
  AppUser,
  Coupon,
  ReferralSettings,
  ReferralRecord,
  NotificationItem,
  SupportTicket,
  WebsiteSettings,
  HomepageSettings,
  AdminUser,
  AdminLog,
  DashboardStats,
  AdminRole,
  Banner,
  MatchProof,
  PlayerSquad,
  VipSubscription,
} from '../types';

// Admin Activity Logger
export async function logAdminActivity(
  admin: { id: string; email: string; role: AdminRole },
  action: string,
  targetResource: string,
  description: string,
  targetId?: string,
  details?: Record<string, any>
): Promise<void> {
  try {
    const logsRef = collection(db, 'adminLogs');
    await addDoc(logsRef, {
      adminId: admin.id,
      adminEmail: admin.email,
      adminRole: admin.role,
      action,
      targetResource,
      targetId: targetId || '',
      description,
      details: details || {},
      timestamp: Date.now(),
    });
  } catch (error) {
    console.error('Error logging admin activity:', error);
  }
}

// ----------------------------------------------------
// DASHBOARD REAL STATISTICS (SYNC & REAL-TIME LISTENERS)
// ----------------------------------------------------
export function subscribeDashboardStats(callback: (stats: DashboardStats) => void): () => void {
  let usersList: any[] = [];
  let tournamentsList: Tournament[] = [];
  let registrationsList: Registration[] = [];
  let paymentsList: PaymentSubmission[] = [];
  let withdrawalsList: WithdrawalRequest[] = [];
  let depositsList: DepositRequest[] = [];
  let resultsList: TournamentResult[] = [];

  const recalculateAndNotify = () => {
    let upcomingTournaments = 0;
    let liveTournaments = 0;
    let completedTournaments = 0;

    tournamentsList.forEach((t) => {
      if (t.status === 'Registration Open' || t.status === 'Draft') upcomingTournaments++;
      else if (t.status === 'Live') liveTournaments++;
      else if (t.status === 'Completed') completedTournaments++;
    });

    let pendingRegistrations = 0;
    let approvedRegistrations = 0;
    let totalEntryFees = 0;

    registrationsList.forEach((r) => {
      if (r.status === 'Pending') pendingRegistrations++;
      if (r.status === 'Approved') {
        approvedRegistrations++;
        totalEntryFees += Number(r.paidAmount || r.entryFee || 0);
      }
    });

    let pendingPayments = 0;
    let approvedPayments = 0;
    paymentsList.forEach((p) => {
      if (p.status === 'Pending') pendingPayments++;
      if (p.status === 'Approved') approvedPayments++;
    });

    let pendingWithdrawals = 0;
    let totalWithdrawals = 0;
    withdrawalsList.forEach((w) => {
      if (w.status === 'Pending' || w.status === 'Processing') pendingWithdrawals++;
      if (w.status === 'Paid') {
        totalWithdrawals += Number(w.netAmount || w.requestedAmount || 0);
      }
    });

    let totalDeposits = 0;
    depositsList.forEach((d) => {
      if (d.status === 'Approved') {
        totalDeposits += Number(d.amount || 0);
      }
    });

    let totalPrizeDistributed = 0;
    resultsList.forEach((res) => {
      if (res.isPrizeCredited) {
        totalPrizeDistributed += Number(res.prizeMoney || 0);
      }
    });

    const totalRevenue = Math.max(0, totalEntryFees - totalPrizeDistributed);

    const stats: DashboardStats = {
      totalUsers: usersList.length,
      totalTournaments: tournamentsList.length,
      upcomingTournaments,
      liveTournaments,
      completedTournaments,
      totalRegistrations: registrationsList.length,
      pendingRegistrations,
      approvedRegistrations,
      pendingPayments,
      approvedPayments,
      pendingWithdrawals,
      totalDeposits,
      totalWithdrawals,
      totalEntryFees,
      totalPrizeDistributed,
      totalRevenue,
    };

    callback(stats);
  };

  const unsubUsers = onSnapshot(collection(db, 'users'), (snap) => {
    usersList = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    recalculateAndNotify();
  }, (err) => console.warn('Users listener:', err));

  const unsubTournaments = onSnapshot(collection(db, 'tournaments'), (snap) => {
    tournamentsList = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Tournament));
    recalculateAndNotify();
  }, (err) => console.warn('Tournaments listener:', err));

  const unsubRegs = onSnapshot(collection(db, 'registrations'), (snap) => {
    registrationsList = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Registration));
    recalculateAndNotify();
  }, (err) => console.warn('Registrations listener:', err));

  const unsubPayments = onSnapshot(collection(db, 'payments'), (snap) => {
    paymentsList = snap.docs.map((d) => ({ id: d.id, ...d.data() } as PaymentSubmission));
    recalculateAndNotify();
  }, (err) => console.warn('Payments listener:', err));

  const unsubWithdrawals = onSnapshot(collection(db, 'withdrawalRequests'), (snap) => {
    withdrawalsList = snap.docs.map((d) => ({ id: d.id, ...d.data() } as WithdrawalRequest));
    recalculateAndNotify();
  }, (err) => console.warn('Withdrawals listener:', err));

  const unsubDeposits = onSnapshot(collection(db, 'depositRequests'), (snap) => {
    depositsList = snap.docs.map((d) => ({ id: d.id, ...d.data() } as DepositRequest));
    recalculateAndNotify();
  }, (err) => console.warn('Deposits listener:', err));

  const unsubResults = onSnapshot(collection(db, 'results'), (snap) => {
    resultsList = snap.docs.map((d) => ({ id: d.id, ...d.data() } as TournamentResult));
    recalculateAndNotify();
  }, (err) => console.warn('Results listener:', err));

  return () => {
    unsubUsers();
    unsubTournaments();
    unsubRegs();
    unsubPayments();
    unsubWithdrawals();
    unsubDeposits();
    unsubResults();
  };
}

export async function fetchDashboardStats(): Promise<DashboardStats> {
  const stats: DashboardStats = {
    totalUsers: 0,
    totalTournaments: 0,
    upcomingTournaments: 0,
    liveTournaments: 0,
    completedTournaments: 0,
    totalRegistrations: 0,
    pendingRegistrations: 0,
    approvedRegistrations: 0,
    pendingPayments: 0,
    approvedPayments: 0,
    pendingWithdrawals: 0,
    totalDeposits: 0,
    totalWithdrawals: 0,
    totalEntryFees: 0,
    totalPrizeDistributed: 0,
    totalRevenue: 0,
  };

  try {
    // 1. Users
    const usersSnap = await getDocs(collection(db, 'users'));
    stats.totalUsers = usersSnap.size;

    // 2. Tournaments
    const tournamentsSnap = await getDocs(collection(db, 'tournaments'));
    stats.totalTournaments = tournamentsSnap.size;
    tournamentsSnap.forEach((d) => {
      const data = d.data() as Tournament;
      if (data.status === 'Registration Open' || data.status === 'Draft') {
        stats.upcomingTournaments++;
      } else if (data.status === 'Live') {
        stats.liveTournaments++;
      } else if (data.status === 'Completed') {
        stats.completedTournaments++;
      }
    });

    // 3. Registrations
    const regSnap = await getDocs(collection(db, 'registrations'));
    stats.totalRegistrations = regSnap.size;
    regSnap.forEach((d) => {
      const data = d.data() as Registration;
      if (data.status === 'Pending') stats.pendingRegistrations++;
      if (data.status === 'Approved') {
        stats.approvedRegistrations++;
        stats.totalEntryFees += Number(data.paidAmount || data.entryFee || 0);
      }
    });

    // 4. Payments
    const paySnap = await getDocs(collection(db, 'payments'));
    paySnap.forEach((d) => {
      const data = d.data() as PaymentSubmission;
      if (data.status === 'Pending') stats.pendingPayments++;
      if (data.status === 'Approved') stats.approvedPayments++;
    });

    // 5. Withdrawals
    const withSnap = await getDocs(collection(db, 'withdrawalRequests'));
    withSnap.forEach((d) => {
      const data = d.data() as WithdrawalRequest;
      if (data.status === 'Pending' || data.status === 'Processing') {
        stats.pendingWithdrawals++;
      }
      if (data.status === 'Paid') {
        stats.totalWithdrawals += Number(data.netAmount || data.requestedAmount || 0);
      }
    });

    // 6. Deposits
    const depSnap = await getDocs(collection(db, 'depositRequests'));
    depSnap.forEach((d) => {
      const data = d.data() as DepositRequest;
      if (data.status === 'Approved') {
        stats.totalDeposits += Number(data.amount || 0);
      }
    });

    // 7. Prize Distributed
    const resultsSnap = await getDocs(collection(db, 'results'));
    resultsSnap.forEach((d) => {
      const data = d.data() as TournamentResult;
      if (data.isPrizeCredited) {
        stats.totalPrizeDistributed += Number(data.prizeMoney || 0);
      }
    });

    // Revenue calculation: Total Entry Fees collected - Total Prize Distributed
    stats.totalRevenue = Math.max(0, stats.totalEntryFees - stats.totalPrizeDistributed);
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
  }

  return stats;
}

// ----------------------------------------------------
// TOURNAMENT MANAGEMENT
// ----------------------------------------------------
export async function getTournaments(): Promise<Tournament[]> {
  const snap = await getDocs(query(collection(db, 'tournaments'), orderBy('createdAt', 'desc')));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Tournament));
}

export async function saveTournament(tournament: Partial<Tournament>): Promise<string> {
  const now = Date.now();
  const cleanPayload: Record<string, any> = {};

  Object.entries(tournament).forEach(([key, value]) => {
    if (value !== undefined && key !== 'id') {
      cleanPayload[key] = value;
    }
  });

  if (tournament.id) {
    const docRef = doc(db, 'tournaments', tournament.id);
    await updateDoc(docRef, {
      ...cleanPayload,
      updatedAt: now,
    });
    return tournament.id;
  } else {
    const docRef = await addDoc(collection(db, 'tournaments'), {
      name: tournament.name || 'New Tournament',
      description: tournament.description || '',
      bannerUrl: tournament.bannerUrl || '',
      type: tournament.type || 'Solo',
      entryFee: Number(tournament.entryFee) || 0,
      prizePool: Number(tournament.prizePool) || 0,
      firstPrize: Number(tournament.firstPrize) || 0,
      secondPrize: Number(tournament.secondPrize) || 0,
      thirdPrize: Number(tournament.thirdPrize) || 0,
      perKillPrize: Number(tournament.perKillPrize) || 0,
      maxTeams: Number(tournament.maxTeams) || 48,
      currentRegistrations: Number(tournament.currentRegistrations) || 0,
      date: tournament.date || new Date().toISOString().split('T')[0],
      time: tournament.time || '18:00',
      registrationClosingTime: tournament.registrationClosingTime || '17:30',
      map: tournament.map || 'Bermuda',
      mode: tournament.mode || 'Battle Royale',
      matchCount: Number(tournament.matchCount) || 1,
      rules: tournament.rules || '1. Emulators not allowed\n2. Hackers will be banned\n3. Respect tournament timings.',
      status: tournament.status || 'Draft',
      isFeatured: tournament.isFeatured || false,
      createdAt: now,
      updatedAt: now,
      createdBy: tournament.createdBy || '',
      ...cleanPayload,
    });
    return docRef.id;
  }
}

export async function deleteTournament(id: string): Promise<void> {
  await deleteDoc(doc(db, 'tournaments', id));
}

// ----------------------------------------------------
// MATCH MANAGEMENT
// ----------------------------------------------------
export async function getMatches(tournamentId?: string): Promise<Match[]> {
  const q = tournamentId
    ? query(collection(db, 'matches'), where('tournamentId', '==', tournamentId), orderBy('matchNumber', 'asc'))
    : query(collection(db, 'matches'), orderBy('createdAt', 'desc'));
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Match));
}

export async function saveMatch(match: Partial<Match>): Promise<string> {
  const now = Date.now();
  if (match.id) {
    const docRef = doc(db, 'matches', match.id);
    await updateDoc(docRef, { ...match, updatedAt: now });
    return match.id;
  } else {
    const docRef = await addDoc(collection(db, 'matches'), {
      tournamentId: match.tournamentId || '',
      tournamentName: match.tournamentName || '',
      matchNumber: Number(match.matchNumber) || 1,
      matchDate: match.matchDate || new Date().toISOString().split('T')[0],
      matchTime: match.matchTime || '19:00',
      map: match.map || 'Bermuda',
      mode: match.mode || 'Battle Royale',
      roomId: match.roomId || '',
      roomPassword: match.roomPassword || '',
      isRoomPublished: match.isRoomPublished || false,
      status: match.status || 'Scheduled',
      notes: match.notes || '',
      createdAt: now,
      updatedAt: now,
    });
    return docRef.id;
  }
}

export async function deleteMatch(id: string): Promise<void> {
  await deleteDoc(doc(db, 'matches', id));
}

// ----------------------------------------------------
// REGISTRATION MANAGEMENT
// ----------------------------------------------------
export async function getRegistrations(tournamentId?: string): Promise<Registration[]> {
  const q = tournamentId
    ? query(collection(db, 'registrations'), where('tournamentId', '==', tournamentId), orderBy('registeredAt', 'desc'))
    : query(collection(db, 'registrations'), orderBy('registeredAt', 'desc'));
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Registration));
}

export async function updateRegistrationStatus(
  id: string,
  status: 'Approved' | 'Rejected',
  adminEmail: string,
  reason?: string
): Promise<void> {
  const docRef = doc(db, 'registrations', id);
  await updateDoc(docRef, {
    status,
    paymentStatus: status === 'Approved' ? 'Approved' : 'Rejected',
    approvedAt: Date.now(),
    approvedBy: adminEmail,
    rejectionReason: reason || '',
  });
}

export async function deleteRegistration(id: string): Promise<void> {
  await deleteDoc(doc(db, 'registrations', id));
}

// ----------------------------------------------------
// PAYMENT & DEPOSIT MANAGEMENT
// ----------------------------------------------------
export async function getPayments(): Promise<PaymentSubmission[]> {
  const snap = await getDocs(query(collection(db, 'payments'), orderBy('createdAt', 'desc')));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as PaymentSubmission));
}

export async function getDeposits(): Promise<DepositRequest[]> {
  const snap = await getDocs(query(collection(db, 'depositRequests'), orderBy('createdAt', 'desc')));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as DepositRequest));
}

export async function approveDeposit(
  depositId: string,
  admin: { id: string; email: string; role: AdminRole }
): Promise<void> {
  await runTransaction(db, async (transaction) => {
    const depRef = doc(db, 'depositRequests', depositId);
    const depSnap = await transaction.get(depRef);
    if (!depSnap.exists()) throw new Error('Deposit request not found');

    const deposit = depSnap.data() as DepositRequest;
    if (deposit.status === 'Approved') throw new Error('Deposit is already approved');

    const walletRef = doc(db, 'wallets', deposit.userId);
    const walletSnap = await transaction.get(walletRef);

    let prevBalance = 0;
    let newBalance = deposit.amount;
    let totalDeposited = deposit.amount;
    let totalWinnings = 0;
    let totalWithdrawn = 0;

    if (walletSnap.exists()) {
      const wallet = walletSnap.data() as UserWallet;
      prevBalance = Number(wallet.availableBalance || 0);
      newBalance = prevBalance + deposit.amount;
      totalDeposited = Number(wallet.totalDeposited || 0) + deposit.amount;
      totalWinnings = Number(wallet.totalWinnings || 0);
      totalWithdrawn = Number(wallet.totalWithdrawn || 0);
    }

    // 1. Update deposit status
    transaction.update(depRef, {
      status: 'Approved',
      processedAt: Date.now(),
      processedBy: admin.email,
    });

    // 2. Update wallet
    transaction.set(walletRef, {
      userId: deposit.userId,
      userEmail: deposit.userEmail,
      userName: deposit.userName || 'Player',
      availableBalance: newBalance,
      pendingBalance: 0,
      totalDeposited,
      totalWinnings,
      totalWithdrawn,
      updatedAt: Date.now(),
    });

    // 3. Create wallet transaction entry
    const txRef = doc(collection(db, 'walletTransactions'));
    transaction.set(txRef, {
      userId: deposit.userId,
      userEmail: deposit.userEmail,
      amount: deposit.amount,
      type: 'Deposit',
      previousBalance: prevBalance,
      newBalance,
      status: 'Completed',
      description: `Deposit via UPI/QR approved (UTR: ${deposit.utrNumber})`,
      referenceId: depositId,
      adminId: admin.id,
      adminEmail: admin.email,
      timestamp: Date.now(),
    });
  });
}

export async function rejectDeposit(
  depositId: string,
  reason: string,
  admin: { id: string; email: string; role: AdminRole }
): Promise<void> {
  const depRef = doc(db, 'depositRequests', depositId);
  await updateDoc(depRef, {
    status: 'Rejected',
    adminNote: reason,
    processedAt: Date.now(),
    processedBy: admin.email,
  });
}

// ----------------------------------------------------
// WALLET TRANSACTIONS & MANUAL ADJUSTMENT
// ----------------------------------------------------
export async function getWallets(): Promise<UserWallet[]> {
  const snap = await getDocs(collection(db, 'wallets'));
  return snap.docs.map((d) => ({ userId: d.id, ...d.data() } as UserWallet));
}

export async function getWalletTransactions(userId?: string): Promise<WalletTransaction[]> {
  const q = userId
    ? query(collection(db, 'walletTransactions'), where('userId', '==', userId), orderBy('timestamp', 'desc'))
    : query(collection(db, 'walletTransactions'), orderBy('timestamp', 'desc'), limit(100));
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as WalletTransaction));
}

export async function manualWalletAdjustment(
  userId: string,
  userEmail: string,
  amount: number,
  isCredit: boolean,
  reason: string,
  admin: { id: string; email: string; role: AdminRole }
): Promise<void> {
  if (!reason.trim()) throw new Error('A mandatory reason is required for wallet adjustments');
  if (amount <= 0) throw new Error('Amount must be greater than zero');

  await runTransaction(db, async (transaction) => {
    const walletRef = doc(db, 'wallets', userId);
    const walletSnap = await transaction.get(walletRef);

    let prevBalance = 0;
    let totalDeposited = 0;
    let totalWinnings = 0;
    let totalWithdrawn = 0;

    if (walletSnap.exists()) {
      const wallet = walletSnap.data() as UserWallet;
      prevBalance = Number(wallet.availableBalance || 0);
      totalDeposited = Number(wallet.totalDeposited || 0);
      totalWinnings = Number(wallet.totalWinnings || 0);
      totalWithdrawn = Number(wallet.totalWithdrawn || 0);
    }

    if (!isCredit && prevBalance < amount) {
      throw new Error(`Insufficient wallet balance. Current: ₹${prevBalance}, Requested Debit: ₹${amount}`);
    }

    const newBalance = isCredit ? prevBalance + amount : prevBalance - amount;

    transaction.set(
      walletRef,
      {
        userId,
        userEmail,
        userName: userEmail.split('@')[0],
        availableBalance: newBalance,
        totalDeposited,
        totalWinnings,
        totalWithdrawn,
        updatedAt: Date.now(),
      },
      { merge: true }
    );

    const txRef = doc(collection(db, 'walletTransactions'));
    transaction.set(txRef, {
      userId,
      userEmail,
      amount,
      type: 'Admin Adjustment',
      previousBalance: prevBalance,
      newBalance,
      status: 'Completed',
      description: `${isCredit ? 'Credit' : 'Debit'} Adjustment: ${reason}`,
      adminId: admin.id,
      adminEmail: admin.email,
      timestamp: Date.now(),
    });
  });
}

// ----------------------------------------------------
// REFUND SYSTEM
// ----------------------------------------------------
export async function issueRefund(
  userId: string,
  userEmail: string,
  amount: number,
  tournamentId: string,
  tournamentName: string,
  reason: string,
  admin: { id: string; email: string; role: AdminRole }
): Promise<void> {
  if (!reason.trim()) throw new Error('Reason is required for issuing a refund');

  await runTransaction(db, async (transaction) => {
    const walletRef = doc(db, 'wallets', userId);
    const walletSnap = await transaction.get(walletRef);

    let prevBalance = 0;
    if (walletSnap.exists()) {
      prevBalance = Number((walletSnap.data() as UserWallet).availableBalance || 0);
    }

    const newBalance = prevBalance + amount;

    transaction.set(
      walletRef,
      {
        userId,
        userEmail,
        availableBalance: newBalance,
        updatedAt: Date.now(),
      },
      { merge: true }
    );

    const txRef = doc(collection(db, 'walletTransactions'));
    transaction.set(txRef, {
      userId,
      userEmail,
      amount,
      type: 'Refund',
      previousBalance: prevBalance,
      newBalance,
      status: 'Completed',
      description: `Refund for tournament: ${tournamentName}. Reason: ${reason}`,
      tournamentId,
      tournamentName,
      adminId: admin.id,
      adminEmail: admin.email,
      timestamp: Date.now(),
    });
  });
}

// ----------------------------------------------------
// WITHDRAWAL MANAGEMENT
// ----------------------------------------------------
export async function getWithdrawals(): Promise<WithdrawalRequest[]> {
  const snap = await getDocs(query(collection(db, 'withdrawalRequests'), orderBy('createdAt', 'desc')));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as WithdrawalRequest));
}

export async function updateWithdrawalStatus(
  requestId: string,
  status: 'Pending' | 'Processing' | 'Approved' | 'Rejected' | 'Paid',
  admin: { id: string; email: string; role: AdminRole },
  note?: string,
  txRefId?: string
): Promise<void> {
  const docRef = doc(db, 'withdrawalRequests', requestId);

  if (status === 'Paid') {
    await runTransaction(db, async (transaction) => {
      // 1. ALL READS FIRST
      const withSnap = await transaction.get(docRef);
      if (!withSnap.exists()) throw new Error('Withdrawal request not found');
      const req = withSnap.data() as WithdrawalRequest;

      const walletRef = doc(db, 'wallets', req.userId);
      const walletSnap = await transaction.get(walletRef);

      // 2. ALL WRITES AFTER ALL READS ARE COMPLETE
      transaction.update(docRef, {
        status: 'Paid',
        adminNote: note || req.adminNote || '',
        transactionRef: txRefId || '',
        updatedAt: Date.now(),
        processedBy: admin.email,
      });

      let currentAvail = 0;
      if (walletSnap.exists()) {
        const wallet = walletSnap.data() as UserWallet;
        currentAvail = Number(wallet.availableBalance || 0);
        const totalWithdrawn = Number(wallet.totalWithdrawn || 0) + req.requestedAmount;
        const pendingBalance = Math.max(0, Number(wallet.pendingBalance || 0) - req.requestedAmount);
        transaction.update(walletRef, { totalWithdrawn, pendingBalance, updatedAt: Date.now() });
      }

      // Record wallet transaction entry
      const txRef = doc(collection(db, 'walletTransactions'));
      transaction.set(txRef, {
        userId: req.userId,
        userEmail: req.userEmail,
        amount: req.requestedAmount,
        type: 'Withdrawal',
        previousBalance: currentAvail,
        newBalance: currentAvail,
        status: 'Completed',
        description: `Withdrawal paid to ${req.payoutMethod} (Ref: ${txRefId || 'N/A'})`,
        referenceId: requestId,
        adminId: admin.id,
        adminEmail: admin.email,
        timestamp: Date.now(),
      });
    });
  } else if (status === 'Rejected') {
    // If rejected, refund the pending balance back to available balance
    await runTransaction(db, async (transaction) => {
      // 1. ALL READS FIRST
      const withSnap = await transaction.get(docRef);
      if (!withSnap.exists()) throw new Error('Withdrawal request not found');
      const req = withSnap.data() as WithdrawalRequest;

      const walletRef = doc(db, 'wallets', req.userId);
      const walletSnap = await transaction.get(walletRef);

      // 2. ALL WRITES AFTER ALL READS
      transaction.update(docRef, {
        status: 'Rejected',
        adminNote: note || 'Withdrawal rejected',
        updatedAt: Date.now(),
        processedBy: admin.email,
      });

      let currentAvail = 0;
      if (walletSnap.exists()) {
        const wallet = walletSnap.data() as UserWallet;
        currentAvail = Number(wallet.availableBalance || 0);
        const availableBalance = currentAvail + req.requestedAmount;
        const pendingBalance = Math.max(0, Number(wallet.pendingBalance || 0) - req.requestedAmount);
        transaction.update(walletRef, { availableBalance, pendingBalance, updatedAt: Date.now() });
      }

      const txRef = doc(collection(db, 'walletTransactions'));
      transaction.set(txRef, {
        userId: req.userId,
        userEmail: req.userEmail,
        amount: req.requestedAmount,
        type: 'Refund',
        previousBalance: currentAvail,
        newBalance: currentAvail + req.requestedAmount,
        status: 'Completed',
        description: `Refund for rejected withdrawal. Reason: ${note || 'Admin rejected'}`,
        referenceId: requestId,
        adminId: admin.id,
        adminEmail: admin.email,
        timestamp: Date.now(),
      });
    });
  } else {
    await updateDoc(docRef, {
      status,
      adminNote: note || '',
      updatedAt: Date.now(),
      processedBy: admin.email,
    });
  }
}

// ----------------------------------------------------
// WINNINGS & PRIZE DISTRIBUTION
// ----------------------------------------------------
export async function creditTournamentPrize(
  resultId: string,
  userEmailOrUserId: string,
  prizeAmount: number,
  tournamentNameOrTournamentId: string,
  admin: { id: string; email: string; role: AdminRole },
  userIdParam?: string,
  tournamentIdParam?: string,
  rankParam?: number
): Promise<void> {
  if (prizeAmount <= 0) throw new Error('Prize amount must be greater than zero');

  const userEmail = userEmailOrUserId.includes('@') ? userEmailOrUserId : '';
  const userId = userIdParam || (userEmail ? userEmail.replace(/[^a-zA-Z0-9]/g, '_') : userEmailOrUserId);
  const tournamentName = tournamentNameOrTournamentId;
  const tournamentId = tournamentIdParam || '';
  const rank = rankParam || 1;

  await runTransaction(db, async (transaction) => {
    const resultRef = doc(db, 'results', resultId);
    const resultSnap = await transaction.get(resultRef);

    if (resultSnap.exists()) {
      const resData = resultSnap.data() as TournamentResult;
      if (resData.isPrizeCredited) {
        throw new Error('Prize money has already been credited for this result!');
      }
    }

    const walletRef = doc(db, 'wallets', userId);
    const walletSnap = await transaction.get(walletRef);

    let prevBalance = 0;
    let totalWinnings = 0;
    if (walletSnap.exists()) {
      const wallet = walletSnap.data() as UserWallet;
      prevBalance = Number(wallet.availableBalance || 0);
      totalWinnings = Number(wallet.totalWinnings || 0) + prizeAmount;
    } else {
      totalWinnings = prizeAmount;
    }

    const newBalance = prevBalance + prizeAmount;

    // 1. Update wallet
    transaction.set(
      walletRef,
      {
        userId,
        userEmail: userEmail || `${userId}@user.com`,
        userName: (userEmail || userId).split('@')[0],
        availableBalance: newBalance,
        totalWinnings,
        updatedAt: Date.now(),
      },
      { merge: true }
    );

    // 2. Mark prize as credited in result
    if (resultSnap.exists()) {
      transaction.update(resultRef, {
        isPrizeCredited: true,
        creditedAt: Date.now(),
        creditedBy: admin.email,
      });
    }

    // 3. Create wallet transaction
    const txRef = doc(collection(db, 'walletTransactions'));
    transaction.set(txRef, {
      userId,
      userEmail: userEmail || `${userId}@user.com`,
      amount: prizeAmount,
      type: 'Winnings',
      previousBalance: prevBalance,
      newBalance,
      status: 'Completed',
      description: `Prize for Rank #${rank} in ${tournamentName}`,
      tournamentId,
      tournamentName,
      referenceId: resultId,
      adminId: admin.id,
      adminEmail: admin.email,
      timestamp: Date.now(),
    });
  });
}

// ----------------------------------------------------
// LEADERBOARDS & RESULTS
// ----------------------------------------------------
export async function getLeaderboards(tournamentId?: string): Promise<LeaderboardEntry[]> {
  const q = tournamentId
    ? query(collection(db, 'leaderboards'), where('tournamentId', '==', tournamentId), orderBy('rank', 'asc'))
    : query(collection(db, 'leaderboards'), orderBy('updatedAt', 'desc'));
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as LeaderboardEntry));
}

export async function saveLeaderboardEntry(entry: Partial<LeaderboardEntry>): Promise<string> {
  const now = Date.now();
  const killPoints = (Number(entry.kills) || 0) * 1; // 1 pt per kill standard FF
  const totalPoints = (Number(entry.placementPoints) || 0) + killPoints;

  if (entry.id) {
    const docRef = doc(db, 'leaderboards', entry.id);
    await updateDoc(docRef, {
      ...entry,
      killPoints,
      totalPoints,
      updatedAt: now,
    });
    return entry.id;
  } else {
    const docRef = await addDoc(collection(db, 'leaderboards'), {
      tournamentId: entry.tournamentId || '',
      matchId: entry.matchId || '',
      matchNumber: Number(entry.matchNumber) || 1,
      rank: Number(entry.rank) || 1,
      teamName: entry.teamName || '',
      playerNames: entry.playerNames || [],
      captainFfUid: entry.captainFfUid || '',
      kills: Number(entry.kills) || 0,
      killPoints,
      placementPoints: Number(entry.placementPoints) || 0,
      totalPoints,
      prizeAmount: Number(entry.prizeAmount) || 0,
      isPublished: entry.isPublished || false,
      updatedAt: now,
    });
    return docRef.id;
  }
}

export async function deleteLeaderboardEntry(id: string): Promise<void> {
  await deleteDoc(doc(db, 'leaderboards', id));
}

export async function getResults(tournamentId?: string): Promise<TournamentResult[]> {
  const q = tournamentId
    ? query(collection(db, 'results'), where('tournamentId', '==', tournamentId), orderBy('rank', 'asc'))
    : query(collection(db, 'results'), orderBy('updatedAt', 'desc'));
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as TournamentResult));
}

export async function saveResult(result: Partial<TournamentResult>): Promise<string> {
  const now = Date.now();
  if (result.id) {
    const docRef = doc(db, 'results', result.id);
    await updateDoc(docRef, { ...result, updatedAt: now });
    return result.id;
  } else {
    const docRef = await addDoc(collection(db, 'results'), {
      tournamentId: result.tournamentId || '',
      tournamentName: result.tournamentName || '',
      rank: Number(result.rank) || 1,
      teamName: result.teamName || '',
      captainName: result.captainName || '',
      captainEmail: result.captainEmail || '',
      captainFfUid: result.captainFfUid || '',
      players: result.players || [],
      totalKills: Number(result.totalKills) || 0,
      totalPoints: Number(result.totalPoints) || 0,
      prizeMoney: Number(result.prizeMoney) || 0,
      isPrizeCredited: false,
      isPublished: result.isPublished || false,
      updatedAt: now,
    });
    return docRef.id;
  }
}

export async function deleteResult(id: string): Promise<void> {
  await deleteDoc(doc(db, 'results', id));
}

export const getTournamentResults = getResults;
export const saveTournamentResult = saveResult;
export const deleteTournamentResult = deleteResult;

// ----------------------------------------------------
// USER MANAGEMENT
// ----------------------------------------------------
export async function getUsers(): Promise<AppUser[]> {
  const snap = await getDocs(query(collection(db, 'users'), orderBy('createdAt', 'desc')));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as AppUser));
}

export async function toggleUserStatus(userId: string, statusOrActive: boolean | string): Promise<void> {
  const docRef = doc(db, 'users', userId);
  const isActive = typeof statusOrActive === 'boolean' ? statusOrActive : statusOrActive !== 'Banned';
  const status = typeof statusOrActive === 'string' ? statusOrActive : (statusOrActive ? 'Active' : 'Banned');
  await updateDoc(docRef, { isActive, status, updatedAt: Date.now() });
}

export async function updateUserRole(userId: string, role: string): Promise<void> {
  const docRef = doc(db, 'users', userId);
  await updateDoc(docRef, { role, updatedAt: Date.now() });
}

// ----------------------------------------------------
// BANNERS
// ----------------------------------------------------
export async function getBanners(): Promise<Banner[]> {
  const snap = await getDocs(query(collection(db, 'banners'), orderBy('order', 'asc')));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Banner));
}

export async function saveBanner(banner: Partial<Banner>): Promise<string> {
  const now = Date.now();
  if (banner.id) {
    const docRef = doc(db, 'banners', banner.id);
    await updateDoc(docRef, { ...banner, updatedAt: now });
    return banner.id;
  } else {
    const docRef = await addDoc(collection(db, 'banners'), {
      title: banner.title || '',
      imageUrl: banner.imageUrl || '',
      linkUrl: banner.linkUrl || '',
      isActive: banner.isActive !== false,
      order: Number(banner.order) || 0,
      createdAt: now,
    });
    return docRef.id;
  }
}

export async function deleteBanner(id: string): Promise<void> {
  await deleteDoc(doc(db, 'banners', id));
}

// ----------------------------------------------------
// COUPONS
// ----------------------------------------------------
export async function getCoupons(): Promise<Coupon[]> {
  const snap = await getDocs(query(collection(db, 'coupons'), orderBy('createdAt', 'desc')));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Coupon));
}

export async function saveCoupon(coupon: Partial<Coupon>): Promise<string> {
  const now = Date.now();
  if (coupon.id) {
    const docRef = doc(db, 'coupons', coupon.id);
    await updateDoc(docRef, coupon);
    return coupon.id;
  } else {
    const docRef = await addDoc(collection(db, 'coupons'), {
      code: (coupon.code || '').toUpperCase().trim(),
      discountType: coupon.discountType || 'PERCENTAGE',
      discountAmount: Number(coupon.discountAmount) || 10,
      minEntryFee: Number(coupon.minEntryFee) || 0,
      maxDiscount: Number(coupon.maxDiscount) || 50,
      expiryDate: coupon.expiryDate || new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
      maxUses: Number(coupon.maxUses) || 100,
      usedCount: 0,
      tournamentId: coupon.tournamentId || '',
      tournamentName: coupon.tournamentName || '',
      status: coupon.status || 'Active',
      createdAt: now,
    });
    return docRef.id;
  }
}

export async function deleteCoupon(id: string): Promise<void> {
  await deleteDoc(doc(db, 'coupons', id));
}

// ----------------------------------------------------
// REFERRALS
// ----------------------------------------------------
export async function getReferralSettings(): Promise<ReferralSettings> {
  const docRef = doc(db, 'websiteSettings', 'referrals');
  const snap = await getDoc(docRef);
  if (snap.exists()) {
    return snap.data() as ReferralSettings;
  }
  return {
    isEnabled: true,
    rewardPerReferral: 10,
    minDepositRequired: 50,
    rules: 'Refer a friend. When they register and make their first deposit of ₹50 or more, you both get ₹10 bonus in your wallet.',
    updatedAt: Date.now(),
  };
}

export async function saveReferralSettings(settings: ReferralSettings): Promise<void> {
  const docRef = doc(db, 'websiteSettings', 'referrals');
  await setDoc(docRef, { ...settings, updatedAt: Date.now() }, { merge: true });
}

export async function getReferralRecords(): Promise<ReferralRecord[]> {
  const snap = await getDocs(query(collection(db, 'referrals'), orderBy('createdAt', 'desc')));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as ReferralRecord));
}

// ----------------------------------------------------
// NOTIFICATIONS
// ----------------------------------------------------
export async function getNotifications(): Promise<NotificationItem[]> {
  const snap = await getDocs(query(collection(db, 'notifications'), orderBy('createdAt', 'desc')));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as NotificationItem));
}

export async function sendNotification(notif: Partial<NotificationItem>): Promise<string> {
  const now = Date.now();
  const docRef = await addDoc(collection(db, 'notifications'), {
    title: notif.title || '',
    message: notif.message || '',
    type: notif.type || 'Announcement',
    targetAudience: notif.targetAudience || 'ALL',
    targetUserId: notif.targetUserId || '',
    targetTournamentId: notif.targetTournamentId || '',
    isPublished: true,
    createdAt: now,
    createdBy: notif.createdBy || '',
  });
  return docRef.id;
}

export async function deleteNotification(id: string): Promise<void> {
  await deleteDoc(doc(db, 'notifications', id));
}

// ----------------------------------------------------
// SUPPORT TICKETS
// ----------------------------------------------------
export async function getSupportTickets(): Promise<SupportTicket[]> {
  const snap = await getDocs(query(collection(db, 'supportTickets'), orderBy('updatedAt', 'desc')));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as SupportTicket));
}

export async function addTicketReply(
  ticketId: string,
  reply: { senderEmail?: string; senderId?: string; senderRole?: 'USER' | 'ADMIN'; message: string; senderName?: string }
): Promise<void> {
  const docRef = doc(db, 'supportTickets', ticketId);
  const snap = await getDoc(docRef);
  if (!snap.exists()) throw new Error('Ticket not found');

  const ticket = snap.data() as SupportTicket;
  const messages = ticket.messages || [];

  messages.push({
    id: 'msg_' + Date.now(),
    senderId: reply.senderId || reply.senderEmail || 'admin',
    senderName: reply.senderName || (reply.senderEmail ? reply.senderEmail.split('@')[0] : 'Admin'),
    senderRole: reply.senderRole || 'ADMIN',
    message: reply.message,
    createdAt: Date.now(),
  });

  await updateDoc(docRef, {
    messages,
    updatedAt: Date.now(),
  });
}

export async function replySupportTicket(
  ticketId: string,
  messageText: string,
  admin: { id: string; email: string; role: AdminRole },
  newStatus?: 'In Progress' | 'Resolved' | 'Closed'
): Promise<void> {
  const docRef = doc(db, 'supportTickets', ticketId);
  const snap = await getDoc(docRef);
  if (!snap.exists()) throw new Error('Ticket not found');

  const ticket = snap.data() as SupportTicket;
  const messages = ticket.messages || [];

  messages.push({
    id: 'msg_' + Date.now(),
    senderId: admin.id,
    senderName: 'Admin (' + admin.email.split('@')[0] + ')',
    senderRole: 'ADMIN',
    message: messageText,
    createdAt: Date.now(),
  });

  await updateDoc(docRef, {
    messages,
    status: newStatus || ticket.status,
    updatedAt: Date.now(),
    assignedToAdminId: admin.id,
    assignedToAdminName: admin.email,
  });
}

export async function updateTicketStatus(
  ticketId: string,
  status: 'Open' | 'In Progress' | 'Resolved' | 'Closed'
): Promise<void> {
  const docRef = doc(db, 'supportTickets', ticketId);
  await updateDoc(docRef, { status, updatedAt: Date.now() });
}

// ----------------------------------------------------
// WEBSITE & HOMEPAGE SETTINGS
// ----------------------------------------------------
export function subscribeWebsiteSettings(callback: (settings: WebsiteSettings) => void): () => void {
  const docRef = doc(db, 'websiteSettings', 'general');
  return onSnapshot(
    docRef,
    (snap) => {
      if (snap.exists()) {
        const data = snap.data() as WebsiteSettings;
        if (!data.upiId || data.upiId === '9991522138@ybl') {
          data.upiId = '9991522138-2@ybl';
        }
        callback(data);
      } else {
        callback({
          id: 'general',
          websiteName: 'FF TOURNAMENT',
          tagline: 'India’s Premier Free Fire Esports Platform',
          logoUrl: '',
          faviconUrl: '',
          contactGmail: 'wajidwajidkhan203@gmail.com',
          instagramHandle: '@wsk_khan_1010',
          whatsAppNumber: '+91 9876543210',
          supportPhone: '+91 9876543210',
          footerText: '© 2026 FF TOURNAMENT. All rights reserved. Free Fire is a registered trademark of Garena.',
          aboutText: 'FF TOURNAMENT is a premier platform organizing competitive Free Fire Battle Royale, Clash Squad, and Custom tournaments with real instant wallet payouts.',
          rulesText: '1. Emulators and PC players are strictly prohibited unless specified.\n2. Any form of hacking or scripting will result in permanent device ban.\n3. Room ID & Password will be revealed 15 minutes prior to match time.\n4. Screenshots of final kill counts and rankings must be submitted if requested.',
          faqList: [
            { question: 'How do I join a tournament?', answer: 'Select a tournament, click Register, add your team UID and pay using Wallet, UPI, or QR.' },
            { question: 'When will I get Room ID & Password?', answer: 'Room credentials appear in your registered tournament tab 15 minutes before match start.' },
            { question: 'How do withdrawals work?', answer: 'Request a withdrawal to UPI or Bank. Our admin processes payouts within 30-60 minutes.' },
          ],
          termsText: 'By participating in FF TOURNAMENT, players agree to follow fair play guidelines, abide by admin decisions, and verify their game UIDs.',
          privacyPolicyText: 'We protect user data including phone numbers, UIDs, and payment identifiers with enterprise-grade encryption.',
          isUpiEnabled: true,
          upiId: '9991522138-2@ybl',
          upiAccountHolder: 'FF Tournament Official',
          isQrEnabled: true,
          qrCodeUrl: '',
          paymentInstructions: '1. Scan the QR code or copy the UPI ID.\n2. Pay exact registration fee.\n3. Enter the 12-digit UTR/Reference number.\n4. Upload payment screenshot for instant approval.',
          updatedAt: Date.now(),
        });
      }
    },
    (err) => {
      console.warn('subscribeWebsiteSettings listener notice:', err);
    }
  );
}

export async function getWebsiteSettings(): Promise<WebsiteSettings> {
  const docRef = doc(db, 'websiteSettings', 'general');
  const snap = await getDoc(docRef);
  if (snap.exists()) {
    const data = snap.data() as WebsiteSettings;
    if (!data.upiId || data.upiId === '9991522138@ybl') {
      data.upiId = '9991522138-2@ybl';
      saveWebsiteSettings(data).catch((err) => console.warn('Auto upi migration notice:', err));
    }
    return data;
  }
  return {
    id: 'general',
    websiteName: 'FF TOURNAMENT',
    tagline: 'India’s Premier Free Fire Esports Platform',
    logoUrl: '',
    faviconUrl: '',
    contactGmail: 'wajidwajidkhan203@gmail.com',
    instagramHandle: '@wsk_khan_1010',
    whatsAppNumber: '+91 9876543210',
    supportPhone: '+91 9876543210',
    footerText: '© 2026 FF TOURNAMENT. All rights reserved. Free Fire is a registered trademark of Garena.',
    aboutText: 'FF TOURNAMENT is a premier platform organizing competitive Free Fire Battle Royale, Clash Squad, and Custom tournaments with real instant wallet payouts.',
    rulesText: '1. Emulators and PC players are strictly prohibited unless specified.\n2. Any form of hacking or scripting will result in permanent device ban.\n3. Room ID & Password will be revealed 15 minutes prior to match time.\n4. Screenshots of final kill counts and rankings must be submitted if requested.',
    faqList: [
      { question: 'How do I join a tournament?', answer: 'Select a tournament, click Register, add your team UID and pay using Wallet, UPI, or QR.' },
      { question: 'When will I get Room ID & Password?', answer: 'Room credentials appear in your registered tournament tab 15 minutes before match start.' },
      { question: 'How do withdrawals work?', answer: 'Request a withdrawal to UPI or Bank. Our admin processes payouts within 30-60 minutes.' },
    ],
    termsText: 'By participating in FF TOURNAMENT, players agree to follow fair play guidelines, abide by admin decisions, and verify their game UIDs.',
    privacyPolicyText: 'We protect user data including phone numbers, UIDs, and payment identifiers with enterprise-grade encryption.',
    isUpiEnabled: true,
    upiId: '9991522138-2@ybl',
    upiAccountHolder: 'FF Tournament Official',
    isQrEnabled: true,
    qrCodeUrl: '',
    paymentInstructions: '1. Scan the QR code or copy the UPI ID.\n2. Pay exact registration fee.\n3. Enter the 12-digit UTR/Reference number.\n4. Upload payment screenshot for instant approval.',
    updatedAt: Date.now(),
  };
}

export async function saveWebsiteSettings(settings: WebsiteSettings): Promise<void> {
  const docRef = doc(db, 'websiteSettings', 'general');
  await setDoc(docRef, { ...settings, updatedAt: Date.now() }, { merge: true });
}

export async function getHomepageSettings(): Promise<HomepageSettings> {
  const docRef = doc(db, 'homepageSettings', 'main');
  const snap = await getDoc(docRef);
  if (snap.exists()) {
    return snap.data() as HomepageSettings;
  }
  return {
    id: 'main',
    heroHeadline: 'DOMINATE THE BATTLEGROUND',
    heroSubheadline: 'Join daily Free Fire Solo, Duo & Squad tournaments. Win real cash prizes and climb the official leaderboards.',
    heroBannerUrl: '',
    ctaButtonText: 'Join Tournament Now',
    ctaButtonLink: '#tournaments',
    featuredTournamentIds: [],
    showUpcomingSection: true,
    showLiveSection: true,
    showCompletedSection: true,
    showLeaderboardPreview: true,
    promotionalBanners: [],
    updatedAt: Date.now(),
  };
}

export async function saveHomepageSettings(settings: HomepageSettings): Promise<void> {
  const docRef = doc(db, 'homepageSettings', 'main');
  await setDoc(docRef, { ...settings, updatedAt: Date.now() }, { merge: true });
}

// ----------------------------------------------------
// ADMIN USERS & LOGS
// ----------------------------------------------------
export async function getAdminUsers(): Promise<AdminUser[]> {
  const snap = await getDocs(query(collection(db, 'adminUsers'), orderBy('createdAt', 'desc')));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as AdminUser));
}

export async function saveAdminUser(admin: Partial<AdminUser>): Promise<string> {
  const now = Date.now();
  if (admin.id) {
    const docRef = doc(db, 'adminUsers', admin.id);
    await setDoc(docRef, { ...admin, updatedAt: now }, { merge: true });
    return admin.id;
  } else {
    const docRef = await addDoc(collection(db, 'adminUsers'), {
      email: admin.email || '',
      name: admin.name || (admin.email ? admin.email.split('@')[0] : 'Admin'),
      role: admin.role || 'TOURNAMENT_ADMIN',
      isActive: admin.isActive !== false,
      createdAt: now,
      createdBy: admin.createdBy || '',
    });
    return docRef.id;
  }
}

export async function deleteAdminUser(adminId: string): Promise<void> {
  await deleteDoc(doc(db, 'adminUsers', adminId));
}

export async function getAdminLogs(): Promise<AdminLog[]> {
  const snap = await getDocs(query(collection(db, 'adminLogs'), orderBy('timestamp', 'desc'), limit(150)));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as AdminLog));
}

// ----------------------------------------------------
// REAL-TIME SUBSCRIBERS FOR APP & ADMIN
// ----------------------------------------------------
export function subscribeTournaments(callback: (tournaments: Tournament[]) => void): () => void {
  return onSnapshot(query(collection(db, 'tournaments'), orderBy('createdAt', 'desc')), (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Tournament)));
  }, (err) => console.warn('Tournaments snapshot:', err));
}

export function subscribeMatches(callback: (matches: Match[]) => void): () => void {
  return onSnapshot(query(collection(db, 'matches'), orderBy('matchDate', 'asc')), (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Match)));
  }, (err) => console.warn('Matches snapshot:', err));
}

export function subscribeBanners(callback: (banners: Banner[]) => void): () => void {
  return onSnapshot(query(collection(db, 'banners'), orderBy('order', 'asc')), (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Banner)));
  }, (err) => console.warn('Banners snapshot:', err));
}

export function subscribeUserWallet(userId: string, callback: (wallet: UserWallet | null) => void): () => void {
  return onSnapshot(doc(db, 'wallets', userId), (snap) => {
    if (snap.exists()) {
      callback({ userId: snap.id, ...snap.data() } as UserWallet);
    } else {
      callback({
        userId,
        userEmail: '',
        userName: '',
        availableBalance: 0,
        pendingBalance: 0,
        totalDeposited: 0,
        totalWithdrawn: 0,
        totalWinnings: 0,
        updatedAt: Date.now(),
      });
    }
  }, (err) => console.warn('User wallet snapshot:', err));
}

export function subscribeUserRegistrations(userId: string, callback: (regs: Registration[]) => void): () => void {
  return onSnapshot(query(collection(db, 'registrations'), where('userId', '==', userId)), (snap) => {
    const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Registration));
    list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    callback(list);
  }, (err) => console.warn('User regs snapshot:', err));
}

export function subscribeUserWalletTransactions(userId: string, callback: (txs: WalletTransaction[]) => void): () => void {
  return onSnapshot(query(collection(db, 'walletTransactions'), where('userId', '==', userId)), (snap) => {
    const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as WalletTransaction));
    list.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
    callback(list);
  }, (err) => console.warn('User txs snapshot:', err));
}

export function subscribeUserSupportTickets(userId: string, callback: (tickets: SupportTicket[]) => void): () => void {
  return onSnapshot(query(collection(db, 'supportTickets'), where('userId', '==', userId)), (snap) => {
    const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as SupportTicket));
    list.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    callback(list);
  }, (err) => console.warn('User tickets snapshot:', err));
}

export function subscribeDeposits(callback: (deposits: DepositRequest[]) => void): () => void {
  return onSnapshot(query(collection(db, 'depositRequests'), orderBy('createdAt', 'desc')), (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() } as DepositRequest)));
  }, (err) => console.warn('Deposits snapshot:', err));
}

export function subscribeWithdrawals(callback: (withdrawals: WithdrawalRequest[]) => void): () => void {
  return onSnapshot(query(collection(db, 'withdrawalRequests'), orderBy('createdAt', 'desc')), (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() } as WithdrawalRequest)));
  }, (err) => console.warn('Withdrawals snapshot:', err));
}

export function subscribeRegistrations(callback: (registrations: Registration[]) => void): () => void {
  return onSnapshot(query(collection(db, 'registrations'), orderBy('createdAt', 'desc')), (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Registration)));
  }, (err) => console.warn('Registrations snapshot:', err));
}

// ----------------------------------------------------
// PLAYER ACTIONS (TOURNAMENT JOIN, WALLET DEPOSIT & WITHDRAWAL)
// ----------------------------------------------------
export async function playerJoinTournament(params: {
  tournamentId: string;
  tournamentName: string;
  userId: string;
  userEmail: string;
  teamName: string;
  players: { name: string; ign: string; ffUid: string; isLeader?: boolean }[];
  entryFee: number;
  discountAmount?: number;
  couponCode?: string;
}): Promise<string> {
  const actualFee = Math.max(0, params.entryFee - (params.discountAmount || 0));

  let regId = '';

  await runTransaction(db, async (transaction) => {
    // 0. Check duplicate registration for this user in this tournament using deterministic document ID
    const regDocId = `${params.tournamentId}_${params.userId}`;
    const regRef = doc(db, 'registrations', regDocId);
    const existingRegSnap = await transaction.get(regRef);

    if (existingRegSnap.exists()) {
      const existingData = existingRegSnap.data() as Registration;
      if (existingData.status !== 'Rejected') {
        throw new Error('Aapne is tournament me pehle se hi join kar liya hai! (Already Joined)');
      }
    }

    // 1. Check tournament capacity & status
    const tourneyRef = doc(db, 'tournaments', params.tournamentId);
    const tourneySnap = await transaction.get(tourneyRef);
    if (!tourneySnap.exists()) throw new Error('Tournament not found');
    const tourney = tourneySnap.data() as Tournament;

    if (tourney.status !== 'Registration Open' && tourney.status !== 'Draft') {
      throw new Error(`Tournament registration is closed (Status: ${tourney.status})`);
    }

    const currentRegs = Number(tourney.currentRegistrations) || 0;
    const maxTeams = Number(tourney.maxTeams) || 48;

    if (currentRegs >= maxTeams) {
      throw new Error('Tournament slots are completely filled! No more joins allowed. (Slots Full)');
    }

    // 2. Check wallet balance
    const walletRef = doc(db, 'wallets', params.userId);
    const walletSnap = await transaction.get(walletRef);
    const currentBalance = walletSnap.exists() ? (walletSnap.data() as UserWallet).availableBalance || 0 : 0;

    if (actualFee > 0 && currentBalance < actualFee) {
      throw new Error(`Insufficient wallet balance. Available: ₹${currentBalance}, Required: ₹${actualFee}. Please add funds.`);
    }

    // 3. Deduct from wallet if fee > 0
    if (actualFee > 0) {
      const newBalance = currentBalance - actualFee;
      transaction.set(
        walletRef,
        {
          userId: params.userId,
          userEmail: params.userEmail,
          userName: params.userEmail.split('@')[0],
          availableBalance: newBalance,
          updatedAt: Date.now(),
        },
        { merge: true }
      );

      // Create transaction log
      const txRef = doc(collection(db, 'walletTransactions'));
      transaction.set(txRef, {
        userId: params.userId,
        userEmail: params.userEmail,
        amount: actualFee,
        type: 'Entry Fee',
        previousBalance: currentBalance,
        newBalance,
        status: 'Completed',
        description: `Entry fee for tournament: ${params.tournamentName}`,
        tournamentId: params.tournamentId,
        tournamentName: params.tournamentName,
        timestamp: Date.now(),
      });
    }

    // 4. Create Registration with deterministic doc ID
    regId = regRef.id;
    const leader = params.players[0] || { name: params.userEmail.split('@')[0], ign: '', ffUid: '' };
    const newReg: Registration = {
      id: regRef.id,
      tournamentId: params.tournamentId,
      tournamentName: params.tournamentName,
      userId: params.userId,
      userEmail: params.userEmail,
      teamName: params.teamName || `${params.userEmail.split('@')[0]}'s Squad`,
      captainName: leader.name || params.userEmail.split('@')[0],
      captainEmail: params.userEmail,
      captainPhone: '',
      captainFfUid: leader.ffUid || '',
      captainIgn: leader.ign || '',
      players: params.players.map((p) => ({ name: p.name, ffUid: p.ffUid, ign: p.ign })),
      type: tourney.type,
      paymentMethod: 'WALLET',
      paymentStatus: 'Approved',
      entryFee: params.entryFee,
      discountAmount: params.discountAmount || 0,
      paidAmount: actualFee,
      couponCode: params.couponCode || '',
      status: 'Approved', // Auto-approved since deducted from wallet
      slotNumber: currentRegs + 1,
      registeredAt: Date.now(),
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    transaction.set(regRef, newReg);

    // 5. Update Tournament currentRegistrations
    transaction.update(tourneyRef, {
      currentRegistrations: currentRegs + 1,
      updatedAt: Date.now(),
    });

    // 6. Update User totalTournamentsJoined
    const userRef = doc(db, 'users', params.userId);
    const userSnap = await transaction.get(userRef);
    const prevJoined = userSnap.exists() ? Number((userSnap.data() as any).totalTournamentsJoined) || 0 : 0;
    transaction.set(
      userRef,
      {
        totalTournamentsJoined: prevJoined + 1,
        updatedAt: Date.now(),
      },
      { merge: true }
    );
  });

  return regId;
}

export async function playerRequestDeposit(params: {
  userId: string;
  userEmail: string;
  userName: string;
  amount: number;
  utrNumber?: string;
  screenshotUrl?: string;
  upiUsed?: string;
}): Promise<string> {
  if (!params.amount || params.amount <= 0) {
    throw new Error('Please enter a valid deposit amount');
  }

  const finalUtr =
    params.utrNumber && params.utrNumber.trim().length >= 4
      ? params.utrNumber.trim()
      : `DIRECT_UPI_${Math.floor(10000000 + Math.random() * 90000000)}`;

  const now = Date.now();
  const docRef = await addDoc(collection(db, 'depositRequests'), {
    userId: params.userId,
    userEmail: params.userEmail,
    userName: params.userName || params.userEmail.split('@')[0],
    amount: Number(params.amount),
    utrNumber: finalUtr,
    screenshotUrl: params.screenshotUrl || '',
    upiUsed: params.upiUsed || 'Direct UPI App',
    status: 'Pending',
    createdAt: now,
  });

  // Create payment record for admin tracking
  await addDoc(collection(db, 'payments'), {
    userId: params.userId,
    userEmail: params.userEmail,
    amount: Number(params.amount),
    method: 'UPI',
    utrNumber: finalUtr,
    screenshotUrl: params.screenshotUrl || '',
    status: 'Pending',
    createdAt: now,
  });

  return docRef.id;
}

export async function playerRequestWithdrawal(params: {
  userId: string;
  userEmail: string;
  userName: string;
  phone: string;
  requestedAmount: number;
  payoutMethod: 'UPI' | 'BANK' | 'PAYTM' | 'GPAY' | 'PHONEPE' | 'REDEEM_CODE';
  payoutDetails: {
    upiId?: string;
    accountNumber?: string;
    ifscCode?: string;
    bankName?: string;
    holderName?: string;
    mobileNumber?: string;
    redeemCodeAmount?: number;
  };
}): Promise<string> {
  if (params.requestedAmount <= 0) {
    throw new Error('Withdrawal amount must be greater than zero');
  }

  let withId = '';

  await runTransaction(db, async (transaction) => {
    const walletRef = doc(db, 'wallets', params.userId);
    const walletSnap = await transaction.get(walletRef);
    if (!walletSnap.exists()) throw new Error('User wallet not found');
    const wallet = walletSnap.data() as UserWallet;

    const available = Number(wallet.availableBalance || 0);
    if (available < params.requestedAmount) {
      throw new Error(`Insufficient available balance for withdrawal. Balance: ₹${available}`);
    }

    // Deduct immediately from availableBalance to prevent double withdrawal
    const newBalance = available - params.requestedAmount;
    const pendingBalance = Number(wallet.pendingBalance || 0) + params.requestedAmount;

    transaction.update(walletRef, {
      availableBalance: newBalance,
      pendingBalance: pendingBalance,
      updatedAt: Date.now(),
    });

    const withRef = doc(collection(db, 'withdrawalRequests'));
    withId = withRef.id;

    const feeAmount = 0; // 0% withdrawal fee default
    const netAmount = params.requestedAmount - feeAmount;

    transaction.set(withRef, {
      userId: params.userId,
      userEmail: params.userEmail,
      userName: params.userName || params.userEmail.split('@')[0],
      phone: params.phone || '',
      requestedAmount: params.requestedAmount,
      feeAmount,
      netAmount,
      payoutMethod: params.payoutMethod,
      payoutDetails: params.payoutDetails,
      status: 'Pending',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });
  });

  return withId;
}

export async function playerCreateTicket(params: {
  userId: string;
  userEmail: string;
  userName: string;
  subject: string;
  category: 'Payment' | 'Tournament' | 'Room' | 'Result' | 'Account' | 'Other';
  message: string;
}): Promise<string> {
  const now = Date.now();
  const docRef = await addDoc(collection(db, 'supportTickets'), {
    userId: params.userId,
    userEmail: params.userEmail,
    userName: params.userName,
    subject: params.subject,
    category: params.category,
    status: 'Open',
    priority: 'Normal',
    messages: [
      {
        id: 'msg_' + now,
        senderId: params.userId,
        senderEmail: params.userEmail,
        senderName: params.userName,
        senderRole: 'USER',
        message: params.message,
        createdAt: now,
      },
    ],
    createdAt: now,
    updatedAt: now,
  });

  return docRef.id;
}

export function subscribeUserDepositRequests(
  userId: string,
  callback: (deposits: DepositRequest[]) => void
): () => void {
  const q = query(
    collection(db, 'depositRequests'),
    where('userId', '==', userId),
    orderBy('createdAt', 'desc'),
    limit(50)
  );
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as DepositRequest));
      callback(list);
    },
    (err) => {
      console.warn('Error subscribing to user deposit requests:', err);
      // Fallback query without orderBy if index is building
      const fallbackQ = query(
        collection(db, 'depositRequests'),
        where('userId', '==', userId)
      );
      return onSnapshot(fallbackQ, (fSnap) => {
        const list = fSnap.docs.map((d) => ({ id: d.id, ...d.data() } as DepositRequest));
        list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        callback(list);
      });
    }
  );
}

export function subscribeUserWithdrawalRequests(
  userId: string,
  callback: (withdrawals: WithdrawalRequest[]) => void
): () => void {
  const q = query(
    collection(db, 'withdrawalRequests'),
    where('userId', '==', userId),
    orderBy('createdAt', 'desc'),
    limit(50)
  );
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as WithdrawalRequest));
      callback(list);
    },
    (err) => {
      console.warn('Error subscribing to user withdrawal requests:', err);
      const fallbackQ = query(
        collection(db, 'withdrawalRequests'),
        where('userId', '==', userId)
      );
      return onSnapshot(fallbackQ, (fSnap) => {
        const list = fSnap.docs.map((d) => ({ id: d.id, ...d.data() } as WithdrawalRequest));
        list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        callback(list);
      });
    }
  );
}

// ----------------------------------------------------
// CSV EXPORT HELPER
// ----------------------------------------------------
export function exportToCsv(filename: string, rows: Record<string, any>[]): void {
  if (!rows || !rows.length) {
    alert('No data to export');
    return;
  }
  const separator = ',';
  const keys = Object.keys(rows[0]);
  const csvContent =
    keys.join(separator) +
    '\n' +
    rows
      .map((row) => {
        return keys
          .map((k) => {
            let cell = row[k] === null || row[k] === undefined ? '' : row[k];
            cell = cell instanceof Date ? cell.toLocaleString() : cell.toString();
            cell = cell.replace(/"/g, '""');
            if (cell.search(/("|,|\n)/g) >= 0) {
              cell = `"${cell}"`;
            }
            return cell;
          })
          .join(separator);
      })
      .join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}_${new Date().toISOString().split('T')[0]}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// ----------------------------------------------------
// 1. MATCH PROOFS & SCREENSHOT VERIFICATION
// ----------------------------------------------------
export async function submitMatchProof(proof: Omit<MatchProof, 'id' | 'status' | 'submittedAt'>): Promise<string> {
  const proofRef = collection(db, 'matchProofs');
  const newDoc = await addDoc(proofRef, {
    ...proof,
    status: 'Pending',
    submittedAt: Date.now(),
  });
  return newDoc.id;
}

export function subscribeMatchProofs(callback: (proofs: MatchProof[]) => void): () => void {
  const q = query(collection(db, 'matchProofs'), orderBy('submittedAt', 'desc'), limit(100));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as MatchProof));
      callback(list);
    },
    () => {
      // Fallback without orderBy
      return onSnapshot(collection(db, 'matchProofs'), (fSnap) => {
        const list = fSnap.docs.map((d) => ({ id: d.id, ...d.data() } as MatchProof));
        list.sort((a, b) => (b.submittedAt || 0) - (a.submittedAt || 0));
        callback(list);
      });
    }
  );
}

export function subscribeUserMatchProofs(
  userId: string,
  callback: (proofs: MatchProof[]) => void
): () => void {
  const q = query(collection(db, 'matchProofs'), where('userId', '==', userId));
  return onSnapshot(q, (snap) => {
    const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as MatchProof));
    list.sort((a, b) => (b.submittedAt || 0) - (a.submittedAt || 0));
    callback(list);
  });
}

export async function verifyMatchProof(
  proofId: string,
  status: 'Verified' | 'Rejected',
  adminNotes?: string,
  verifiedBy?: string
): Promise<void> {
  const proofRef = doc(db, 'matchProofs', proofId);
  await updateDoc(proofRef, {
    status,
    adminNotes: adminNotes || '',
    verifiedAt: Date.now(),
    verifiedBy: verifiedBy || 'Admin',
  });
}

// ----------------------------------------------------
// 2. SQUAD & TEAM MANAGEMENT
// ----------------------------------------------------
export async function savePlayerSquad(
  squad: Partial<PlayerSquad> & { ownerUserId: string; teamName: string }
): Promise<string> {
  const now = Date.now();
  if (squad.id) {
    const squadRef = doc(db, 'playerSquads', squad.id);
    await updateDoc(squadRef, {
      teamName: squad.teamName,
      teamTag: squad.teamTag || '',
      logoUrl: squad.logoUrl || '',
      members: squad.members || [],
      updatedAt: now,
    });
    return squad.id;
  } else {
    const squadRef = collection(db, 'playerSquads');
    const squadCode = 'SQ-' + Math.floor(1000 + Math.random() * 9000);
    const newDoc = await addDoc(squadRef, {
      ownerUserId: squad.ownerUserId,
      teamName: squad.teamName,
      teamTag: squad.teamTag || '',
      logoUrl: squad.logoUrl || '',
      squadCode,
      members: squad.members || [],
      createdAt: now,
      updatedAt: now,
    });
    return newDoc.id;
  }
}

export function subscribePlayerSquads(
  userId: string,
  callback: (squads: PlayerSquad[]) => void
): () => void {
  const q = query(collection(db, 'playerSquads'), where('ownerUserId', '==', userId));
  return onSnapshot(q, (snap) => {
    const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as PlayerSquad));
    callback(list);
  });
}

export async function deletePlayerSquad(squadId: string): Promise<void> {
  await deleteDoc(doc(db, 'playerSquads', squadId));
}

// ----------------------------------------------------
// 3. VIP ESPORTS PASS & SUBSCRIPTIONS
// ----------------------------------------------------
export async function buyVipPass(
  userId: string,
  userEmail: string,
  userName: string,
  planType: 'WEEKLY' | 'MONTHLY'
): Promise<void> {
  const price = planType === 'WEEKLY' ? 49 : 149;
  const days = planType === 'WEEKLY' ? 7 : 30;
  const now = Date.now();
  const expiryDate = now + days * 24 * 60 * 60 * 1000;

  // Run transaction to check wallet balance and deduct
  await runTransaction(db, async (transaction) => {
    const walletRef = doc(db, 'wallets', userId);
    const walletSnap = await transaction.get(walletRef);

    if (!walletSnap.exists()) {
      throw new Error('Wallet not found');
    }

    const currentBalance = walletSnap.data().availableBalance || 0;
    if (currentBalance < price) {
      throw new Error(`Insufficient wallet balance. Required: ₹${price}, Available: ₹${currentBalance}`);
    }

    const newBalance = currentBalance - price;

    // Update wallet
    transaction.update(walletRef, {
      availableBalance: newBalance,
      updatedAt: now,
    });

    // Create wallet transaction
    const transRef = doc(collection(db, 'walletTransactions'));
    transaction.set(transRef, {
      userId,
      userEmail,
      amount: price,
      type: 'Admin Adjustment',
      previousBalance: currentBalance,
      newBalance,
      status: 'Completed',
      description: `Purchased 👑 VIP Esports Pass (${planType})`,
      timestamp: now,
    });

    // Update AppUser VIP status
    const userRef = doc(db, 'users', userId);
    transaction.set(
      userRef,
      {
        isVip: true,
        vipPlan: planType,
        vipExpiryDate: expiryDate,
        updatedAt: now,
      },
      { merge: true }
    );

    // Save VIP record
    const vipRef = doc(collection(db, 'vipSubscriptions'));
    transaction.set(vipRef, {
      userId,
      userEmail,
      userName,
      planType,
      pricePaid: price,
      discountPercent: 10,
      startDate: now,
      expiryDate,
      isActive: true,
    });
  });
}

export async function toggleUserVip(userId: string, isVip: boolean): Promise<void> {
  const userRef = doc(db, 'users', userId);
  const expiry = isVip ? Date.now() + 30 * 24 * 60 * 60 * 1000 : 0;
  await updateDoc(userRef, {
    isVip,
    vipExpiryDate: expiry,
  });
}

// ----------------------------------------------------
// REFERRAL SYSTEM FUNCTIONS
// ----------------------------------------------------
export function generateUniqueReferralCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = 'FF';
  for (let i = 0; i < 5; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

export async function processReferralOnSignup(
  newUserId: string,
  newUserName: string,
  newUserEmail: string,
  referralCodeInput: string
): Promise<{ success: boolean; message: string }> {
  const cleanCode = referralCodeInput.trim().toUpperCase();
  if (!cleanCode) return { success: false, message: 'No code provided' };

  try {
    // Find referrer with this code
    const usersRef = collection(db, 'users');
    const q = query(usersRef, where('referralCode', '==', cleanCode));
    const snap = await getDocs(q);

    if (snap.empty) {
      return { success: false, message: 'Invalid referral code' };
    }

    const referrerDoc = snap.docs[0];
    const referrerId = referrerDoc.id;
    const referrerData = referrerDoc.data() as AppUser;

    if (referrerId === newUserId) {
      return { success: false, message: 'Cannot refer yourself' };
    }

    // Check if referral was already processed for this user
    const refRecordRef = collection(db, 'referrals');
    const existingQ = query(refRecordRef, where('referredUserId', '==', newUserId));
    const existingSnap = await getDocs(existingQ);
    if (!existingSnap.empty) {
      return { success: false, message: 'Referral already applied for this account' };
    }

    const now = Date.now();
    const REFERRAL_REWARD = 20; // ₹20 for referrer
    const NEW_USER_BONUS = 10;  // ₹10 bonus for new user
    const MILESTONE_COUNT = 10; // Every 10 referrals = ₹500 bonus
    const MILESTONE_BONUS = 500; // ₹500 bonus

    const currentTotalRefs = (referrerData.totalReferrals || 0) + 1;
    let milestoneAwarded = 0;

    // Check if this referral completes a milestone (10th, 20th, 30th, etc.)
    if (currentTotalRefs % MILESTONE_COUNT === 0) {
      milestoneAwarded = MILESTONE_BONUS;
    }

    const totalReferrerEarnings = REFERRAL_REWARD + milestoneAwarded;

    await runTransaction(db, async (transaction) => {
      // 1. Credit Referrer Wallet
      const referrerWalletRef = doc(db, 'wallets', referrerId);
      const referrerWalletSnap = await transaction.get(referrerWalletRef);
      const refPrevBal = referrerWalletSnap.exists() ? (referrerWalletSnap.data().availableBalance || 0) : 0;
      const refNewBal = refPrevBal + totalReferrerEarnings;

      transaction.set(
        referrerWalletRef,
        {
          userId: referrerId,
          userEmail: referrerData.email || '',
          userName: referrerData.name || 'Referrer',
          availableBalance: refNewBal,
          updatedAt: now,
        },
        { merge: true }
      );

      // 2. Referrer Wallet Transaction log
      const refTransRef = doc(collection(db, 'walletTransactions'));
      transaction.set(refTransRef, {
        userId: referrerId,
        userEmail: referrerData.email || '',
        amount: totalReferrerEarnings,
        type: 'Prize Credit',
        previousBalance: refPrevBal,
        newBalance: refNewBal,
        status: 'Completed',
        description: `🎁 Referral Reward for inviting ${newUserName} (+₹${REFERRAL_REWARD})${
          milestoneAwarded > 0 ? ` + 🏆 Milestone Bonus (+₹${MILESTONE_BONUS})` : ''
        }`,
        timestamp: now,
      });

      // 3. Credit New User Wallet with ₹10 Welcome Bonus
      const newUserWalletRef = doc(db, 'wallets', newUserId);
      const newUserWalletSnap = await transaction.get(newUserWalletRef);
      const newUserPrevBal = newUserWalletSnap.exists() ? (newUserWalletSnap.data().availableBalance || 0) : 0;
      const newUserNewBal = newUserPrevBal + NEW_USER_BONUS;

      transaction.set(
        newUserWalletRef,
        {
          userId: newUserId,
          userEmail: newUserEmail,
          userName: newUserName,
          availableBalance: newUserNewBal,
          updatedAt: now,
        },
        { merge: true }
      );

      // 4. New User Wallet Transaction log
      const newUserTransRef = doc(collection(db, 'walletTransactions'));
      transaction.set(newUserTransRef, {
        userId: newUserId,
        userEmail: newUserEmail,
        amount: NEW_USER_BONUS,
        type: 'Prize Credit',
        previousBalance: newUserPrevBal,
        newBalance: newUserNewBal,
        status: 'Completed',
        description: `🎉 Welcome Bonus for registering with Referral Code ${cleanCode}`,
        timestamp: now,
      });

      // 5. Update Referrer User Doc stats
      const referrerUserDocRef = doc(db, 'users', referrerId);
      transaction.set(
        referrerUserDocRef,
        {
          totalReferrals: currentTotalRefs,
          totalReferralEarnings: (referrerData.totalReferralEarnings || 0) + totalReferrerEarnings,
          updatedAt: now,
        },
        { merge: true }
      );

      // 6. Update New User Doc
      const newUserDocRef = doc(db, 'users', newUserId);
      transaction.set(
        newUserDocRef,
        {
          referredBy: cleanCode,
          updatedAt: now,
        },
        { merge: true }
      );

      // 7. Create Referral Record
      const newRefRecordRef = doc(collection(db, 'referrals'));
      transaction.set(newRefRecordRef, {
        referrerUserId: referrerId,
        referredUserId: newUserId,
        referredUserEmail: newUserEmail,
        referredUserName: newUserName,
        bonusAmount: REFERRAL_REWARD,
        milestoneBonusAwarded: milestoneAwarded,
        timestamp: now,
      });
    });

    return {
      success: true,
      message: `🎉 Referral Applied! You got ₹${NEW_USER_BONUS} Welcome Bonus, and referrer received ₹${REFERRAL_REWARD}!`,
    };
  } catch (err: any) {
    console.error('Error processing referral:', err);
    return { success: false, message: err.message || 'Failed to process referral code' };
  }
}

export function subscribeUserReferrals(
  userId: string,
  callback: (records: ReferralRecord[]) => void
): () => void {
  const refCol = collection(db, 'referrals');
  const q = query(refCol, where('referrerUserId', '==', userId), orderBy('timestamp', 'desc'));

  return onSnapshot(
    q,
    (snap) => {
      const records: ReferralRecord[] = snap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as ReferralRecord[];
      callback(records);
    },
    (err) => {
      console.warn('subscribeUserReferrals indexed query warning, using fallback:', err);
      const fallbackQ = query(refCol, where('referrerUserId', '==', userId));
      return onSnapshot(
        fallbackQ,
        (fSnap) => {
          const records: ReferralRecord[] = fSnap.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          })) as ReferralRecord[];
          records.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
          callback(records);
        },
        (fErr) => {
          console.warn('subscribeUserReferrals fallback error:', fErr);
          callback([]);
        }
      );
    }
  );
}

