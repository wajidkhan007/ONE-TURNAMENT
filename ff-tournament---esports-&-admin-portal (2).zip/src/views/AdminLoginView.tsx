import React, { useState } from 'react';
import { Shield, Lock, Mail, KeyRound, AlertCircle, CheckCircle2, ArrowRight, UserPlus, HelpCircle, ArrowLeft, Gamepad2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { SUPER_ADMIN_EMAIL } from '../firebase';

interface AdminLoginViewProps {
  onBackToWebsite?: () => void;
}

export const AdminLoginView: React.FC<AdminLoginViewProps> = ({ onBackToWebsite }) => {
  const { login, setupSuperAdmin, resetPassword } = useAuth();
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [mode, setMode] = useState<'login' | 'reset' | 'setup'>('login');
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      if (mode === 'login') {
        if (!email.trim() || !password) {
          throw new Error('Please enter both email and password');
        }
        await login(email.trim(), password);
      } else if (mode === 'setup') {
        if (password.length < 6) {
          throw new Error('Password must be at least 6 characters');
        }
        await setupSuperAdmin(password);
        setSuccess('Super Admin account configured! Logging in...');
      } else if (mode === 'reset') {
        if (!email.trim()) {
          throw new Error('Please enter your admin email');
        }
        await resetPassword(email.trim());
        setSuccess('Password reset link sent to ' + email + '. Check your inbox.');
      }
    } catch (err: any) {
      console.error('Auth error:', err);
      let msg = err.message || 'Authentication failed';
      if (err.code === 'auth/invalid-credential' || err.code === 'auth/wrong-password') {
        msg = 'Invalid email or password. You can initialize account or check credentials.';
      } else if (err.code === 'auth/user-not-found') {
        msg = 'No admin account found for this email. Use "Initialize Super Admin" if setting up first.';
      } else if (err.code === 'auth/too-many-requests') {
        msg = 'Access temporarily disabled due to many failed attempts. Please reset password or try later.';
      } else if (err.code === 'auth/operation-not-allowed') {
        msg = 'Email/Password sign-in provider is currently disabled in Firebase Console. Local instant access mode is activated.';
      }
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-zinc-950 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background neon grid glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(245,158,11,0.08)_0,transparent_70%)] pointer-events-none" />
      <div className="absolute -top-40 -right-40 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Left Return to Tournament Website Button */}
      {onBackToWebsite && (
        <button
          onClick={onBackToWebsite}
          className="absolute top-6 left-6 z-20 flex items-center gap-2 px-3.5 py-2 rounded-xl bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-800 text-xs font-bold text-zinc-300 hover:text-amber-400 transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return to Tournament Website</span>
        </button>
      )}

      <div className="w-full max-w-md relative z-10">
        {/* Logo and Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-600 via-amber-500 to-amber-400 p-0.5 shadow-xl shadow-amber-500/20 mb-4">
            <div className="w-full h-full bg-zinc-950 rounded-[14px] flex items-center justify-center">
              <Shield className="w-8 h-8 text-amber-400" />
            </div>
          </div>
          <h1 className="text-2xl font-black tracking-tight text-white font-mono uppercase">
            🌐 ADMIN CONTROL PORTAL
          </h1>
          <p className="text-xs font-semibold text-zinc-400 mt-1 uppercase tracking-widest">
            FF Tournament Operations Center
          </p>
        </div>

        {/* Card */}
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900/90 backdrop-blur-xl p-6 sm:p-8 shadow-2xl">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-white tracking-tight">
              {mode === 'login' && 'Admin Verification'}
              {mode === 'setup' && 'Initialize Super Admin'}
              {mode === 'reset' && 'Reset Admin Password'}
            </h2>
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-zinc-800 text-amber-400 border border-zinc-700">
              SECURE
            </span>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-start gap-2.5 text-rose-300 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-start gap-2.5 text-emerald-300 text-xs">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
              <span>{success}</span>
            </div>
          )}

          {/* FORM WITH STRICT AUTOCOMPLETE DISABLED */}
          <form onSubmit={handleSubmit} autoComplete="off" className="space-y-4">
            {/* Hidden dummy fields to neutralize browser autofill */}
            <input type="text" style={{ display: 'none' }} aria-hidden="true" />
            <input type="password" style={{ display: 'none' }} aria-hidden="true" />

            {mode !== 'setup' && (
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400 mb-1.5">
                  Admin Email
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-500">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    id="input-admin-email"
                    type="email"
                    name="admin_email_no_autofill"
                    autoComplete="off"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter admin email address"
                    required
                    className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-zinc-700 bg-zinc-950 text-sm text-white placeholder-zinc-500 focus:border-amber-500 focus:outline-none transition"
                  />
                </div>
              </div>
            )}

            {mode === 'setup' && (
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 mb-3">
                <p className="text-xs text-amber-300 font-medium">
                  Setting up initial password for Super Admin:
                </p>
                <p className="text-xs font-mono font-bold text-white mt-1">
                  {SUPER_ADMIN_EMAIL}
                </p>
              </div>
            )}

            {mode !== 'reset' && (
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                    {mode === 'setup' ? 'Set Master Password' : 'Password'}
                  </label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => {
                        setMode('reset');
                        setError('');
                        setSuccess('');
                      }}
                      className="text-xs text-amber-400 hover:underline cursor-pointer"
                    >
                      Forgot password?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-500">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="input-admin-password"
                    type="password"
                    name="admin_password_no_autofill"
                    autoComplete="new-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter admin password"
                    required
                    className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-zinc-700 bg-zinc-950 text-sm text-white placeholder-zinc-500 focus:border-amber-500 focus:outline-none transition"
                  />
                </div>
              </div>
            )}

            <button
              id="btn-admin-auth-submit"
              type="submit"
              disabled={loading}
              className="w-full mt-2 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-bold text-sm transition shadow-lg shadow-amber-500/25 active:scale-98 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {loading ? (
                <span>Authenticating with Firebase...</span>
              ) : mode === 'login' ? (
                <>
                  <span>Sign In to Admin Panel</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              ) : mode === 'setup' ? (
                <>
                  <span>Initialize & Login</span>
                  <KeyRound className="w-4 h-4" />
                </>
              ) : (
                <span>Send Reset Link</span>
              )}
            </button>
          </form>

          {/* Alternative setup actions */}
          <div className="mt-6 pt-5 border-t border-zinc-800 flex flex-col items-center gap-3 text-center">
            {mode === 'login' ? (
              <button
                id="btn-switch-setup-super-admin"
                type="button"
                onClick={() => {
                  setMode('setup');
                  setError('');
                  setSuccess('');
                }}
                className="text-xs text-zinc-400 hover:text-amber-400 transition flex items-center gap-1.5 cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5 text-amber-400" />
                <span>First time? Initialize Super Admin Account</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError('');
                  setSuccess('');
                }}
                className="text-xs text-amber-400 hover:underline cursor-pointer"
              >
                ← Back to Admin Login
              </button>
            )}
          </div>
        </div>

        {/* Security watermark */}
        <p className="text-center text-[11px] text-zinc-600 mt-6">
          Authorized personnel only. All access attempts are logged to Firestore.
        </p>
      </div>
    </div>
  );
};

