import React, { useEffect, useState } from 'react';
import {
  KeyRound,
  Eye,
  EyeOff,
  Copy,
  Check,
  Calendar,
  Clock,
  MapPin,
  Save,
  Search,
} from 'lucide-react';
import { getMatches, saveMatch, logAdminActivity } from '../services/adminService';
import { Match } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';
import { useAuth } from '../context/AuthContext';

export const RoomsView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [editingRoomData, setEditingRoomData] = useState<Record<string, { roomId: string; roomPass: string }>>({});

  const loadMatches = async () => {
    try {
      setLoading(true);
      const data = await getMatches();
      setMatches(data);
      const initialMap: Record<string, { roomId: string; roomPass: string }> = {};
      data.forEach((m) => {
        initialMap[m.id] = { roomId: m.roomId || '', roomPass: m.roomPassword || '' };
      });
      setEditingRoomData(initialMap);
    } catch (err) {
      console.error('Error loading matches:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMatches();
  }, []);

  const handleSaveRoom = async (m: Match) => {
    const current = editingRoomData[m.id];
    if (!current) return;
    try {
      await saveMatch({
        id: m.id,
        roomId: current.roomId,
        roomPassword: current.roomPass,
      });

      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'UPDATE_ROOM_CREDENTIALS',
          'rooms',
          `Updated Room ID: ${current.roomId} for Match #${m.matchNumber}`,
          m.id
        );
      }
      alert('Room credentials saved successfully!');
      await loadMatches();
    } catch (err) {
      console.error('Error saving room:', err);
      alert('Failed to save room credentials');
    }
  };

  const handleTogglePublish = async (m: Match) => {
    try {
      const nextState = !m.isRoomPublished;
      await saveMatch({ id: m.id, isRoomPublished: nextState });

      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          nextState ? 'PUBLISH_ROOM' : 'HIDE_ROOM',
          'rooms',
          `${nextState ? 'Published' : 'Hidden'} Room for Match #${m.matchNumber}`,
          m.id
        );
      }
      await loadMatches();
    } catch (err) {
      console.error('Error toggling publish state:', err);
    }
  };

  const handleCopy = (m: Match) => {
    const text = `FREE FIRE CUSTOM ROOM CREDENTIALS\nTournament: ${m.tournamentName}\nMatch: #${m.matchNumber}\nRoom ID: ${m.roomId || 'Not set'}\nPassword: ${m.roomPassword || 'None'}\nMap: ${m.map}\nTime: ${m.matchTime}`;
    navigator.clipboard.writeText(text);
    setCopiedId(m.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredMatches = matches.filter(
    (m) =>
      m.tournamentName?.toLowerCase().includes(search.toLowerCase()) ||
      m.roomId?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <KeyRound className="w-5 h-5 text-amber-400" />
            <span>Room Credential Distribution</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Quickly assign Free Fire Custom Room IDs & Passwords, and make them instantly visible to registered players.
          </p>
        </div>
        <div className="relative max-w-xs w-full">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search tournament or room ID..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
          />
        </div>
      </div>

      {/* Grid */}
      {loading ? (
        <LoadingSpinner text="Loading room configurations..." />
      ) : filteredMatches.length === 0 ? (
        <EmptyState
          icon={KeyRound}
          title="No match rooms found"
          description="Create matches inside tournaments to manage and publish Free Fire custom room credentials."
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredMatches.map((m) => {
            const currentEdit = editingRoomData[m.id] || { roomId: m.roomId || '', roomPass: m.roomPassword || '' };
            const isDirty = currentEdit.roomId !== (m.roomId || '') || currentEdit.roomPass !== (m.roomPassword || '');

            return (
              <div
                key={m.id}
                className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-5 space-y-4 hover:border-zinc-700 transition"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-amber-400 font-mono">
                      Match #{m.matchNumber}
                    </span>
                    <h3 className="text-sm font-bold text-white tracking-tight truncate max-w-[180px]">
                      {m.tournamentName || 'Tournament'}
                    </h3>
                  </div>
                  <button
                    onClick={() => handleTogglePublish(m)}
                    className={`text-[10px] font-bold px-2.5 py-1 rounded-lg flex items-center gap-1.5 cursor-pointer transition ${
                      m.isRoomPublished
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700 border border-zinc-700'
                    }`}
                  >
                    {m.isRoomPublished ? (
                      <>
                        <Eye className="w-3.5 h-3.5" />
                        <span>LIVE TO PLAYERS</span>
                      </>
                    ) : (
                      <>
                        <EyeOff className="w-3.5 h-3.5" />
                        <span>HIDDEN (DRAFT)</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="flex items-center gap-3 text-[11px] text-zinc-400">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-zinc-500" />
                    {m.matchDate}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-zinc-500" />
                    {m.matchTime}
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-zinc-500" />
                    {m.map}
                  </span>
                </div>

                {/* Form fields */}
                <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800/80 space-y-3">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-zinc-400 mb-1">
                        Room ID
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. 581938"
                        value={currentEdit.roomId}
                        onChange={(e) =>
                          setEditingRoomData({
                            ...editingRoomData,
                            [m.id]: { ...currentEdit, roomId: e.target.value },
                          })
                        }
                        className="w-full px-2.5 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white font-mono focus:border-amber-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-zinc-400 mb-1">
                        Password
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. 1234"
                        value={currentEdit.roomPass}
                        onChange={(e) =>
                          setEditingRoomData({
                            ...editingRoomData,
                            [m.id]: { ...currentEdit, roomPass: e.target.value },
                          })
                        }
                        className="w-full px-2.5 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white font-mono focus:border-amber-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={() => handleSaveRoom(m)}
                      disabled={!isDirty}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer ${
                        isDirty
                          ? 'bg-amber-500 hover:bg-amber-400 text-zinc-950 shadow-md shadow-amber-500/20'
                          : 'bg-zinc-900 text-zinc-500 border border-zinc-800 cursor-not-allowed'
                      }`}
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>{isDirty ? 'Save Changes' : 'Saved'}</span>
                    </button>
                    <button
                      onClick={() => handleCopy(m)}
                      className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 text-xs font-semibold flex items-center gap-1 border border-zinc-800 transition cursor-pointer"
                    >
                      {copiedId === m.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
