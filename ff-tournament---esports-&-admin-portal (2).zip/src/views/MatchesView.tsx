import React, { useEffect, useState } from 'react';
import {
  Swords,
  Plus,
  KeyRound,
  Eye,
  EyeOff,
  Clock,
  Calendar,
  MapPin,
  CheckCircle2,
  Trash2,
  Edit2,
  Play,
  Copy,
  Trophy,
} from 'lucide-react';
import { getMatches, saveMatch, deleteMatch, getTournaments, logAdminActivity } from '../services/adminService';
import { Match, Tournament, GameMap, GameMode, MatchStatus } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useAuth } from '../context/AuthContext';

export const MatchesView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [matches, setMatches] = useState<Match[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedTournFilter, setSelectedTournFilter] = useState<string>('ALL');

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingMatch, setEditingMatch] = useState<Partial<Match> | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const loadData = async () => {
    try {
      setLoading(true);
      const [matchesData, tournamentsData] = await Promise.all([
        getMatches(),
        getTournaments(),
      ]);
      setMatches(matchesData);
      setTournaments(tournamentsData);
    } catch (err) {
      console.error('Error loading matches data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleOpenCreate = () => {
    const firstTourn = tournaments[0];
    setEditingMatch({
      tournamentId: firstTourn?.id || '',
      tournamentName: firstTourn?.name || '',
      matchNumber: (matches.length % 10) + 1,
      matchDate: new Date().toISOString().split('T')[0],
      matchTime: '19:00',
      map: firstTourn?.map || 'Bermuda',
      mode: firstTourn?.mode || 'Battle Royale',
      roomId: '',
      roomPassword: '',
      isRoomPublished: false,
      status: 'Scheduled',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (m: Match) => {
    setEditingMatch({ ...m });
    setIsModalOpen(true);
  };

  const handleToggleRoomPublish = async (m: Match) => {
    try {
      const nextState = !m.isRoomPublished;
      await saveMatch({ id: m.id, isRoomPublished: nextState });
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          nextState ? 'PUBLISH_ROOM' : 'HIDE_ROOM',
          'matches',
          `${nextState ? 'Published' : 'Hidden'} Room credentials for Match #${m.matchNumber}`,
          m.id
        );
      }
      await loadData();
    } catch (err) {
      console.error('Error updating room publication:', err);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMatch?.tournamentId) {
      alert('Please select a tournament for this match');
      return;
    }

    const t = tournaments.find((tour) => tour.id === editingMatch.tournamentId);
    try {
      await saveMatch({
        ...editingMatch,
        tournamentName: t?.name || editingMatch.tournamentName || 'Tournament',
      });

      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          editingMatch.id ? 'EDIT_MATCH' : 'CREATE_MATCH',
          'matches',
          `${editingMatch.id ? 'Edited' : 'Created'} Match #${editingMatch.matchNumber} in ${t?.name}`,
          editingMatch.id
        );
      }

      setIsModalOpen(false);
      setEditingMatch(null);
      await loadData();
    } catch (err) {
      console.error('Error saving match:', err);
      alert('Failed to save match');
    }
  };

  const handleDelete = async () => {
    if (!deleteConfirmId) return;
    try {
      await deleteMatch(deleteConfirmId);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'DELETE_MATCH',
          'matches',
          `Deleted match ${deleteConfirmId}`,
          deleteConfirmId
        );
      }
      setDeleteConfirmId(null);
      await loadData();
    } catch (err) {
      console.error('Error deleting match:', err);
    }
  };

  const handleCopyRoom = (roomId?: string, pass?: string, key?: string) => {
    if (!roomId) return;
    const text = `FF TOURNAMENT ROOM CREDENTIALS\nRoom ID: ${roomId}\nPassword: ${pass || 'None'}`;
    navigator.clipboard.writeText(text);
    if (key) {
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 2000);
    }
  };

  const filteredMatches = matches.filter((m) => {
    if (selectedTournFilter === 'ALL') return true;
    return m.tournamentId === selectedTournFilter;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Swords className="w-5 h-5 text-amber-400" />
            <span>Match & Room Management</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Schedule matches, distribute Free Fire Custom Room IDs & Passwords, and control publication to approved players.
          </p>
        </div>
        <button
          id="btn-create-new-match"
          onClick={handleOpenCreate}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold transition shadow-lg shadow-amber-500/20 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Create Match</span>
        </button>
      </div>

      {/* Filter by Tournament */}
      <div className="max-w-md">
        <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
          Filter by Tournament
        </label>
        <select
          value={selectedTournFilter}
          onChange={(e) => setSelectedTournFilter(e.target.value)}
          className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 cursor-pointer"
        >
          <option value="ALL">All Tournaments ({matches.length} matches total)</option>
          {tournaments.map((t) => (
            <option key={t.id} value={t.id}>
              {t.name} ({t.type})
            </option>
          ))}
        </select>
      </div>

      {/* Matches Grid */}
      {loading ? (
        <LoadingSpinner text="Fetching matches from Firestore..." />
      ) : filteredMatches.length === 0 ? (
        <EmptyState
          icon={Swords}
          title="No matches found"
          description="Create your first match inside a tournament to configure Room ID and schedule."
          actionLabel="Schedule Match"
          onAction={handleOpenCreate}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredMatches.map((m) => (
            <div
              key={m.id}
              className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-5 space-y-4 hover:border-zinc-700 transition"
            >
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 font-bold text-xs font-mono">
                  Match #{m.matchNumber}
                </span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                    m.status === 'Live'
                      ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20 animate-pulse'
                      : m.status === 'Completed'
                      ? 'bg-emerald-500/10 text-emerald-400'
                      : 'bg-zinc-800 text-zinc-300'
                  }`}
                >
                  {m.status}
                </span>
              </div>

              <div>
                <p className="text-xs font-bold text-white tracking-tight truncate">
                  {m.tournamentName || 'Tournament'}
                </p>
                <div className="flex items-center gap-3 text-[11px] text-zinc-400 mt-1.5 font-medium">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-zinc-500" />
                    {m.matchDate}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-zinc-500" />
                    {m.matchTime}
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-zinc-500" />
                    {m.map}
                  </span>
                </div>
              </div>

              {/* Room ID & Password Block */}
              <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800/80 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1">
                    <KeyRound className="w-3 h-3 text-amber-400" />
                    Room Credentials
                  </span>
                  <button
                    onClick={() => handleToggleRoomPublish(m)}
                    className={`text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1 cursor-pointer transition ${
                      m.isRoomPublished
                        ? 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30'
                        : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700'
                    }`}
                  >
                    {m.isRoomPublished ? (
                      <>
                        <Eye className="w-3 h-3" />
                        <span>Visible to Players</span>
                      </>
                    ) : (
                      <>
                        <EyeOff className="w-3 h-3" />
                        <span>Hidden (Private)</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div className="p-2 rounded bg-zinc-900 border border-zinc-800">
                    <span className="text-[9px] text-zinc-500 block uppercase">Room ID</span>
                    <span className="text-white font-bold">{m.roomId || 'Not Assigned'}</span>
                  </div>
                  <div className="p-2 rounded bg-zinc-900 border border-zinc-800">
                    <span className="text-[9px] text-zinc-500 block uppercase">Password</span>
                    <span className="text-white font-bold">{m.roomPassword || 'None'}</span>
                  </div>
                </div>

                {m.roomId && (
                  <button
                    onClick={() => handleCopyRoom(m.roomId, m.roomPassword, m.id)}
                    className="w-full py-1 rounded bg-zinc-900 hover:bg-zinc-800 text-[11px] text-zinc-300 hover:text-white flex items-center justify-center gap-1.5 transition cursor-pointer border border-zinc-800"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copiedKey === m.id ? 'Copied Room Details!' : 'Copy Room Details'}</span>
                  </button>
                )}
              </div>

              {/* Actions */}
              <div className="pt-2 flex items-center justify-between border-t border-zinc-800/60">
                <select
                  value={m.status}
                  onChange={(e) => saveMatch({ id: m.id, status: e.target.value as MatchStatus }).then(loadData)}
                  className="px-2 py-1 rounded-lg bg-zinc-950 border border-zinc-800 text-[11px] text-zinc-300 cursor-pointer"
                >
                  <option value="Scheduled">Scheduled</option>
                  <option value="Live">Live</option>
                  <option value="Completed">Completed</option>
                  <option value="Cancelled">Cancelled</option>
                </select>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleOpenEdit(m)}
                    className="p-1.5 rounded-lg text-amber-400 hover:bg-zinc-800 transition cursor-pointer"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setDeleteConfirmId(m.id)}
                    className="p-1.5 rounded-lg text-rose-400 hover:bg-zinc-800 transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create / Edit Modal */}
      {isModalOpen && editingMatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-lg rounded-2xl border border-zinc-800 bg-zinc-900 p-6 shadow-2xl">
            <h2 className="text-lg font-bold text-white mb-4">
              {editingMatch.id ? 'Edit Match & Room' : 'Create New Match'}
            </h2>

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Tournament</label>
                <select
                  value={editingMatch.tournamentId || ''}
                  onChange={(e) => {
                    const t = tournaments.find((x) => x.id === e.target.value);
                    setEditingMatch({
                      ...editingMatch,
                      tournamentId: e.target.value,
                      tournamentName: t?.name,
                    });
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white"
                >
                  {tournaments.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Match Number</label>
                  <input
                    type="number"
                    min={1}
                    value={editingMatch.matchNumber ?? 1}
                    onChange={(e) => setEditingMatch({ ...editingMatch, matchNumber: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Map</label>
                  <select
                    value={editingMatch.map || 'Bermuda'}
                    onChange={(e) => setEditingMatch({ ...editingMatch, map: e.target.value as GameMap })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white"
                  >
                    <option value="Bermuda">Bermuda</option>
                    <option value="Purgatory">Purgatory</option>
                    <option value="Kalahari">Kalahari</option>
                    <option value="Alpine">Alpine</option>
                    <option value="NexTerra">NexTerra</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Date</label>
                  <input
                    type="date"
                    value={editingMatch.matchDate || ''}
                    onChange={(e) => setEditingMatch({ ...editingMatch, matchDate: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Time</label>
                  <input
                    type="time"
                    value={editingMatch.matchTime || ''}
                    onChange={(e) => setEditingMatch({ ...editingMatch, matchTime: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white"
                  />
                </div>
              </div>

              {/* Room credentials */}
              <div className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3">
                <h4 className="text-xs font-bold text-amber-400 uppercase">Room Credentials</h4>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">Custom Room ID</label>
                    <input
                      type="text"
                      placeholder="e.g. 84920412"
                      value={editingMatch.roomId || ''}
                      onChange={(e) => setEditingMatch({ ...editingMatch, roomId: e.target.value })}
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-sm text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">Room Password</label>
                    <input
                      type="text"
                      placeholder="e.g. 1234"
                      value={editingMatch.roomPassword || ''}
                      onChange={(e) => setEditingMatch({ ...editingMatch, roomPassword: e.target.value })}
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-sm text-white font-mono"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="chk-publish-room"
                    checked={editingMatch.isRoomPublished || false}
                    onChange={(e) => setEditingMatch({ ...editingMatch, isRoomPublished: e.target.checked })}
                    className="w-4 h-4 rounded text-amber-500 border-zinc-700 bg-zinc-900 cursor-pointer"
                  />
                  <label htmlFor="chk-publish-room" className="text-xs text-zinc-300 cursor-pointer">
                    Publish Room ID & Password to approved participants immediately
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-zinc-700 text-xs font-semibold text-zinc-300 hover:bg-zinc-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow-lg shadow-amber-500/20 cursor-pointer"
                >
                  Save Match
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmationModal
        isOpen={!!deleteConfirmId}
        title="Delete Match"
        message="Are you sure you want to delete this match record?"
        isDangerous
        onConfirm={handleDelete}
        onCancel={() => setDeleteConfirmId(null)}
      />
    </div>
  );
};
