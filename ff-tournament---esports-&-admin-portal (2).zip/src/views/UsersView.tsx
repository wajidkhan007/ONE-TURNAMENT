import React, { useEffect, useState } from 'react';
import {
  UserCheck,
  Search,
  Shield,
  Ban,
  CheckCircle2,
  AlertTriangle,
  Wallet,
  Trophy,
  Phone,
  Mail,
  UserX,
  Download,
} from 'lucide-react';
import {
  getUsers,
  toggleUserStatus,
  updateUserRole,
  logAdminActivity,
  exportToCsv,
  toggleUserVip,
} from '../services/adminService';
import { User, AdminRole } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useAuth } from '../context/AuthContext';

export const UsersView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Modals
  const [banConfirmUser, setBanConfirmUser] = useState<User | null>(null);
  const [roleChangeUser, setRoleChangeUser] = useState<User | null>(null);
  const [selectedRole, setSelectedRole] = useState<AdminRole>('USER');

  const loadUsers = async () => {
    try {
      setLoading(true);
      const data = await getUsers();
      setUsers(data);
    } catch (err) {
      console.error('Error loading users:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const handleToggleStatus = async (user: User) => {
    const nextStatus = user.status === 'Banned' ? 'Active' : 'Banned';
    try {
      await toggleUserStatus(user.id, nextStatus);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          nextStatus === 'Banned' ? 'BAN_USER' : 'UNBAN_USER',
          'users',
          `${nextStatus === 'Banned' ? 'Banned' : 'Unbanned'} user ${user.email}`,
          user.id
        );
      }
      setBanConfirmUser(null);
      await loadUsers();
    } catch (err) {
      console.error('Error toggling user status:', err);
    }
  };

  const handleConfirmRoleChange = async () => {
    if (!roleChangeUser || !adminProfile) return;
    try {
      await updateUserRole(roleChangeUser.id, selectedRole);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'CHANGE_USER_ROLE',
          'users',
          `Changed role of ${roleChangeUser.email} to ${selectedRole}`,
          roleChangeUser.id
        );
      }
      setRoleChangeUser(null);
      await loadUsers();
    } catch (err) {
      console.error('Error updating user role:', err);
    }
  };

  const handleExportCsv = () => {
    const rows = filteredUsers.map((u) => ({
      ID: u.id,
      Email: u.email,
      DisplayName: u.displayName || '',
      Phone: u.phoneNumber || '',
      FreeFire_UID: u.ffUid || '',
      FreeFire_IGN: u.ffIgn || '',
      Role: u.role,
      Status: u.status,
      WalletBalance: u.walletBalance || 0,
      TotalWinnings: u.totalWinnings || 0,
      TournamentsPlayed: u.tournamentsPlayed || 0,
      CreatedAt: new Date(u.createdAt).toLocaleString(),
    }));
    exportToCsv('registered_users', rows);
  };

  const filteredUsers = users.filter((u) => {
    const term = search.toLowerCase();
    const matchesSearch =
      u.email?.toLowerCase().includes(term) ||
      u.displayName?.toLowerCase().includes(term) ||
      u.phoneNumber?.includes(term) ||
      u.ffUid?.toLowerCase().includes(term) ||
      u.ffIgn?.toLowerCase().includes(term);
    const matchesStatus = statusFilter === 'ALL' || u.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-amber-400" />
            <span>User & Player Management</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Manage player profiles, Free Fire gamer tags, account statuses, and admin role assignments.
          </p>
        </div>
        <button
          id="btn-export-users-csv"
          onClick={handleExportCsv}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold border border-zinc-700 transition cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Filters & Search */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-xl">
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search email, name, UID, IGN, phone..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 cursor-pointer"
          >
            <option value="ALL">All Statuses ({users.length} users)</option>
            <option value="Active">Active</option>
            <option value="Suspended">Suspended</option>
            <option value="Banned">Banned</option>
          </select>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <LoadingSpinner text="Fetching users from Firestore..." />
      ) : filteredUsers.length === 0 ? (
        <EmptyState
          icon={UserCheck}
          title="No users found"
          description="There are currently no registered users matching your search in Firebase."
        />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-zinc-800 bg-zinc-900/60 shadow-xl">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="border-b border-zinc-800 bg-zinc-950/80 text-[10px] uppercase font-bold text-zinc-400 tracking-wider">
              <tr>
                <th className="px-4 py-3.5">Player / Account</th>
                <th className="px-4 py-3.5">Free Fire UID & IGN</th>
                <th className="px-4 py-3.5">Wallet Balance</th>
                <th className="px-4 py-3.5">Winnings</th>
                <th className="px-4 py-3.5">Role</th>
                <th className="px-4 py-3.5">Status</th>
                <th className="px-4 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60">
              {filteredUsers.map((u) => (
                <tr key={u.id} className="hover:bg-zinc-800/40 transition">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-white tracking-tight">{u.displayName || 'Unnamed User'}</span>
                      {u.isVip && (
                        <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[10px] font-extrabold border border-amber-500/40">
                          👑 VIP
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-zinc-400 mt-0.5">{u.email}</div>
                    {u.phoneNumber && <div className="text-[10px] text-zinc-500 font-mono">{u.phoneNumber}</div>}
                  </td>
                  <td className="px-4 py-3 font-mono">
                    <div className="text-amber-400 font-bold">{u.ffUid || 'Not Linked'}</div>
                    <div className="text-[11px] text-zinc-400">{u.ffIgn || 'No IGN'}</div>
                  </td>
                  <td className="px-4 py-3 font-mono">
                    <span className="font-bold text-emerald-400 text-sm">₹{u.walletBalance || 0}</span>
                  </td>
                  <td className="px-4 py-3 font-mono">
                    <span className="font-bold text-amber-400">₹{u.totalWinnings || 0}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded font-mono ${
                        u.role === 'SUPER_ADMIN'
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                          : u.role === 'TOURNAMENT_ADMIN'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : u.role === 'FINANCE_ADMIN'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-zinc-800 text-zinc-400'
                      }`}
                    >
                      {u.role}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                        u.status === 'Active'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                      }`}
                    >
                      {u.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={async () => {
                          await toggleUserVip(u.id, !u.isVip);
                          await loadUsers();
                        }}
                        title={u.isVip ? 'Remove VIP Pass' : 'Grant VIP Pass'}
                        className={`px-2 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                          u.isVip
                            ? 'bg-amber-500 text-black hover:bg-amber-400'
                            : 'bg-zinc-800 text-zinc-400 hover:text-amber-300'
                        }`}
                      >
                        👑 VIP
                      </button>
                      {role === 'SUPER_ADMIN' && (
                        <button
                          onClick={() => {
                            setRoleChangeUser(u);
                            setSelectedRole(u.role);
                          }}
                          title="Assign Admin Role"
                          className="p-1.5 rounded-lg text-purple-400 hover:bg-purple-500/10 transition cursor-pointer"
                        >
                          <Shield className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button
                        onClick={() => setBanConfirmUser(u)}
                        title={u.status === 'Banned' ? 'Unban Player' : 'Ban Player'}
                        className={`p-1.5 rounded-lg transition cursor-pointer ${
                          u.status === 'Banned'
                            ? 'text-emerald-400 hover:bg-emerald-500/10'
                            : 'text-rose-400 hover:bg-rose-500/10'
                        }`}
                      >
                        {u.status === 'Banned' ? (
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        ) : (
                          <Ban className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Role Assignment Modal */}
      {roleChangeUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl border border-zinc-800 bg-zinc-900 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Shield className="w-5 h-5 text-purple-400" />
              <span>Change User Role & Permissions</span>
            </h3>
            <p className="text-xs text-zinc-400">
              Assign role for <strong className="text-white">{roleChangeUser.email}</strong>
            </p>

            <div>
              <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                Admin Role Level
              </label>
              <select
                value={selectedRole}
                onChange={(e) => setSelectedRole(e.target.value as AdminRole)}
                className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
              >
                <option value="USER">USER (Standard Player)</option>
                <option value="SUPPORT_ADMIN">SUPPORT_ADMIN (Tickets & Users)</option>
                <option value="MATCH_MODERATOR">MATCH_MODERATOR (Rooms & Results)</option>
                <option value="TOURNAMENT_ADMIN">TOURNAMENT_ADMIN (Tournaments & Matches)</option>
                <option value="FINANCE_ADMIN">FINANCE_ADMIN (Deposits & Withdrawals)</option>
                <option value="SUPER_ADMIN">SUPER_ADMIN (Full Unlimited Access)</option>
              </select>
            </div>

            <div className="flex justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={() => setRoleChangeUser(null)}
                className="px-4 py-2 rounded-xl border border-zinc-700 text-xs font-semibold text-zinc-300 hover:bg-zinc-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRoleChange}
                className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg shadow-purple-600/20 cursor-pointer"
              >
                Apply Role
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Ban / Unban Confirmation */}
      {banConfirmUser && (
        <ConfirmationModal
          isOpen={true}
          title={banConfirmUser.status === 'Banned' ? 'Unban Player Account' : 'Ban Player Account'}
          message={`Are you sure you want to ${
            banConfirmUser.status === 'Banned' ? 'unban' : 'ban'
          } ${banConfirmUser.email}? ${
            banConfirmUser.status !== 'Banned'
              ? 'They will be instantly locked out from joining tournaments, deposits, and room lobbies.'
              : 'They will regain normal platform access.'
          }`}
          confirmText={banConfirmUser.status === 'Banned' ? 'Yes, Unban Account' : 'Yes, Ban Account'}
          isDangerous={banConfirmUser.status !== 'Banned'}
          onConfirm={() => handleToggleStatus(banConfirmUser)}
          onCancel={() => setBanConfirmUser(null)}
        />
      )}
    </div>
  );
};
