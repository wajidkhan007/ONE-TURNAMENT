import React, { useEffect, useState } from 'react';
import {
  Bell,
  Send,
  Trash2,
  Users,
  AlertTriangle,
  Info,
  KeyRound,
  Wallet,
  CheckCircle2,
} from 'lucide-react';
import {
  getNotifications,
  sendNotification,
  deleteNotification,
  getTournaments,
  logAdminActivity,
} from '../services/adminService';
import { AppNotification, Tournament } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useAuth } from '../context/AuthContext';

export const NotificationsView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Form states
  const [title, setTitle] = useState<string>('');
  const [message, setMessage] = useState<string>('');
  const [type, setType] = useState<'info' | 'alert' | 'match' | 'wallet'>('info');
  const [target, setTarget] = useState<'ALL' | 'TOURNAMENT_PARTICIPANTS'>('ALL');
  const [selectedTournId, setSelectedTournId] = useState<string>('');
  const [sending, setSending] = useState<boolean>(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const loadData = async () => {
    try {
      setLoading(true);
      const [notifs, tours] = await Promise.all([
        getNotifications(),
        getTournaments(),
      ]);
      setNotifications(notifs);
      setTournaments(tours);
      if (tours.length > 0) setSelectedTournId(tours[0].id);
    } catch (err) {
      console.error('Error loading notifications:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSendNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim()) {
      alert('Title and Message are required');
      return;
    }

    setSending(true);
    try {
      await sendNotification({
        title: title.trim(),
        message: message.trim(),
        type,
        target,
        targetTournamentId: target === 'TOURNAMENT_PARTICIPANTS' ? selectedTournId : undefined,
        sentBy: adminProfile?.email || 'admin',
      });

      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'SEND_BROADCAST_NOTIFICATION',
          'notifications',
          `Broadcasted "${title}" to ${target}`
        );
      }

      setTitle('');
      setMessage('');
      await loadData();
      alert('Notification broadcasted successfully!');
    } catch (err) {
      console.error('Error sending notification:', err);
      alert('Failed to broadcast notification');
    } finally {
      setSending(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteConfirmId) return;
    try {
      await deleteNotification(deleteConfirmId);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'DELETE_NOTIFICATION',
          'notifications',
          `Deleted notification ${deleteConfirmId}`,
          deleteConfirmId
        );
      }
      setDeleteConfirmId(null);
      await loadData();
    } catch (err) {
      console.error('Error deleting notification:', err);
    }
  };

  const getTypeIcon = (t: string) => {
    switch (t) {
      case 'alert':
        return <AlertTriangle className="w-4 h-4 text-rose-400" />;
      case 'match':
        return <KeyRound className="w-4 h-4 text-amber-400" />;
      case 'wallet':
        return <Wallet className="w-4 h-4 text-emerald-400" />;
      default:
        return <Info className="w-4 h-4 text-cyan-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
          <Bell className="w-5 h-5 text-amber-400" />
          <span>Push Notifications & Platform Broadcasts</span>
        </h1>
        <p className="text-xs text-zinc-400 mt-0.5">
          Send real-time alerts, room updates, tournament reminders, and maintenance notices to registered players.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Broadcast Composer */}
        <div className="lg:col-span-1">
          <div className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-5 space-y-4 shadow-xl">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Send className="w-4 h-4 text-amber-400" />
              <span>Compose Broadcast Alert</span>
            </h2>

            <form onSubmit={handleSendNotification} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Recipient Target Audience
                </label>
                <select
                  value={target}
                  onChange={(e) => setTarget(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
                >
                  <option value="ALL">All Registered Players</option>
                  <option value="TOURNAMENT_PARTICIPANTS">Specific Tournament Participants</option>
                </select>
              </div>

              {target === 'TOURNAMENT_PARTICIPANTS' && (
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Select Tournament
                  </label>
                  <select
                    value={selectedTournId}
                    onChange={(e) => setSelectedTournId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
                  >
                    {tournaments.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Notification Category
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['info', 'alert', 'match', 'wallet'] as const).map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setType(cat)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold capitalize flex items-center justify-center gap-1.5 transition cursor-pointer ${
                        type === cat
                          ? 'bg-amber-500 text-zinc-950 shadow'
                          : 'bg-zinc-950 text-zinc-400 border border-zinc-800 hover:text-white'
                      }`}
                    >
                      {getTypeIcon(cat)}
                      <span>{cat}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Headline Title <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Free Fire Room ID Live!"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Message Content <span className="text-rose-400">*</span>
                </label>
                <textarea
                  rows={3}
                  required
                  placeholder="e.g. Room ID and password for Match #2 have been published..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
                />
              </div>

              <button
                type="submit"
                disabled={sending}
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow-lg shadow-amber-500/20 active:scale-95 transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>{sending ? 'Broadcasting...' : 'Broadcast Notification'}</span>
              </button>
            </form>
          </div>
        </div>

        {/* History List */}
        <div className="lg:col-span-2">
          <div className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-5 space-y-4 shadow-xl">
            <h2 className="text-sm font-bold text-white flex items-center justify-between">
              <span>Broadcast History ({notifications.length})</span>
            </h2>

            {loading ? (
              <LoadingSpinner text="Fetching broadcast history from Firestore..." />
            ) : notifications.length === 0 ? (
              <EmptyState
                icon={Bell}
                title="No broadcast notifications sent"
                description="Use the composer on the left to send announcements to your players."
              />
            ) : (
              <div className="space-y-3 max-h-[600px] overflow-y-auto">
                {notifications.map((n) => (
                  <div
                    key={n.id}
                    className="p-4 rounded-xl bg-zinc-950 border border-zinc-800/80 space-y-2 hover:border-zinc-700 transition"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <div className="p-1.5 rounded-lg bg-zinc-900 border border-zinc-800">
                          {getTypeIcon(n.type)}
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-white">{n.title}</h4>
                          <span className="text-[10px] text-zinc-500">
                            Sent by {n.sentBy || 'Admin'} • {new Date(n.createdAt).toLocaleString()}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-zinc-900 text-amber-400 border border-zinc-800 uppercase">
                          {n.target}
                        </span>
                        <button
                          onClick={() => setDeleteConfirmId(n.id)}
                          className="p-1 rounded text-zinc-500 hover:text-rose-400 hover:bg-zinc-800 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                    <p className="text-xs text-zinc-300 pl-8">{n.message}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <ConfirmationModal
        isOpen={!!deleteConfirmId}
        title="Delete Notification"
        message="Are you sure you want to remove this notification record from Firebase?"
        isDangerous
        onConfirm={handleDelete}
        onCancel={() => setDeleteConfirmId(null)}
      />
    </div>
  );
};
