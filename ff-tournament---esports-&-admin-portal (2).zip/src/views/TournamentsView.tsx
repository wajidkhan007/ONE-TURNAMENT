import React, { useEffect, useState } from 'react';
import {
  Trophy,
  Plus,
  Search,
  Filter,
  MoreVertical,
  Edit2,
  Trash2,
  Copy,
  Play,
  CheckCircle,
  XCircle,
  Calendar,
  Clock,
  Users,
  MapPin,
  Flame,
  AlertCircle,
  Eye,
} from 'lucide-react';
import { getTournaments, saveTournament, deleteTournament, logAdminActivity } from '../services/adminService';
import { Tournament, TournamentType, TournamentStatus, GameMap, GameMode } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useAuth } from '../context/AuthContext';

export const TournamentsView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterType, setFilterType] = useState<string>('ALL');

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingTournament, setEditingTournament] = useState<Partial<Tournament> | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [saving, setSaving] = useState<boolean>(false);

  const loadTournaments = async () => {
    try {
      setLoading(true);
      const data = await getTournaments();
      setTournaments(data);
    } catch (err) {
      console.error('Error loading tournaments:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTournaments();
  }, []);

  const handleOpenCreate = () => {
    setEditingTournament({
      name: '',
      description: '',
      bannerUrl: '',
      type: 'Solo',
      entryFee: 50,
      prizePool: 2000,
      firstPrize: 1000,
      secondPrize: 600,
      thirdPrize: 400,
      perKillPrize: 10,
      maxTeams: 48,
      date: new Date().toISOString().split('T')[0],
      time: '19:00',
      registrationClosingTime: '18:30',
      map: 'Bermuda',
      mode: 'Battle Royale',
      matchCount: 1,
      rules: '1. No emulators allowed.\n2. UID must match registered player.\n3. Hackers will be banned permanently.\n4. Room details given 15 mins before match.',
      status: 'Registration Open',
      isFeatured: false,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (t: Tournament) => {
    setEditingTournament({ ...t });
    setIsModalOpen(true);
  };

  const handleDuplicate = async (t: Tournament) => {
    try {
      const duplicateData: Partial<Tournament> = {
        ...t,
        id: undefined,
        name: `${t.name} (Copy)`,
        currentRegistrations: 0,
        status: 'Draft',
        createdAt: Date.now(),
      };
      await saveTournament(duplicateData);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'DUPLICATE_TOURNAMENT',
          'tournaments',
          `Duplicated tournament: ${t.name}`,
          t.id
        );
      }
      await loadTournaments();
    } catch (err) {
      console.error('Error duplicating tournament:', err);
      alert('Failed to duplicate tournament');
    }
  };

  const handleQuickStatusChange = async (t: Tournament, newStatus: TournamentStatus) => {
    try {
      await saveTournament({ id: t.id, status: newStatus });
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'STATUS_CHANGE',
          'tournaments',
          `Changed status of ${t.name} to ${newStatus}`,
          t.id
        );
      }
      await loadTournaments();
    } catch (err) {
      console.error('Error updating status:', err);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTournament?.name?.trim()) {
      alert('Tournament name is required');
      return;
    }
    setSaving(true);
    try {
      await saveTournament({
        ...editingTournament,
        createdBy: adminProfile?.email || 'admin',
      });

      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          editingTournament.id ? 'EDIT_TOURNAMENT' : 'CREATE_TOURNAMENT',
          'tournaments',
          `${editingTournament.id ? 'Edited' : 'Created'} tournament: ${editingTournament.name}`,
          editingTournament.id
        );
      }

      setIsModalOpen(false);
      setEditingTournament(null);
      await loadTournaments();
    } catch (err: any) {
      console.error('Error saving tournament:', err);
      alert(`Failed to save tournament: ${err?.message || 'Unexpected error'}`);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteConfirmId) return;
    try {
      const tour = tournaments.find((t) => t.id === deleteConfirmId);
      await deleteTournament(deleteConfirmId);

      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'DELETE_TOURNAMENT',
          'tournaments',
          `Deleted tournament: ${tour?.name || deleteConfirmId}`,
          deleteConfirmId
        );
      }

      setDeleteConfirmId(null);
      await loadTournaments();
    } catch (err) {
      console.error('Error deleting tournament:', err);
      alert('Failed to delete tournament');
    }
  };

  const filteredTournaments = tournaments.filter((t) => {
    const matchesSearch =
      t.name.toLowerCase().includes(search.toLowerCase()) ||
      t.map?.toLowerCase().includes(search.toLowerCase()) ||
      t.type.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = filterStatus === 'ALL' || t.status === filterStatus;
    const matchesType = filterType === 'ALL' || t.type === filterType;
    return matchesSearch && matchesStatus && matchesType;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <span>Tournament Management</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Create, schedule, edit, duplicate, and control live status of Free Fire esports events.
          </p>
        </div>
        <button
          id="btn-create-new-tournament"
          onClick={handleOpenCreate}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold transition shadow-lg shadow-amber-500/20 active:scale-95 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Create Tournament</span>
        </button>
      </div>

      {/* Filters & Search */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="input-search-tournaments"
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search tournament name, map, mode..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div>
          <select
            id="select-filter-status"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 cursor-pointer"
          >
            <option value="ALL">All Statuses ({tournaments.length})</option>
            <option value="Registration Open">Registration Open</option>
            <option value="Registration Closed">Registration Closed</option>
            <option value="Live">Live</option>
            <option value="Draft">Draft</option>
            <option value="Completed">Completed</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>

        <div>
          <select
            id="select-filter-type"
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 cursor-pointer"
          >
            <option value="ALL">All Formats (Solo / Duo / Squad)</option>
            <option value="Solo">Solo</option>
            <option value="Duo">Duo</option>
            <option value="Squad">Squad</option>
          </select>
        </div>
      </div>

      {/* Tournament List */}
      {loading ? (
        <LoadingSpinner text="Fetching tournaments from Firestore..." />
      ) : filteredTournaments.length === 0 ? (
        <EmptyState
          icon={Trophy}
          title="No tournaments available"
          description="There are currently no tournaments matching your filters in Firebase."
          actionLabel="Create Tournament"
          onAction={handleOpenCreate}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredTournaments.map((t) => (
            <div
              key={t.id}
              className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-5 flex flex-col justify-between hover:border-zinc-700 transition space-y-4"
            >
              <div>
                {/* Status & Format tags */}
                <div className="flex items-center justify-between gap-2 mb-2.5">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                      t.status === 'Registration Open'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : t.status === 'Live'
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20 animate-pulse'
                        : t.status === 'Completed'
                        ? 'bg-zinc-800 text-zinc-400'
                        : t.status === 'Registration Closed'
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        : 'bg-zinc-800 text-zinc-300'
                    }`}
                  >
                    {t.status}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 border border-zinc-700">
                      {t.type}
                    </span>
                    <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 border border-zinc-700">
                      {t.map}
                    </span>
                  </div>
                </div>

                <h3 className="text-base font-bold text-white tracking-tight leading-snug line-clamp-1">
                  {t.name}
                </h3>
                <p className="text-xs text-zinc-400 mt-1 line-clamp-2">{t.description || 'No description provided'}</p>

                {/* Metrics Grid */}
                <div className="grid grid-cols-2 gap-2 mt-4 p-3 rounded-xl bg-zinc-950/80 border border-zinc-800/80 text-xs">
                  <div>
                    <span className="text-[10px] text-zinc-500 uppercase font-semibold">Entry Fee</span>
                    <p className="font-bold text-amber-400 font-mono text-sm">₹{t.entryFee}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-zinc-500 uppercase font-semibold">Prize Pool</span>
                    <p className="font-bold text-emerald-400 font-mono text-sm">₹{t.prizePool}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-zinc-500 uppercase font-semibold">Schedule</span>
                    <p className="text-zinc-300 font-medium text-[11px] truncate">
                      {t.date} @ {t.time}
                    </p>
                  </div>
                  <div>
                    <span className="text-[10px] text-zinc-500 uppercase font-semibold">Slots</span>
                    <p className="text-zinc-300 font-mono font-medium text-[11px]">
                      {t.currentRegistrations || 0} / {t.maxTeams}
                    </p>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-zinc-800/80 flex items-center justify-between gap-1 text-xs">
                {/* Status Switcher */}
                <select
                  value={t.status}
                  onChange={(e) => handleQuickStatusChange(t, e.target.value as TournamentStatus)}
                  className="px-2 py-1 rounded-lg bg-zinc-950 border border-zinc-800 text-[11px] text-zinc-300 font-medium focus:outline-none focus:border-amber-500 cursor-pointer"
                >
                  <option value="Draft">Draft</option>
                  <option value="Registration Open">Open Reg</option>
                  <option value="Registration Closed">Close Reg</option>
                  <option value="Live">Go Live</option>
                  <option value="Completed">End (Completed)</option>
                  <option value="Cancelled">Cancel</option>
                </select>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleDuplicate(t)}
                    title="Duplicate Tournament"
                    className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleOpenEdit(t)}
                    title="Edit Details"
                    className="p-1.5 rounded-lg text-amber-400 hover:text-amber-300 hover:bg-zinc-800 transition cursor-pointer"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setDeleteConfirmId(t.id)}
                    title="Delete Tournament"
                    className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-zinc-800 transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create / Edit Modal */}
      {isModalOpen && editingTournament && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-2xl rounded-2xl border border-zinc-800 bg-zinc-900 p-6 shadow-2xl my-8 max-h-[90vh] overflow-y-auto">
            <h2 className="text-lg font-bold text-white mb-4">
              {editingTournament.id ? 'Edit Tournament' : 'Create New Tournament'}
            </h2>

            <form onSubmit={handleSave} className="space-y-4">
              {/* Name */}
              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Tournament Name <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={editingTournament.name || ''}
                  onChange={(e) => setEditingTournament({ ...editingTournament, name: e.target.value })}
                  placeholder="e.g. Free Fire Bermuda Championship #24"
                  className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Format & Mode & Map */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Format</label>
                  <select
                    value={editingTournament.type || 'Solo'}
                    onChange={(e) => setEditingTournament({ ...editingTournament, type: e.target.value as TournamentType })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="Solo">Solo</option>
                    <option value="Duo">Duo</option>
                    <option value="Squad">Squad</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Map</label>
                  <select
                    value={editingTournament.map || 'Bermuda'}
                    onChange={(e) => setEditingTournament({ ...editingTournament, map: e.target.value as GameMap })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="Bermuda">Bermuda</option>
                    <option value="Purgatory">Purgatory</option>
                    <option value="Kalahari">Kalahari</option>
                    <option value="Alpine">Alpine</option>
                    <option value="NexTerra">NexTerra</option>
                    <option value="Random">Random</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Game Mode</label>
                  <select
                    value={editingTournament.mode || 'Battle Royale'}
                    onChange={(e) => setEditingTournament({ ...editingTournament, mode: e.target.value as GameMode })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="Battle Royale">Battle Royale</option>
                    <option value="Clash Squad">Clash Squad</option>
                    <option value="Custom Classic">Custom Classic</option>
                    <option value="Hardcore">Hardcore</option>
                  </select>
                </div>
              </div>

              {/* Financials: Entry Fee, Prize Pool, First, Second, Per Kill */}
              <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3">
                <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                  Financials & Prize Breakdown (₹)
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">Entry Fee (₹)</label>
                    <input
                      type="number"
                      min={0}
                      value={editingTournament.entryFee ?? 0}
                      onChange={(e) => setEditingTournament({ ...editingTournament, entryFee: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-sm text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">Total Prize Pool (₹)</label>
                    <input
                      type="number"
                      min={0}
                      value={editingTournament.prizePool ?? 0}
                      onChange={(e) => setEditingTournament({ ...editingTournament, prizePool: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-sm text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">1st Prize (₹)</label>
                    <input
                      type="number"
                      min={0}
                      value={editingTournament.firstPrize ?? 0}
                      onChange={(e) => setEditingTournament({ ...editingTournament, firstPrize: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-sm text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">2nd Prize (₹)</label>
                    <input
                      type="number"
                      min={0}
                      value={editingTournament.secondPrize ?? 0}
                      onChange={(e) => setEditingTournament({ ...editingTournament, secondPrize: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-sm text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">3rd Prize (₹)</label>
                    <input
                      type="number"
                      min={0}
                      value={editingTournament.thirdPrize ?? 0}
                      onChange={(e) => setEditingTournament({ ...editingTournament, thirdPrize: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-sm text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">Per Kill Prize (₹)</label>
                    <input
                      type="number"
                      min={0}
                      value={editingTournament.perKillPrize ?? 0}
                      onChange={(e) => setEditingTournament({ ...editingTournament, perKillPrize: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-sm text-white font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Date, Time, Registration Closing, Max Teams */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Date</label>
                  <input
                    type="date"
                    value={editingTournament.date || ''}
                    onChange={(e) => setEditingTournament({ ...editingTournament, date: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Match Time</label>
                  <input
                    type="time"
                    value={editingTournament.time || ''}
                    onChange={(e) => setEditingTournament({ ...editingTournament, time: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Reg Closing</label>
                  <input
                    type="time"
                    value={editingTournament.registrationClosingTime || ''}
                    onChange={(e) => setEditingTournament({ ...editingTournament, registrationClosingTime: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Max Slots</label>
                  <input
                    type="number"
                    min={2}
                    value={editingTournament.maxTeams ?? 48}
                    onChange={(e) => setEditingTournament({ ...editingTournament, maxTeams: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white font-mono"
                  />
                </div>
              </div>

              {/* Status & Banner URL */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Status</label>
                  <select
                    value={editingTournament.status || 'Draft'}
                    onChange={(e) => setEditingTournament({ ...editingTournament, status: e.target.value as TournamentStatus })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
                  >
                    <option value="Draft">Draft</option>
                    <option value="Registration Open">Registration Open</option>
                    <option value="Registration Closed">Registration Closed</option>
                    <option value="Live">Live</option>
                    <option value="Completed">Completed</option>
                    <option value="Cancelled">Cancelled</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Banner Image URL</label>
                  <input
                    type="url"
                    value={editingTournament.bannerUrl || ''}
                    onChange={(e) => setEditingTournament({ ...editingTournament, bannerUrl: e.target.value })}
                    placeholder="https://example.com/banner.jpg"
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
                  />
                </div>
              </div>

              {/* Live Stream & Social Links */}
              <div className="p-3 bg-zinc-950/80 rounded-xl border border-zinc-800 space-y-3">
                <span className="text-xs font-bold text-amber-400">📺 Live Stream & Community Links</span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">YouTube Live Stream Embed URL</label>
                    <input
                      type="text"
                      value={editingTournament.liveStreamUrl || ''}
                      onChange={(e) => setEditingTournament({ ...editingTournament, liveStreamUrl: e.target.value })}
                      placeholder="https://www.youtube.com/embed/..."
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">Discord Invite Link</label>
                    <input
                      type="url"
                      value={editingTournament.discordLink || ''}
                      onChange={(e) => setEditingTournament({ ...editingTournament, discordLink: e.target.value })}
                      placeholder="https://discord.gg/..."
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">Telegram Channel Link</label>
                    <input
                      type="url"
                      value={editingTournament.telegramLink || ''}
                      onChange={(e) => setEditingTournament({ ...editingTournament, telegramLink: e.target.value })}
                      placeholder="https://t.me/..."
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                    />
                  </div>
                </div>
              </div>

              {/* Custom Room ID & Password Control */}
              <div className="p-4 rounded-xl bg-zinc-950 border border-amber-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                    <span>🔑 Custom Room Credentials (Auto-Sync to Player Profile)</span>
                  </h4>
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-zinc-300">
                    <input
                      type="checkbox"
                      checked={editingTournament.isRoomPublished ?? false}
                      onChange={(e) =>
                        setEditingTournament({ ...editingTournament, isRoomPublished: e.target.checked })
                      }
                      className="rounded accent-amber-500"
                    />
                    <span>Publish Credentials to Players</span>
                  </label>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">Room ID</label>
                    <input
                      type="text"
                      value={editingTournament.roomId || ''}
                      onChange={(e) => setEditingTournament({ ...editingTournament, roomId: e.target.value })}
                      placeholder="e.g. 84920192"
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-sm text-amber-400 font-mono focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">Room Password</label>
                    <input
                      type="text"
                      value={editingTournament.roomPassword || ''}
                      onChange={(e) => setEditingTournament({ ...editingTournament, roomPassword: e.target.value })}
                      placeholder="e.g. 1234 or gg99"
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-sm text-amber-400 font-mono focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
              </div>

              {/* Rules */}
              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Rules & Guidelines</label>
                <textarea
                  rows={3}
                  value={editingTournament.rules || ''}
                  onChange={(e) => setEditingTournament({ ...editingTournament, rules: e.target.value })}
                  placeholder="Enter tournament rules and requirements..."
                  className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Buttons */}
              <div className="flex justify-end gap-3 pt-4 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-zinc-700 text-xs font-semibold text-zinc-300 hover:bg-zinc-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow-lg shadow-amber-500/20 cursor-pointer disabled:opacity-50"
                >
                  {saving ? 'Saving to Firestore...' : editingTournament.id ? 'Update Tournament' : 'Create Tournament'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={!!deleteConfirmId}
        title="Delete Tournament"
        message="Are you sure you want to permanently delete this tournament from Firebase? This action cannot be undone."
        confirmText="Delete Tournament"
        isDangerous
        onConfirm={handleDelete}
        onCancel={() => setDeleteConfirmId(null)}
      />
    </div>
  );
};
