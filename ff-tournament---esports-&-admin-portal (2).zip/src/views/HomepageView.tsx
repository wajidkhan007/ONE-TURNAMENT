import React, { useEffect, useState } from 'react';
import {
  Globe,
  Save,
  Image,
  Layers,
  CheckCircle2,
  Trophy,
} from 'lucide-react';
import {
  getHomepageSettings,
  saveHomepageSettings,
  getTournaments,
  logAdminActivity,
} from '../services/adminService';
import { HomepageSettings, Tournament } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { useAuth } from '../context/AuthContext';

export const HomepageView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [settings, setSettings] = useState<HomepageSettings | null>(null);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [success, setSuccess] = useState<boolean>(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const [homeData, tourData] = await Promise.all([
        getHomepageSettings(),
        getTournaments(),
      ]);
      setSettings(homeData);
      setTournaments(tourData);
    } catch (err) {
      console.error('Error loading homepage settings:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    setSaving(true);
    setSuccess(false);
    try {
      await saveHomepageSettings(settings);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'UPDATE_HOMEPAGE_CMS',
          'homepage',
          'Updated homepage hero text & section visibility'
        );
      }
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      console.error('Error saving homepage settings:', err);
      alert('Failed to save homepage settings');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <LoadingSpinner text="Loading CMS and homepage control..." />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
          <Globe className="w-5 h-5 text-amber-400" />
          <span>Homepage CMS & Banner Control</span>
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Customize website hero copy, CTA buttons, featured tournaments, and section visibility.
        </p>
      </div>

      {success && (
        <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>Homepage CMS updated successfully!</span>
        </div>
      )}

      {settings && (
        <form onSubmit={handleSave} className="space-y-6">
          {/* Hero Section */}
          <div className="rounded-2xl border border-[#1E1E24] bg-[#0F1115] p-6 space-y-4">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              <span>Hero Banner & Call-to-Action</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Main Headline
                </label>
                <input
                  type="text"
                  required
                  value={settings.heroHeadline}
                  onChange={(e) => setSettings({ ...settings, heroHeadline: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-sm text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Hero Banner Image URL
                </label>
                <input
                  type="url"
                  value={settings.heroBannerUrl || ''}
                  placeholder="https://example.com/hero.jpg"
                  onChange={(e) => setSettings({ ...settings, heroBannerUrl: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-sm text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                Sub-Headline / Tagline
              </label>
              <textarea
                rows={2}
                value={settings.heroSubheadline}
                onChange={(e) => setSettings({ ...settings, heroSubheadline: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  CTA Button Label
                </label>
                <input
                  type="text"
                  value={settings.ctaButtonText}
                  onChange={(e) => setSettings({ ...settings, ctaButtonText: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  CTA Button Target Link
                </label>
                <input
                  type="text"
                  value={settings.ctaButtonLink}
                  onChange={(e) => setSettings({ ...settings, ctaButtonLink: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white"
                />
              </div>
            </div>
          </div>

          {/* Section Visibility Toggles */}
          <div className="rounded-2xl border border-[#1E1E24] bg-[#0F1115] p-6 space-y-4">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Globe className="w-4 h-4 text-amber-400" />
              <span>Section Visibility on Homepage</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#0A0A0B] border border-[#1E1E24]">
                <div>
                  <p className="font-semibold text-white">Upcoming Tournaments Section</p>
                  <p className="text-slate-400 text-[11px]">Showcase registration-open matches</p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.showUpcomingSection}
                  onChange={(e) =>
                    setSettings({ ...settings, showUpcomingSection: e.target.checked })
                  }
                  className="w-5 h-5 accent-amber-500 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-[#0A0A0B] border border-[#1E1E24]">
                <div>
                  <p className="font-semibold text-white">Live Matches Section</p>
                  <p className="text-slate-400 text-[11px]">Show live running tournaments</p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.showLiveSection}
                  onChange={(e) =>
                    setSettings({ ...settings, showLiveSection: e.target.checked })
                  }
                  className="w-5 h-5 accent-amber-500 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-[#0A0A0B] border border-[#1E1E24]">
                <div>
                  <p className="font-semibold text-white">Completed Tournaments Section</p>
                  <p className="text-slate-400 text-[11px]">Archive of finished events</p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.showCompletedSection}
                  onChange={(e) =>
                    setSettings({ ...settings, showCompletedSection: e.target.checked })
                  }
                  className="w-5 h-5 accent-amber-500 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-[#0A0A0B] border border-[#1E1E24]">
                <div>
                  <p className="font-semibold text-white">Leaderboard Preview Section</p>
                  <p className="text-slate-400 text-[11px]">Show top team standings on home</p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.showLeaderboardPreview}
                  onChange={(e) =>
                    setSettings({ ...settings, showLeaderboardPreview: e.target.checked })
                  }
                  className="w-5 h-5 accent-amber-500 cursor-pointer"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow-lg shadow-amber-500/20 flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Saving to Firestore...' : 'Save Homepage Settings'}</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
