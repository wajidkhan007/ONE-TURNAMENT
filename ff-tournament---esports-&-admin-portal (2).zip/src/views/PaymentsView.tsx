import React, { useEffect, useState } from 'react';
import {
  CreditCard,
  Search,
  CheckCircle2,
  XCircle,
  Eye,
  AlertCircle,
  Download,
  Image as ImageIcon,
  ExternalLink,
} from 'lucide-react';
import { getPayments, updateRegistrationStatus, logAdminActivity, exportToCsv } from '../services/adminService';
import { PaymentSubmission } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useAuth } from '../context/AuthContext';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';

export const PaymentsView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [payments, setPayments] = useState<PaymentSubmission[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Preview screenshot modal
  const [viewScreenshotUrl, setViewScreenshotUrl] = useState<string | null>(null);
  const [rejectId, setRejectId] = useState<string | null>(null);

  const loadPayments = async () => {
    try {
      setLoading(true);
      const data = await getPayments();
      setPayments(data);
    } catch (err) {
      console.error('Error loading payments:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPayments();
  }, []);

  const handleApprovePayment = async (pay: PaymentSubmission) => {
    try {
      const docRef = doc(db, 'payments', pay.id);
      await updateDoc(docRef, {
        status: 'Approved',
        processedAt: Date.now(),
        processedBy: adminProfile?.email || 'admin',
      });

      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'APPROVE_PAYMENT',
          'payments',
          `Approved payment of ₹${pay.amount} (UTR: ${pay.utrNumber}) from ${pay.userEmail}`,
          pay.id
        );
      }
      await loadPayments();
    } catch (err) {
      console.error('Error approving payment:', err);
    }
  };

  const handleRejectConfirm = async (reason?: string) => {
    if (!rejectId) return;
    try {
      const pay = payments.find((p) => p.id === rejectId);
      const docRef = doc(db, 'payments', rejectId);
      await updateDoc(docRef, {
        status: 'Rejected',
        adminNote: reason || 'Payment could not be verified',
        processedAt: Date.now(),
        processedBy: adminProfile?.email || 'admin',
      });

      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'REJECT_PAYMENT',
          'payments',
          `Rejected payment (UTR: ${pay?.utrNumber || rejectId}). Reason: ${reason || 'N/A'}`,
          rejectId
        );
      }
      setRejectId(null);
      await loadPayments();
    } catch (err) {
      console.error('Error rejecting payment:', err);
    }
  };

  const handleExportCsv = () => {
    const rows = filteredPayments.map((p) => ({
      ID: p.id,
      UserEmail: p.userEmail,
      Tournament: p.tournamentName || 'N/A',
      Amount: p.amount,
      UTR_Number: p.utrNumber,
      Method: p.paymentMethod,
      Status: p.status,
      Date: new Date(p.createdAt).toLocaleString(),
      AdminNote: p.adminNote || '',
    }));
    exportToCsv('tournament_payments', rows);
  };

  const filteredPayments = payments.filter((p) => {
    const term = search.toLowerCase();
    const matchesSearch =
      p.userEmail?.toLowerCase().includes(term) ||
      p.utrNumber?.toLowerCase().includes(term) ||
      p.tournamentName?.toLowerCase().includes(term);
    const matchesStatus = statusFilter === 'ALL' || p.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-amber-400" />
            <span>Payment Management & Manual Verification</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Verify manual UPI payments, scan UTR numbers, review uploaded transaction screenshots, and approve or reject submissions.
          </p>
        </div>
        <button
          id="btn-export-payments-csv"
          onClick={handleExportCsv}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold border border-zinc-700 transition cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Filters & Search */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-xl">
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by User Email, UTR, Tournament..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 cursor-pointer"
          >
            <option value="ALL">All Payment Statuses ({payments.length})</option>
            <option value="Pending">Pending Verification</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Payments List / Table */}
      {loading ? (
        <LoadingSpinner text="Fetching payments from Firestore..." />
      ) : filteredPayments.length === 0 ? (
        <EmptyState
          icon={CreditCard}
          title="No payments found"
          description="There are currently no manual payment submissions matching your search criteria in Firebase."
        />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-zinc-800 bg-zinc-900/60 shadow-xl">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="border-b border-zinc-800 bg-zinc-950/80 text-[10px] uppercase font-bold text-zinc-400 tracking-wider">
              <tr>
                <th className="px-4 py-3.5">User & Tournament</th>
                <th className="px-4 py-3.5">Amount</th>
                <th className="px-4 py-3.5">UTR / TxID</th>
                <th className="px-4 py-3.5">Screenshot</th>
                <th className="px-4 py-3.5">Status</th>
                <th className="px-4 py-3.5">Date</th>
                <th className="px-4 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60">
              {filteredPayments.map((p) => (
                <tr key={p.id} className="hover:bg-zinc-800/40 transition">
                  <td className="px-4 py-3">
                    <div className="font-bold text-white tracking-tight">{p.userEmail}</div>
                    <div className="text-[11px] text-zinc-400 mt-0.5">{p.tournamentName || 'Tournament Fee'}</div>
                  </td>
                  <td className="px-4 py-3 font-mono">
                    <span className="font-bold text-emerald-400 text-sm">₹{p.amount}</span>
                    <span className="text-[10px] text-zinc-500 block uppercase">{p.paymentMethod}</span>
                  </td>
                  <td className="px-4 py-3 font-mono font-bold text-amber-400">
                    {p.utrNumber || 'N/A'}
                  </td>
                  <td className="px-4 py-3">
                    {p.screenshotUrl ? (
                      <button
                        onClick={() => setViewScreenshotUrl(p.screenshotUrl!)}
                        className="inline-flex items-center gap-1 px-2 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[11px] transition cursor-pointer"
                      >
                        <ImageIcon className="w-3 h-3 text-amber-400" />
                        <span>View Proof</span>
                      </button>
                    ) : (
                      <span className="text-zinc-500 text-[11px]">No image</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                        p.status === 'Approved'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : p.status === 'Rejected'
                          ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/20 animate-pulse'
                      }`}
                    >
                      {p.status}
                    </span>
                    {p.adminNote && (
                      <span className="block text-[10px] text-zinc-400 mt-1 truncate max-w-[120px]">
                        {p.adminNote}
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-[11px] text-zinc-400 font-mono">
                    {new Date(p.createdAt).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </td>
                  <td className="px-4 py-3 text-right">
                    {p.status === 'Pending' ? (
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleApprovePayment(p)}
                          className="px-2.5 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs transition cursor-pointer"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => setRejectId(p.id)}
                          className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 font-bold text-xs border border-rose-500/30 transition cursor-pointer"
                        >
                          Reject
                        </button>
                      </div>
                    ) : (
                      <span className="text-[11px] text-zinc-500">Processed</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Screenshot Zoom Modal */}
      {viewScreenshotUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="relative max-w-2xl w-full bg-zinc-900 rounded-2xl border border-zinc-800 p-4 shadow-2xl">
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-sm font-bold text-white">Payment Screenshot / Receipt Proof</h3>
              <button
                onClick={() => setViewScreenshotUrl(null)}
                className="text-zinc-400 hover:text-white p-1 rounded-lg"
              >
                ✕
              </button>
            </div>
            <div className="max-h-[75vh] overflow-auto flex items-center justify-center rounded-xl bg-black p-2">
              <img
                src={viewScreenshotUrl}
                alt="Payment proof screenshot"
                className="max-h-[70vh] object-contain rounded-lg"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="mt-3 flex justify-between items-center">
              <a
                href={viewScreenshotUrl}
                target="_blank"
                rel="noreferrer"
                className="text-xs text-amber-400 hover:underline flex items-center gap-1"
              >
                <span>Open in full resolution</span>
                <ExternalLink className="w-3 h-3" />
              </a>
              <button
                onClick={() => setViewScreenshotUrl(null)}
                className="px-4 py-1.5 rounded-lg bg-zinc-800 text-xs font-semibold text-white hover:bg-zinc-700 cursor-pointer"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject Modal */}
      <ConfirmationModal
        isOpen={!!rejectId}
        title="Reject Payment Submission"
        message="Please provide a mandatory note describing why this payment could not be approved (e.g., UTR not found on bank statement, amount mismatch)."
        confirmText="Reject Payment"
        isDangerous
        requireReason
        reasonPlaceholder="e.g. UTR not found on bank statement or incorrect amount..."
        onConfirm={handleRejectConfirm}
        onCancel={() => setRejectId(null)}
      />
    </div>
  );
};
