import React, { useEffect, useState } from 'react';
import {
  Users,
  Trophy,
  Flame,
  CheckCircle2,
  Clock,
  CreditCard,
  ArrowDownCircle,
  ArrowUpCircle,
  DollarSign,
  Award,
  TrendingUp,
  AlertCircle,
  Plus,
  RefreshCw,
  ExternalLink,
  ShieldCheck,
  Radio,
} from 'lucide-react';
import {
  subscribeDashboardStats,
  subscribeTournaments,
  subscribeDeposits,
  subscribeWithdrawals,
  subscribeRegistrations,
} from '../services/adminService';
import { DashboardStats, Tournament, DepositRequest, WithdrawalRequest, Registration, ActiveTab } from '../types';
import { StatCard } from '../components/StatCard';
import { LoadingSpinner } from '../components/LoadingSpinner';

interface DashboardViewProps {
  setActiveTab?: (tab: ActiveTab) => void;
  onNavigate?: (tab: ActiveTab) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ setActiveTab, onNavigate }) => {
  const navigate = onNavigate || setActiveTab || (() => {});
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    totalTournaments: 0,
    upcomingTournaments: 0,
    liveTournaments: 0,
    completedTournaments: 0,
    totalRegistrations: 0,
    pendingRegistrations: 0,
    approvedRegistrations: 0,
    pendingPayments: 0,
    approvedPayments: 0,
    pendingWithdrawals: 0,
    totalDeposits: 0,
    totalWithdrawals: 0,
    totalEntryFees: 0,
    totalPrizeDistributed: 0,
    totalRevenue: 0,
  });
  const [recentTournaments, setRecentTournaments] = useState<Tournament[]>([]);
  const [pendingDeposits, setPendingDeposits] = useState<DepositRequest[]>([]);
  const [pendingWithdrawalsList, setPendingWithdrawalsList] = useState<WithdrawalRequest[]>([]);
  const [pendingRegistrationsList, setPendingRegistrationsList] = useState<Registration[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [lastSyncTime, setLastSyncTime] = useState<string>('Just now');

  useEffect(() => {
    // 1. Subscribe to real-time aggregate stats
    const unsubStats = subscribeDashboardStats((newStats) => {
      setStats(newStats);
      setLastSyncTime(new Date().toLocaleTimeString());
      setLoading(false);
    });

    // 2. Subscribe to recent tournaments in real-time
    const unsubTourneys = subscribeTournaments((tourneys) => {
      setRecentTournaments(tourneys.slice(0, 5));
    });

    // 3. Subscribe to pending deposits in real-time
    const unsubDeposits = subscribeDeposits((deps) => {
      setPendingDeposits(deps.filter((d) => d.status === 'Pending').slice(0, 5));
    });

    // 4. Subscribe to pending withdrawals in real-time
    const unsubWithdrawals = subscribeWithdrawals((withs) => {
      setPendingWithdrawalsList(withs.filter((w) => w.status === 'Pending' || w.status === 'Processing').slice(0, 5));
    });

    // 5. Subscribe to pending registrations in real-time
    const unsubRegs = subscribeRegistrations((regs) => {
      setPendingRegistrationsList(regs.filter((r) => r.status === 'Pending').slice(0, 5));
    });

    return () => {
      unsubStats();
      unsubTourneys();
      unsubDeposits();
      unsubWithdrawals();
      unsubRegs();
    };
  }, []);

  if (loading) {
    return <LoadingSpinner text="Connecting real-time Firestore listeners..." />;
  }

  const hasPendingItems =
    pendingDeposits.length > 0 ||
    pendingWithdrawalsList.length > 0 ||
    pendingRegistrationsList.length > 0 ||
    (stats.pendingPayments || 0) > 0;

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-zinc-900 via-zinc-900/90 to-zinc-950 p-6 rounded-2xl border border-zinc-800 shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-2xl font-black text-white tracking-tight font-mono">
              ADMIN DASHBOARD
            </h1>
            <span className="flex items-center gap-1.5 text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>LIVE FIRESTORE SYNC</span>
            </span>
          </div>
          <p className="text-xs text-zinc-400">
            Real-time esports tournament telemetry, wallet ledger, and operations control. Last synced at: {lastSyncTime}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            id="btn-quick-create-tournament"
            onClick={() => navigate('tournaments')}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold transition shadow-lg shadow-amber-500/20 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create Tournament</span>
          </button>
        </div>
      </div>

      {/* Pending Actions Alert Banner */}
      {hasPendingItems && (
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-amber-300">Action Required: Pending User Submissions</p>
              <p className="text-xs text-zinc-400 mt-0.5">
                {pendingDeposits.length} deposits, {pendingWithdrawalsList.length} withdrawals, and {pendingRegistrationsList.length} registrations awaiting admin verification.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {pendingDeposits.length > 0 && (
              <button
                id="btn-dash-review-deposits"
                onClick={() => navigate('deposits')}
                className="px-3 py-1.5 rounded-lg bg-amber-500 text-zinc-950 font-bold text-xs hover:bg-amber-400 cursor-pointer"
              >
                Review Deposits
              </button>
            )}
            {pendingWithdrawalsList.length > 0 && (
              <button
                id="btn-dash-review-withdrawals"
                onClick={() => navigate('withdrawals')}
                className="px-3 py-1.5 rounded-lg bg-zinc-800 text-zinc-200 border border-zinc-700 font-bold text-xs hover:bg-zinc-700 cursor-pointer"
              >
                Review Withdrawals
              </button>
            )}
          </div>
        </div>
      )}

      {/* Section 1: Financial & Revenue KPIs */}
      <div>
        <h2 className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-3">
          Financial & Revenue Telemetry (Real-Time)
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            id="stat-net-revenue"
            title="Total Revenue"
            value={stats.totalRevenue ?? 0}
            isCurrency
            accentColor="emerald"
            icon={TrendingUp}
            subtitle="Entry fees minus prize distribution"
          />
          <StatCard
            id="stat-entry-fees"
            title="Total Entry Fees"
            value={stats.totalEntryFees ?? 0}
            isCurrency
            accentColor="amber"
            icon={DollarSign}
            subtitle="Collected from approved registrations"
          />
          <StatCard
            id="stat-prize-distributed"
            title="Total Prize Distributed"
            value={stats.totalPrizeDistributed ?? 0}
            isCurrency
            accentColor="cyan"
            icon={Award}
            subtitle="Total prize money credited to winners"
          />
          <StatCard
            id="stat-total-deposits"
            title="Total Deposits"
            value={stats.totalDeposits ?? 0}
            isCurrency
            accentColor="purple"
            icon={ArrowDownCircle}
            subtitle="Approved user wallet deposits"
          />
        </div>
      </div>

      {/* Section 2: Tournament & Match KPIs */}
      <div>
        <h2 className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-3">
          Tournament & Esports Metrics (Real-Time)
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            id="stat-total-tournaments"
            title="Total Tournaments"
            value={stats.totalTournaments ?? 0}
            accentColor="amber"
            icon={Trophy}
            subtitle="All time created tournaments"
            onClick={() => navigate('tournaments')}
          />
          <StatCard
            id="stat-live-tournaments"
            title="Live Tournaments"
            value={stats.liveTournaments ?? 0}
            accentColor="rose"
            icon={Flame}
            subtitle="Currently running matches"
            onClick={() => navigate('tournaments')}
          />
          <StatCard
            id="stat-upcoming-tournaments"
            title="Upcoming Tournaments"
            value={stats.upcomingTournaments ?? 0}
            accentColor="cyan"
            icon={Clock}
            subtitle="Registration open or draft"
            onClick={() => navigate('tournaments')}
          />
          <StatCard
            id="stat-completed-tournaments"
            title="Completed Tournaments"
            value={stats.completedTournaments ?? 0}
            accentColor="emerald"
            icon={CheckCircle2}
            subtitle="Finished tournaments"
            onClick={() => navigate('tournaments')}
          />
        </div>
      </div>

      {/* Section 3: User & Operations Metrics */}
      <div>
        <h2 className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-3">
          Users & Operational Status (Real-Time)
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            id="stat-total-users"
            title="Total Users"
            value={stats.totalUsers ?? 0}
            accentColor="indigo"
            icon={Users}
            subtitle="Registered players in Firestore"
            onClick={() => navigate('users')}
          />
          <StatCard
            id="stat-total-registrations"
            title="Total Registrations"
            value={stats.totalRegistrations ?? 0}
            accentColor="amber"
            icon={CheckCircle2}
            subtitle={`Approved: ${stats.approvedRegistrations ?? 0} | Pending: ${stats.pendingRegistrations ?? 0}`}
            onClick={() => navigate('registrations')}
          />
          <StatCard
            id="stat-approved-registrations"
            title="Approved Registrations"
            value={stats.approvedRegistrations ?? 0}
            accentColor="emerald"
            icon={CheckCircle2}
            subtitle="Confirmed tournament participants"
            onClick={() => navigate('registrations')}
          />
          <StatCard
            id="stat-pending-registrations"
            title="Pending Registrations"
            value={stats.pendingRegistrations ?? 0}
            accentColor="amber"
            icon={Clock}
            subtitle="Registrations awaiting approval"
            onClick={() => navigate('registrations')}
          />
          <StatCard
            id="stat-pending-payments"
            title="Pending Payments"
            value={stats.pendingPayments ?? 0}
            accentColor="purple"
            icon={CreditCard}
            subtitle="Pending payment submissions"
            onClick={() => navigate('payments')}
          />
          <StatCard
            id="stat-approved-payments"
            title="Approved Payments"
            value={stats.approvedPayments ?? 0}
            accentColor="emerald"
            icon={CheckCircle2}
            subtitle="Approved payment submissions"
            onClick={() => navigate('payments')}
          />
          <StatCard
            id="stat-pending-withdrawals"
            title="Pending Withdrawals"
            value={stats.pendingWithdrawals ?? 0}
            accentColor="rose"
            icon={ArrowUpCircle}
            subtitle="Withdrawal requests in queue"
            onClick={() => navigate('withdrawals')}
          />
          <StatCard
            id="stat-total-withdrawals"
            title="Total Withdrawals"
            value={stats.totalWithdrawals ?? 0}
            isCurrency
            accentColor="cyan"
            icon={ArrowUpCircle}
            subtitle="Total payouts distributed"
            onClick={() => navigate('withdrawals')}
          />
        </div>
      </div>

      {/* Grid: Recent Tournaments & Pending Verifications */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Tournaments */}
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Trophy className="w-4 h-4 text-amber-400" />
              <span>Recent Tournaments (Real-Time)</span>
            </h3>
            <button
              onClick={() => navigate('tournaments')}
              className="text-xs text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>View All</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          </div>

          {recentTournaments.length === 0 ? (
            <div className="text-center py-8 border border-dashed border-zinc-800 rounded-xl">
              <p className="text-xs text-zinc-400">No tournaments available in Firebase</p>
              <button
                onClick={() => navigate('tournaments')}
                className="mt-3 px-3 py-1.5 text-xs font-semibold text-amber-400 bg-amber-500/10 border border-amber-500/20 rounded-lg hover:bg-amber-500/20 transition cursor-pointer"
              >
                + Create First Tournament
              </button>
            </div>
          ) : (
            <div className="space-y-2.5">
              {recentTournaments.map((t) => (
                <div
                  key={t.id}
                  className="flex items-center justify-between p-3 rounded-xl bg-zinc-950 border border-zinc-800/80 hover:border-zinc-700 transition"
                >
                  <div>
                    <p className="text-xs font-bold text-white tracking-tight">{t.name}</p>
                    <div className="flex items-center gap-2 mt-1 text-[11px] text-zinc-400">
                      <span className="text-amber-400 font-mono font-semibold">{t.type}</span>
                      <span>•</span>
                      <span>Entry: ₹{t.entryFee}</span>
                      <span>•</span>
                      <span>Pool: ₹{t.prizePool}</span>
                    </div>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                      t.status === 'Registration Open'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : t.status === 'Live'
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20 animate-pulse'
                        : t.status === 'Completed'
                        ? 'bg-zinc-800 text-zinc-400'
                        : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                    }`}
                  >
                    {t.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Pending Deposits & Withdrawals Queue */}
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ArrowDownCircle className="w-4 h-4 text-emerald-400" />
              <span>Pending Deposits Verification</span>
            </h3>
            <button
              onClick={() => navigate('deposits')}
              className="text-xs text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>Manage Deposits</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          </div>

          {pendingDeposits.length === 0 ? (
            <div className="text-center py-8 border border-dashed border-zinc-800 rounded-xl">
              <p className="text-xs text-zinc-400">No pending deposits</p>
              <p className="text-[11px] text-zinc-600 mt-1">All user deposits are processed</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {pendingDeposits.map((d) => (
                <div
                  key={d.id}
                  className="flex items-center justify-between p-3 rounded-xl bg-zinc-950 border border-zinc-800/80 hover:border-zinc-700 transition"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-xs font-bold text-white font-mono">₹{d.amount}</p>
                      <span className="text-[10px] text-zinc-400">UTR: {d.utrNumber}</span>
                    </div>
                    <p className="text-[11px] text-zinc-400 mt-0.5 truncate max-w-xs">{d.userEmail}</p>
                  </div>
                  <button
                    onClick={() => navigate('deposits')}
                    className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition cursor-pointer"
                  >
                    Verify
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
