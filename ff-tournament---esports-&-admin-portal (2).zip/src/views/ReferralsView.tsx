import React, { useEffect, useState } from 'react';
import {
  Share2,
  Save,
  Users,
  Award,
  CheckCircle2,
  DollarSign,
} from 'lucide-react';
import {
  getReferralSettings,
  saveReferralSettings,
  getReferralRecords,
  logAdminActivity,
} from '../services/adminService';
import { ReferralSettings, ReferralRecord } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { useAuth } from '../context/AuthContext';

export const ReferralsView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [settings, setSettings] = useState<ReferralSettings | null>(null);
  const [records, setRecords] = useState<ReferralRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const [settingsData, recordsData] = await Promise.all([
        getReferralSettings(),
        getReferralRecords(),
      ]);
      setSettings(settingsData);
      setRecords(recordsData);
    } catch (err) {
      console.error('Error loading referrals:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    setSaving(true);
    setSavedSuccess(false);
    try {
      await saveReferralSettings({
        ...settings,
        updatedBy: adminProfile?.email || 'admin',
      });
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'UPDATE_REFERRAL_SETTINGS',
          'referrals',
          'Updated referral rewards configuration'
        );
      }
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err) {
      console.error('Error saving referral settings:', err);
      alert('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <LoadingSpinner text="Retrieving referral system parameters..." />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
          <Share2 className="w-5 h-5 text-amber-400" />
          <span>Referral Program & Bonus Control</span>
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Configure viral referral bonuses, minimum deposit eligibility thresholds, and track invitations.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Referral Settings Card */}
        <div className="lg:col-span-1 rounded-2xl border border-[#1E1E24] bg-[#0F1115] p-5 space-y-4">
          <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            <span>Referral Program Settings</span>
          </h2>

          {savedSuccess && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Settings updated successfully!</span>
            </div>
          )}

          {settings && (
            <form onSubmit={handleSaveSettings} className="space-y-3.5 text-xs">
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#0A0A0B] border border-[#1E1E24]">
                <div>
                  <p className="font-semibold text-white">Enable Referral System</p>
                  <p className="text-slate-400 text-[11px]">Allow players to earn referral rewards</p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.isEnabled}
                  onChange={(e) => setSettings({ ...settings, isEnabled: e.target.checked })}
                  className="w-5 h-5 accent-amber-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="block uppercase text-slate-400 font-semibold mb-1">
                  Reward Per Referral (₹)
                </label>
                <input
                  type="number"
                  min={0}
                  value={settings.rewardPerReferral}
                  onChange={(e) =>
                    setSettings({ ...settings, rewardPerReferral: Number(e.target.value) })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-white font-mono"
                />
              </div>

              <div>
                <label className="block uppercase text-slate-400 font-semibold mb-1">
                  Min Deposit Required (₹)
                </label>
                <input
                  type="number"
                  min={0}
                  value={settings.minDepositRequired}
                  onChange={(e) =>
                    setSettings({ ...settings, minDepositRequired: Number(e.target.value) })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-white font-mono"
                />
              </div>

              <div>
                <label className="block uppercase text-slate-400 font-semibold mb-1">
                  Referral Rules & Terms
                </label>
                <textarea
                  rows={4}
                  value={settings.rules}
                  onChange={(e) => setSettings({ ...settings, rules: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-white"
                />
              </div>

              <button
                type="submit"
                disabled={saving}
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold shadow-lg shadow-amber-500/20 transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>{saving ? 'Saving...' : 'Save Settings'}</span>
              </button>
            </form>
          )}
        </div>

        {/* Referral Logs Table */}
        <div className="lg:col-span-2 rounded-2xl border border-[#1E1E24] bg-[#0F1115] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Users className="w-4 h-4 text-amber-400" />
              <span>Referral Records ({records.length})</span>
            </h2>
          </div>

          {records.length === 0 ? (
            <div className="text-center py-12 border border-dashed border-[#1E1E24] rounded-xl text-slate-400 text-xs">
              <Share2 className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <p>No referral records found in Firebase.</p>
              <p className="text-[11px] text-slate-600 mt-1">
                Player referral signups will automatically be tracked here.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-[#1E1E24] text-slate-400">
                    <th className="pb-2">Referrer</th>
                    <th className="pb-2">Referred Player</th>
                    <th className="pb-2">Reward</th>
                    <th className="pb-2">Status</th>
                    <th className="pb-2">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1E1E24]">
                  {records.map((r) => (
                    <tr key={r.id} className="hover:bg-[#0A0A0B]/60 transition">
                      <td className="py-2.5 font-medium text-white">{r.referrerEmail}</td>
                      <td className="py-2.5 text-slate-300">{r.referredEmail}</td>
                      <td className="py-2.5 font-mono font-bold text-amber-400">
                        ₹{r.rewardAmount}
                      </td>
                      <td className="py-2.5">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            r.isRewardCredited
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : 'bg-zinc-800 text-slate-400'
                          }`}
                        >
                          {r.isRewardCredited ? 'Credited' : 'Pending'}
                        </span>
                      </td>
                      <td className="py-2.5 text-slate-400 font-mono text-[11px]">
                        {new Date(r.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
