import React, { useEffect, useState } from 'react';
import {
  Wallet,
  Search,
  PlusCircle,
  MinusCircle,
  ArrowDownCircle,
  ArrowUpCircle,
  Award,
  History,
  AlertCircle,
  Download,
} from 'lucide-react';
import { getWallets, manualWalletAdjustment, logAdminActivity, exportToCsv } from '../services/adminService';
import { UserWallet } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useAuth } from '../context/AuthContext';

export const WalletView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [wallets, setWallets] = useState<UserWallet[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');

  // Adjustment Modal
  const [adjustmentTarget, setAdjustmentTarget] = useState<UserWallet | null>(null);
  const [adjustAmount, setAdjustAmount] = useState<number>(100);
  const [isCredit, setIsCredit] = useState<boolean>(true);
  const [adjustReason, setAdjustReason] = useState<string>('');
  const [adjustLoading, setAdjustLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');

  const loadWallets = async () => {
    try {
      setLoading(true);
      const data = await getWallets();
      setWallets(data);
    } catch (err) {
      console.error('Error loading wallets:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadWallets();
  }, []);

  const handleOpenAdjust = (w: UserWallet, credit: boolean) => {
    setAdjustmentTarget(w);
    setIsCredit(credit);
    setAdjustAmount(100);
    setAdjustReason('');
    setErrorMsg('');
  };

  const handleAdjustSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustmentTarget || !adminProfile) return;
    if (!adjustReason.trim()) {
      setErrorMsg('A mandatory reason must be provided for manual wallet adjustments');
      return;
    }
    if (adjustAmount <= 0) {
      setErrorMsg('Amount must be greater than zero');
      return;
    }

    setAdjustLoading(true);
    setErrorMsg('');

    try {
      await manualWalletAdjustment(
        adjustmentTarget.userId,
        adjustmentTarget.userEmail,
        adjustAmount,
        isCredit,
        adjustReason.trim(),
        { id: adminProfile.id, email: adminProfile.email, role }
      );

      await logAdminActivity(
        { id: adminProfile.id, email: adminProfile.email, role },
        'MANUAL_WALLET_ADJUSTMENT',
        'wallets',
        `${isCredit ? 'Credited' : 'Debited'} ₹${adjustAmount} to ${adjustmentTarget.userEmail}. Reason: ${adjustReason}`,
        adjustmentTarget.userId,
        { amount: adjustAmount, isCredit, reason: adjustReason }
      );

      setAdjustmentTarget(null);
      await loadWallets();
    } catch (err: any) {
      console.error('Error adjusting wallet:', err);
      setErrorMsg(err.message || 'Failed to adjust wallet balance');
    } finally {
      setAdjustLoading(false);
    }
  };

  const handleExportCsv = () => {
    const rows = filteredWallets.map((w) => ({
      UserId: w.userId,
      Email: w.userEmail,
      Name: w.userName,
      AvailableBalance: w.availableBalance,
      TotalDeposited: w.totalDeposited,
      TotalWinnings: w.totalWinnings,
      TotalWithdrawn: w.totalWithdrawn,
      LastUpdated: new Date(w.updatedAt).toLocaleString(),
    }));
    exportToCsv('user_wallets', rows);
  };

  const filteredWallets = wallets.filter((w) => {
    const term = search.toLowerCase();
    return (
      w.userEmail?.toLowerCase().includes(term) ||
      w.userName?.toLowerCase().includes(term) ||
      w.phone?.includes(term)
    );
  });

  const totalCirculatingBalance = wallets.reduce((sum, w) => sum + Number(w.availableBalance || 0), 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Wallet className="w-5 h-5 text-amber-400" />
            <span>User Wallets & Balances</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            View player wallet reserves, deposit totals, cumulative winnings, and perform authorized balance adjustments.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="px-3.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs">
            <span className="text-zinc-400 text-[10px] uppercase font-bold block">In Player Wallets</span>
            <span className="text-amber-400 font-mono font-bold text-sm">₹{totalCirculatingBalance}</span>
          </div>
          <button
            id="btn-export-wallets-csv"
            onClick={handleExportCsv}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold border border-zinc-700 transition cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="max-w-md relative">
        <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by user email, name, phone..."
          className="w-full pl-9 pr-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
        />
      </div>

      {/* Table */}
      {loading ? (
        <LoadingSpinner text="Fetching wallet accounts from Firestore..." />
      ) : filteredWallets.length === 0 ? (
        <EmptyState
          icon={Wallet}
          title="No wallets found"
          description="There are currently no player wallets in Firebase."
        />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-zinc-800 bg-zinc-900/60 shadow-xl">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="border-b border-zinc-800 bg-zinc-950/80 text-[10px] uppercase font-bold text-zinc-400 tracking-wider">
              <tr>
                <th className="px-4 py-3.5">User</th>
                <th className="px-4 py-3.5">Available Balance</th>
                <th className="px-4 py-3.5">Deposits</th>
                <th className="px-4 py-3.5">Winnings</th>
                <th className="px-4 py-3.5">Withdrawn</th>
                <th className="px-4 py-3.5 text-right">Manual Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60">
              {filteredWallets.map((w) => (
                <tr key={w.userId} className="hover:bg-zinc-800/40 transition">
                  <td className="px-4 py-3">
                    <div className="font-bold text-white tracking-tight">{w.userEmail}</div>
                    <div className="text-[11px] text-zinc-400 mt-0.5">{w.userName || 'Player'}</div>
                  </td>
                  <td className="px-4 py-3 font-mono">
                    <span className="font-bold text-emerald-400 text-base">₹{w.availableBalance}</span>
                  </td>
                  <td className="px-4 py-3 font-mono text-zinc-300">
                    ₹{w.totalDeposited || 0}
                  </td>
                  <td className="px-4 py-3 font-mono text-amber-400 font-semibold">
                    ₹{w.totalWinnings || 0}
                  </td>
                  <td className="px-4 py-3 font-mono text-rose-400">
                    ₹{w.totalWithdrawn || 0}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleOpenAdjust(w, true)}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 font-semibold text-xs border border-emerald-500/20 transition cursor-pointer"
                      >
                        <PlusCircle className="w-3.5 h-3.5" />
                        <span>Credit</span>
                      </button>
                      <button
                        onClick={() => handleOpenAdjust(w, false)}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 font-semibold text-xs border border-rose-500/20 transition cursor-pointer"
                      >
                        <MinusCircle className="w-3.5 h-3.5" />
                        <span>Debit</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Manual Adjustment Modal */}
      {adjustmentTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl border border-zinc-800 bg-zinc-900 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Wallet className="w-5 h-5 text-amber-400" />
              <span>Manual Wallet {isCredit ? 'Credit' : 'Debit'} Adjustment</span>
            </h3>

            <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-xs">
              <p className="text-zinc-400">Target User: <strong className="text-white">{adjustmentTarget.userEmail}</strong></p>
              <p className="text-zinc-400 mt-1">
                Current Available Balance: <strong className="text-emerald-400 font-mono">₹{adjustmentTarget.availableBalance}</strong>
              </p>
            </div>

            {errorMsg && (
              <div className="p-2.5 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleAdjustSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-zinc-950 border border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsCredit(true)}
                  className={`py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    isCredit ? 'bg-emerald-500 text-zinc-950 shadow' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  + Credit (Add Money)
                </button>
                <button
                  type="button"
                  onClick={() => setIsCredit(false)}
                  className={`py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    !isCredit ? 'bg-rose-600 text-white shadow' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  - Debit (Deduct Money)
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Adjustment Amount (₹) <span className="text-rose-400">*</span>
                </label>
                <input
                  type="number"
                  min={1}
                  required
                  value={adjustAmount}
                  onChange={(e) => setAdjustAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-sm text-white font-mono focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Mandatory Audit Reason <span className="text-rose-400">*</span>
                </label>
                <textarea
                  rows={2}
                  required
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  placeholder="e.g. Compensated for room glitch / Manual offline deposit..."
                  className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-xs text-white focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setAdjustmentTarget(null)}
                  className="px-4 py-2 rounded-xl border border-zinc-700 text-xs font-semibold text-zinc-300 hover:bg-zinc-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={adjustLoading}
                  className={`px-5 py-2 rounded-xl font-bold text-xs shadow-lg transition cursor-pointer ${
                    isCredit
                      ? 'bg-emerald-500 hover:bg-emerald-400 text-zinc-950'
                      : 'bg-rose-600 hover:bg-rose-500 text-white'
                  }`}
                >
                  {adjustLoading ? 'Executing Transaction...' : isCredit ? 'Credit Wallet' : 'Debit Wallet'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
