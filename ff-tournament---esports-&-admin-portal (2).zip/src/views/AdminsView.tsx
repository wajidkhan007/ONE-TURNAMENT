import React, { useEffect, useState } from 'react';
import {
  ShieldCheck,
  Plus,
  Trash2,
  Edit2,
  Mail,
  Shield,
  UserCheck,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import {
  getAdminUsers,
  saveAdminUser,
  deleteAdminUser,
  logAdminActivity,
} from '../services/adminService';
import { AdminUser, AdminRole } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useAuth } from '../context/AuthContext';
import { SUPER_ADMIN_EMAIL } from '../firebase';

export const AdminsView: React.FC = () => {
  const { adminProfile, role, isSuperAdmin } = useAuth();
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingAdmin, setEditingAdmin] = useState<Partial<AdminUser> | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [saving, setSaving] = useState<boolean>(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const data = await getAdminUsers();
      setAdmins(data);
    } catch (err) {
      console.error('Error loading admin users:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleOpenCreate = () => {
    setEditingAdmin({
      name: '',
      email: '',
      role: 'TOURNAMENT_ADMIN',
      isActive: true,
    });
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAdmin?.email?.trim()) return;
    setSaving(true);
    try {
      await saveAdminUser({
        ...editingAdmin,
        createdBy: adminProfile?.email || 'super_admin',
      });
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'SAVE_ADMIN_ROLE',
          'adminUsers',
          `Configured admin permissions for: ${editingAdmin.email}`
        );
      }
      setIsModalOpen(false);
      setEditingAdmin(null);
      await loadData();
    } catch (err) {
      console.error('Error saving admin:', err);
      alert('Failed to save admin user');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteConfirmId) return;
    try {
      await deleteAdminUser(deleteConfirmId);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'DELETE_ADMIN',
          'adminUsers',
          `Removed admin access for ID: ${deleteConfirmId}`,
          deleteConfirmId
        );
      }
      setDeleteConfirmId(null);
      await loadData();
    } catch (err) {
      console.error('Error deleting admin:', err);
    }
  };

  if (!isSuperAdmin) {
    return (
      <div className="p-12 text-center rounded-2xl border border-[#1E1E24] bg-[#0F1115]">
        <Shield className="w-10 h-10 text-amber-500 mx-auto mb-3" />
        <h2 className="text-lg font-bold text-white">Super Admin Access Only</h2>
        <p className="text-xs text-slate-400 mt-1">
          Only the Super Administrator ({SUPER_ADMIN_EMAIL}) has authority to provision and revoke admin privileges.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            <span>Role-Based Admin User Management</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Provision staff sub-admins with dedicated permission scopes for tournaments, finance, results, and support.
          </p>
        </div>
        <button
          id="btn-add-admin"
          onClick={handleOpenCreate}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold transition shadow-lg shadow-amber-500/20 active:scale-95 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Admin Account</span>
        </button>
      </div>

      {/* Role Summary Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
        <div className="p-3.5 rounded-xl bg-[#0F1115] border border-[#1E1E24]">
          <p className="font-bold text-amber-400">SUPER ADMIN</p>
          <p className="text-[11px] text-slate-400 mt-1">Full master access to all panels & finance</p>
        </div>
        <div className="p-3.5 rounded-xl bg-[#0F1115] border border-[#1E1E24]">
          <p className="font-bold text-emerald-400">TOURNAMENT ADMIN</p>
          <p className="text-[11px] text-slate-400 mt-1">Manage tournaments, matches & rooms</p>
        </div>
        <div className="p-3.5 rounded-xl bg-[#0F1115] border border-[#1E1E24]">
          <p className="font-bold text-purple-400">PAYMENT ADMIN</p>
          <p className="text-[11px] text-slate-400 mt-1">Approve deposits, withdrawals & refunds</p>
        </div>
        <div className="p-3.5 rounded-xl bg-[#0F1115] border border-[#1E1E24]">
          <p className="font-bold text-cyan-400">RESULT ADMIN</p>
          <p className="text-[11px] text-slate-400 mt-1">Input scores, rank tables & credit prizes</p>
        </div>
        <div className="p-3.5 rounded-xl bg-[#0F1115] border border-[#1E1E24]">
          <p className="font-bold text-indigo-400">SUPPORT ADMIN</p>
          <p className="text-[11px] text-slate-400 mt-1">Respond to customer helpdesk tickets</p>
        </div>
      </div>

      {/* Admins Table */}
      {loading ? (
        <LoadingSpinner text="Retrieving admin user list..." />
      ) : admins.length === 0 ? (
        <EmptyState
          icon={ShieldCheck}
          title="No sub-admins found"
          description="Click Add Admin to grant restricted dashboard roles to tournament coordinators and payment officers."
          actionLabel="Add Admin"
          onAction={handleOpenCreate}
        />
      ) : (
        <div className="rounded-2xl border border-[#1E1E24] bg-[#0F1115] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0A0A0B] border-b border-[#1E1E24] text-slate-400 uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3 px-4">Admin Name</th>
                  <th className="py-3 px-4">Email</th>
                  <th className="py-3 px-4">Role Assigned</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Last Login</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E1E24]">
                {admins.map((adm) => {
                  const isMaster = adm.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();
                  return (
                    <tr key={adm.id} className="hover:bg-[#0A0A0B]/60 transition">
                      <td className="py-3 px-4 font-bold text-white">
                        {adm.name}
                        {isMaster && (
                          <span className="ml-2 text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                            MASTER
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-slate-300 font-mono">{adm.email}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-amber-500/10 text-amber-400 border border-amber-500/20">
                          {adm.role?.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            adm.isActive !== false
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                          }`}
                        >
                          {adm.isActive !== false ? 'Active' : 'Disabled'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-400 font-mono text-[11px]">
                        {adm.lastLoginAt ? new Date(adm.lastLoginAt).toLocaleString() : 'Never'}
                      </td>
                      <td className="py-3 px-4 text-right">
                        {!isMaster && (
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => {
                                setEditingAdmin({ ...adm });
                                setIsModalOpen(true);
                              }}
                              className="p-1.5 rounded-lg text-amber-400 hover:bg-zinc-800 transition cursor-pointer"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => setDeleteConfirmId(adm.id)}
                              className="p-1.5 rounded-lg text-rose-400 hover:bg-zinc-800 transition cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Create / Edit Modal */}
      {isModalOpen && editingAdmin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-[#1E1E24] bg-[#0F1115] p-6 shadow-2xl space-y-4">
            <h2 className="text-lg font-bold text-white">
              {editingAdmin.id ? 'Edit Admin Role' : 'Add New Admin Account'}
            </h2>

            <form onSubmit={handleSave} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Admin Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Tournament Coordinator"
                  value={editingAdmin.name || ''}
                  onChange={(e) => setEditingAdmin({ ...editingAdmin, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-sm text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  placeholder="staff@fftournament.com"
                  value={editingAdmin.email || ''}
                  onChange={(e) => setEditingAdmin({ ...editingAdmin, email: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-sm text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Role Assignment
                </label>
                <select
                  value={editingAdmin.role || 'TOURNAMENT_ADMIN'}
                  onChange={(e) =>
                    setEditingAdmin({ ...editingAdmin, role: e.target.value as AdminRole })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="TOURNAMENT_ADMIN">Tournament Admin (Tournaments, Matches, Rooms)</option>
                  <option value="PAYMENT_ADMIN">Payment Admin (Deposits, Withdrawals, Wallets)</option>
                  <option value="RESULT_ADMIN">Result Admin (Leaderboards, Scores, Prizes)</option>
                  <option value="SUPPORT_ADMIN">Support Admin (User Tickets, User Management)</option>
                  <option value="SUPER_ADMIN">Super Admin (Unrestricted Full Access)</option>
                </select>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="admin-active-status"
                  checked={editingAdmin.isActive !== false}
                  onChange={(e) =>
                    setEditingAdmin({ ...editingAdmin, isActive: e.target.checked })
                  }
                  className="w-4 h-4 accent-amber-500 cursor-pointer"
                />
                <label htmlFor="admin-active-status" className="text-xs text-slate-300 cursor-pointer">
                  Account is Active & Allowed Login
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-[#1E1E24]">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-700 text-xs text-slate-300 hover:bg-zinc-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow-lg shadow-amber-500/20 cursor-pointer disabled:opacity-50"
                >
                  {saving ? 'Saving...' : 'Save Admin'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmationModal
        isOpen={!!deleteConfirmId}
        title="Revoke Admin Access"
        message="Are you sure you want to revoke admin permissions for this account? They will lose access to the portal immediately."
        confirmText="Revoke Access"
        onConfirm={handleDelete}
        onCancel={() => setDeleteConfirmId(null)}
      />
    </div>
  );
};
