import React, { useEffect, useState } from 'react';
import {
  ReceiptText,
  Search,
  Download,
  ArrowDownRight,
  ArrowUpRight,
  RefreshCw,
  Award,
  Wallet,
  RotateCcw,
  Sliders,
} from 'lucide-react';
import { getWalletTransactions, exportToCsv } from '../services/adminService';
import { WalletTransaction, TransactionType } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';

export const TransactionsView: React.FC = () => {
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');
  const [typeFilter, setTypeFilter] = useState<string>('ALL');

  const loadTransactions = async () => {
    try {
      setLoading(true);
      const data = await getWalletTransactions();
      setTransactions(data);
    } catch (err) {
      console.error('Error loading transactions:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTransactions();
  }, []);

  const handleExportCsv = () => {
    const rows = filteredTransactions.map((t) => ({
      TxID: t.id,
      UserId: t.userId,
      UserEmail: t.userEmail || '',
      Type: t.type,
      Amount: t.amount,
      PreviousBalance: t.previousBalance,
      NewBalance: t.newBalance,
      Status: t.status,
      Description: t.description,
      Tournament: t.tournamentName || '',
      AdminEmail: t.adminEmail || '',
      Timestamp: new Date(t.timestamp).toLocaleString(),
    }));
    exportToCsv('wallet_transactions_ledger', rows);
  };

  const filteredTransactions = transactions.filter((t) => {
    const term = search.toLowerCase();
    const matchesSearch =
      t.userEmail?.toLowerCase().includes(term) ||
      t.description?.toLowerCase().includes(term) ||
      t.id?.toLowerCase().includes(term) ||
      t.userId?.toLowerCase().includes(term);
    const matchesType = typeFilter === 'ALL' || t.type === typeFilter;
    return matchesSearch && matchesType;
  });

  const getTypeBadge = (type: TransactionType) => {
    switch (type) {
      case 'Deposit':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <ArrowDownRight className="w-3 h-3" /> Deposit
          </span>
        );
      case 'Winnings':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Award className="w-3 h-3" /> Winnings
          </span>
        );
      case 'Tournament Entry':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            <ArrowUpRight className="w-3 h-3" /> Entry Fee
          </span>
        );
      case 'Withdrawal':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20">
            <ArrowUpRight className="w-3 h-3" /> Withdrawal
          </span>
        );
      case 'Refund':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <RotateCcw className="w-3 h-3" /> Refund
          </span>
        );
      case 'Admin Adjustment':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20">
            <Sliders className="w-3 h-3" /> Adjustment
          </span>
        );
      default:
        return <span className="text-[10px] text-zinc-400">{type}</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <ReceiptText className="w-5 h-5 text-amber-400" />
            <span>Wallet Transactions Master Ledger</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Immutable log of all user deposits, entry fees, prize credits, payouts, refunds, and adjustments.
          </p>
        </div>
        <button
          id="btn-export-transactions-csv"
          onClick={handleExportCsv}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold border border-zinc-700 transition cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Filters & Search */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-xl">
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by User Email, Description, Tx ID..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 cursor-pointer"
          >
            <option value="ALL">All Transaction Types ({transactions.length})</option>
            <option value="Deposit">Deposit</option>
            <option value="Tournament Entry">Tournament Entry</option>
            <option value="Winnings">Winnings</option>
            <option value="Withdrawal">Withdrawal</option>
            <option value="Refund">Refund</option>
            <option value="Admin Adjustment">Admin Adjustment</option>
          </select>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <LoadingSpinner text="Fetching wallet ledger from Firestore..." />
      ) : filteredTransactions.length === 0 ? (
        <EmptyState
          icon={ReceiptText}
          title="No transactions found"
          description="There are currently no wallet transactions in Firebase matching your filters."
        />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-zinc-800 bg-zinc-900/60 shadow-xl">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="border-b border-zinc-800 bg-zinc-950/80 text-[10px] uppercase font-bold text-zinc-400 tracking-wider">
              <tr>
                <th className="px-4 py-3.5">Type</th>
                <th className="px-4 py-3.5">User</th>
                <th className="px-4 py-3.5">Amount</th>
                <th className="px-4 py-3.5">Prev → New Balance</th>
                <th className="px-4 py-3.5">Description</th>
                <th className="px-4 py-3.5">Date & Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60">
              {filteredTransactions.map((t) => (
                <tr key={t.id} className="hover:bg-zinc-800/40 transition font-mono">
                  <td className="px-4 py-3 font-sans">
                    {getTypeBadge(t.type)}
                  </td>
                  <td className="px-4 py-3 font-sans">
                    <div className="font-bold text-white tracking-tight">{t.userEmail || t.userId}</div>
                    {t.adminEmail && (
                      <span className="text-[10px] text-amber-400/80 block">By: {t.adminEmail}</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`font-bold text-sm ${
                        t.type === 'Deposit' || t.type === 'Winnings' || t.type === 'Refund'
                          ? 'text-emerald-400'
                          : 'text-rose-400'
                      }`}
                    >
                      {t.type === 'Deposit' || t.type === 'Winnings' || t.type === 'Refund' ? '+' : '-'}₹
                      {t.amount}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-zinc-400 text-[11px]">
                    ₹{t.previousBalance} → <span className="text-white font-bold">₹{t.newBalance}</span>
                  </td>
                  <td className="px-4 py-3 font-sans text-zinc-300 max-w-xs truncate text-[11px]">
                    {t.description}
                  </td>
                  <td className="px-4 py-3 text-zinc-500 text-[11px]">
                    {new Date(t.timestamp).toLocaleString([], {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
