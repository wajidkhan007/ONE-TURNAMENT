import React, { useEffect, useState } from 'react';
import {
  Tag,
  Plus,
  Search,
  Trash2,
  Edit2,
  Calendar,
  Percent,
  CheckCircle2,
  XCircle,
  Clock,
} from 'lucide-react';
import { getCoupons, saveCoupon, deleteCoupon, logAdminActivity } from '../services/adminService';
import { Coupon } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useAuth } from '../context/AuthContext';

export const CouponsView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingCoupon, setEditingCoupon] = useState<Partial<Coupon> | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [saving, setSaving] = useState<boolean>(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const data = await getCoupons();
      setCoupons(data);
    } catch (err) {
      console.error('Error loading coupons:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleOpenCreate = () => {
    setEditingCoupon({
      code: '',
      discountType: 'PERCENTAGE',
      discountAmount: 20,
      minEntryFee: 50,
      maxDiscount: 100,
      expiryDate: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
      maxUses: 100,
      status: 'Active',
    });
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCoupon?.code?.trim()) return;
    setSaving(true);
    try {
      await saveCoupon(editingCoupon);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'SAVE_COUPON',
          'coupons',
          `Saved promo coupon: ${editingCoupon.code}`
        );
      }
      setIsModalOpen(false);
      setEditingCoupon(null);
      await loadData();
    } catch (err) {
      console.error('Error saving coupon:', err);
      alert('Failed to save coupon');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteConfirmId) return;
    try {
      await deleteCoupon(deleteConfirmId);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'DELETE_COUPON',
          'coupons',
          `Deleted coupon: ${deleteConfirmId}`,
          deleteConfirmId
        );
      }
      setDeleteConfirmId(null);
      await loadData();
    } catch (err) {
      console.error('Error deleting coupon:', err);
    }
  };

  const filteredCoupons = coupons.filter((c) =>
    c.code.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Tag className="w-5 h-5 text-amber-400" />
            <span>Discount Coupons & Promo Codes</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Configure percentage and flat discount codes for tournament entry fees.
          </p>
        </div>
        <button
          id="btn-create-coupon"
          onClick={handleOpenCreate}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold transition shadow-lg shadow-amber-500/20 active:scale-95 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Create Coupon</span>
        </button>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          id="input-search-coupons"
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search promo code..."
          className="w-full pl-9 pr-3 py-2 rounded-xl bg-[#0F1115] border border-[#1E1E24] text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
        />
      </div>

      {/* Coupon List */}
      {loading ? (
        <LoadingSpinner text="Retrieving coupon codes from Firestore..." />
      ) : filteredCoupons.length === 0 ? (
        <EmptyState
          icon={Tag}
          title="No coupons found"
          description="Create your first promotional discount coupon for tournament entry fees."
          actionLabel="Create Coupon"
          onAction={handleOpenCreate}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCoupons.map((coupon) => (
            <div
              key={coupon.id}
              className="rounded-2xl border border-[#1E1E24] bg-[#0F1115] p-5 flex flex-col justify-between hover:border-slate-700 transition space-y-4"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="px-3 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono font-bold text-sm tracking-wider">
                    {coupon.code}
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                      coupon.status === 'Active'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : 'bg-zinc-800 text-slate-400'
                    }`}
                  >
                    {coupon.status}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Discount:</span>
                    <span className="font-bold text-white font-mono">
                      {coupon.discountType === 'PERCENTAGE'
                        ? `${coupon.discountAmount}% OFF`
                        : `₹${coupon.discountAmount} FLAT OFF`}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Min Entry Fee:</span>
                    <span className="font-mono">₹{coupon.minEntryFee}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Usage Count:</span>
                    <span className="font-mono text-amber-400 font-bold">
                      {coupon.usedCount || 0} / {coupon.maxUses}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Expires On:</span>
                    <span className="font-mono text-slate-300">{coupon.expiryDate}</span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-[#1E1E24] flex justify-end gap-2">
                <button
                  onClick={() => {
                    setEditingCoupon({ ...coupon });
                    setIsModalOpen(true);
                  }}
                  className="p-1.5 rounded-lg text-amber-400 hover:bg-zinc-800 transition cursor-pointer"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setDeleteConfirmId(coupon.id)}
                  className="p-1.5 rounded-lg text-rose-400 hover:bg-zinc-800 transition cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create / Edit Modal */}
      {isModalOpen && editingCoupon && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-[#1E1E24] bg-[#0F1115] p-6 shadow-2xl space-y-4">
            <h2 className="text-lg font-bold text-white">
              {editingCoupon.id ? 'Edit Coupon Code' : 'Create New Coupon Code'}
            </h2>

            <form onSubmit={handleSave} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Coupon Code
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. FREEFIRE50"
                  value={editingCoupon.code || ''}
                  onChange={(e) =>
                    setEditingCoupon({ ...editingCoupon, code: e.target.value.toUpperCase() })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-sm text-white font-mono uppercase focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Discount Type
                  </label>
                  <select
                    value={editingCoupon.discountType || 'PERCENTAGE'}
                    onChange={(e) =>
                      setEditingCoupon({
                        ...editingCoupon,
                        discountType: e.target.value as 'PERCENTAGE' | 'FLAT',
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="PERCENTAGE">Percentage (%)</option>
                    <option value="FLAT">Flat Amount (₹)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Discount Value
                  </label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={editingCoupon.discountAmount ?? 10}
                    onChange={(e) =>
                      setEditingCoupon({
                        ...editingCoupon,
                        discountAmount: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Min Entry Fee (₹)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={editingCoupon.minEntryFee ?? 0}
                    onChange={(e) =>
                      setEditingCoupon({
                        ...editingCoupon,
                        minEntryFee: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Max Uses
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={editingCoupon.maxUses ?? 100}
                    onChange={(e) =>
                      setEditingCoupon({
                        ...editingCoupon,
                        maxUses: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Expiry Date
                  </label>
                  <input
                    type="date"
                    value={editingCoupon.expiryDate || ''}
                    onChange={(e) =>
                      setEditingCoupon({ ...editingCoupon, expiryDate: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Status
                  </label>
                  <select
                    value={editingCoupon.status || 'Active'}
                    onChange={(e) =>
                      setEditingCoupon({
                        ...editingCoupon,
                        status: e.target.value as 'Active' | 'Inactive',
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-[#1E1E24]">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-700 text-xs text-slate-300 hover:bg-zinc-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow-lg shadow-amber-500/20 disabled:opacity-50"
                >
                  {saving ? 'Saving...' : 'Save Coupon'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmationModal
        isOpen={!!deleteConfirmId}
        title="Delete Coupon"
        message="Are you sure you want to remove this promo code? Active registrations using this will not be affected."
        confirmText="Delete Code"
        onConfirm={handleDelete}
        onCancel={() => setDeleteConfirmId(null)}
      />
    </div>
  );
};
