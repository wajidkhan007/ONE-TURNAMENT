import React, { useEffect, useState } from 'react';
import {
  Trophy,
  Plus,
  Award,
  Wallet,
  CheckCircle2,
  Trash2,
  Eye,
  EyeOff,
  AlertCircle,
  Download,
} from 'lucide-react';
import {
  getTournamentResults,
  saveTournamentResult,
  deleteTournamentResult,
  creditTournamentPrize,
  getTournaments,
  logAdminActivity,
  exportToCsv,
  subscribeMatchProofs,
  verifyMatchProof,
} from '../services/adminService';
import { TournamentResult, Tournament, MatchProof } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useAuth } from '../context/AuthContext';

export const ResultsView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [activeSubTab, setActiveSubTab] = useState<'results' | 'proofs'>('results');
  const [results, setResults] = useState<TournamentResult[]>([]);
  const [matchProofs, setMatchProofs] = useState<MatchProof[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedTourn, setSelectedTourn] = useState<string>('ALL');
  const [selectedProof, setSelectedProof] = useState<MatchProof | null>(null);

  // Modals
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingResult, setEditingResult] = useState<Partial<TournamentResult> | null>(null);
  const [creditPrizeResult, setCreditPrizeResult] = useState<TournamentResult | null>(null);
  const [winnerEmailInput, setWinnerEmailInput] = useState<string>('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<boolean>(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const [resData, tournData] = await Promise.all([
        getTournamentResults(),
        getTournaments(),
      ]);
      setResults(resData);
      setTournaments(tournData);
    } catch (err) {
      console.error('Error loading results:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    const unsub = subscribeMatchProofs((proofs) => {
      setMatchProofs(proofs);
    });
    return () => unsub();
  }, []);

  const handleOpenCreate = () => {
    setEditingResult({
      tournamentId: tournaments[0]?.id || '',
      tournamentName: tournaments[0]?.name || '',
      rank: 1,
      teamName: '',
      captainName: '',
      captainFfUid: '',
      kills: 0,
      totalPoints: 0,
      prizeMoney: 0,
      isPrizeCredited: false,
      isPublished: true,
    });
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingResult?.teamName?.trim()) {
      alert('Team Name is required');
      return;
    }
    const tourn = tournaments.find((t) => t.id === editingResult.tournamentId);

    try {
      await saveTournamentResult({
        ...editingResult,
        tournamentName: tourn?.name || editingResult.tournamentName || 'Tournament',
      });

      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          editingResult.id ? 'EDIT_RESULT' : 'CREATE_RESULT',
          'tournamentResults',
          `Saved result for Rank #${editingResult.rank}: ${editingResult.teamName}`,
          editingResult.id
        );
      }
      setIsModalOpen(false);
      setEditingResult(null);
      await loadData();
    } catch (err) {
      console.error('Error saving result:', err);
      alert('Failed to save tournament result');
    }
  };

  const handleOpenCreditPrize = (res: TournamentResult) => {
    setCreditPrizeResult(res);
    setWinnerEmailInput('');
  };

  const handleConfirmCreditPrize = async () => {
    if (!creditPrizeResult || !adminProfile) return;
    if (!winnerEmailInput.trim()) {
      alert('Please provide the winner user account email to credit the wallet balance.');
      return;
    }
    setActionLoading(true);
    try {
      await creditTournamentPrize(
        creditPrizeResult.id,
        winnerEmailInput.trim(),
        creditPrizeResult.prizeMoney,
        creditPrizeResult.tournamentName,
        { id: adminProfile.id, email: adminProfile.email, role }
      );

      await logAdminActivity(
        { id: adminProfile.id, email: adminProfile.email, role },
        'CREDIT_PRIZE_MONEY',
        'wallets',
        `Credited prize of ₹${creditPrizeResult.prizeMoney} to ${winnerEmailInput} for ${creditPrizeResult.tournamentName} (Rank #${creditPrizeResult.rank})`,
        creditPrizeResult.id
      );

      setCreditPrizeResult(null);
      await loadData();
      alert('Prize money successfully credited to user wallet!');
    } catch (err: any) {
      console.error('Error crediting prize:', err);
      alert(err.message || 'Failed to credit prize');
    } finally {
      setActionLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteConfirmId) return;
    try {
      await deleteTournamentResult(deleteConfirmId);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'DELETE_RESULT',
          'tournamentResults',
          `Deleted tournament result ${deleteConfirmId}`,
          deleteConfirmId
        );
      }
      setDeleteConfirmId(null);
      await loadData();
    } catch (err) {
      console.error('Error deleting result:', err);
    }
  };

  const handleExportCsv = () => {
    const rows = filteredResults.map((r) => ({
      ID: r.id,
      Tournament: r.tournamentName,
      Rank: r.rank,
      Team: r.teamName,
      CaptainName: r.captainName || '',
      CaptainFF_UID: r.captainFfUid || '',
      Kills: r.kills,
      TotalPoints: r.totalPoints,
      PrizeMoney: r.prizeMoney,
      PrizeCredited: r.isPrizeCredited ? 'YES' : 'NO',
      Published: r.isPublished ? 'YES' : 'NO',
    }));
    exportToCsv('tournament_final_results', rows);
  };

  const filteredResults = results.filter((r) => {
    if (selectedTourn === 'ALL') return true;
    return r.tournamentId === selectedTourn;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <span>Tournament Results & Prize Distribution</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Publish official champion standings, declare winners, and credit prize money directly to player wallets with atomic ledger verification.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            id="btn-export-results-csv"
            onClick={handleExportCsv}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold border border-zinc-700 transition cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </button>
          <button
            id="btn-add-result"
            onClick={handleOpenCreate}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold transition shadow-lg shadow-amber-500/20 active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Declare Result</span>
          </button>
        </div>
      </div>

      {/* Sub Tabs */}
      <div className="flex items-center gap-2 border-b border-zinc-800 pb-3">
        <button
          onClick={() => setActiveSubTab('results')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeSubTab === 'results'
              ? 'bg-amber-500 text-zinc-950 shadow-md shadow-amber-500/20'
              : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
          }`}
        >
          🏆 Official Standings & Declarations ({results.length})
        </button>
        <button
          onClick={() => setActiveSubTab('proofs')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer relative ${
            activeSubTab === 'proofs'
              ? 'bg-amber-500 text-zinc-950 shadow-md shadow-amber-500/20'
              : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
          }`}
        >
          <span>📸 Player Uploaded Proofs & Screenshots</span>
          {matchProofs.filter((p) => p.status === 'Pending').length > 0 && (
            <span className="ml-2 px-1.5 py-0.2 rounded-full bg-rose-500 text-[10px] text-white font-extrabold">
              {matchProofs.filter((p) => p.status === 'Pending').length} pending
            </span>
          )}
        </button>
      </div>

      {activeSubTab === 'proofs' ? (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800">
            <h3 className="text-sm font-bold text-white mb-1">Uploaded Match Screenshots & Kill Proofs</h3>
            <p className="text-xs text-zinc-400">Review screenshots uploaded by players after matches to verify their claimed kills and standings before crediting prizes.</p>
          </div>

          {matchProofs.length === 0 ? (
            <div className="p-8 text-center bg-zinc-900/50 rounded-2xl border border-zinc-800">
              <p className="text-xs text-zinc-400">No match proofs submitted by players yet.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {matchProofs.map((proof) => (
                <div key={proof.id} className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">{proof.teamName}</span>
                    <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                      proof.status === 'Verified' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                      proof.status === 'Rejected' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' :
                      'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    }`}>
                      {proof.status}
                    </span>
                  </div>

                  <div className="text-xs text-zinc-400 space-y-1">
                    <p><span className="text-zinc-500">Tournament:</span> {proof.tournamentName}</p>
                    <p><span className="text-zinc-500">Player:</span> {proof.userName} ({proof.userEmail})</p>
                    <p><span className="text-zinc-500">Claimed Kills:</span> <strong className="text-amber-400">{proof.claimedKills} kills</strong></p>
                    <p><span className="text-zinc-500">Claimed Rank:</span> <strong className="text-white">#{proof.claimedRank}</strong></p>
                  </div>

                  {proof.screenshotUrl && (
                    <div className="relative group rounded-xl overflow-hidden border border-zinc-800 bg-black aspect-video flex items-center justify-center">
                      <img src={proof.screenshotUrl} alt="Match Proof" className="w-full h-full object-cover" />
                      <button
                        onClick={() => setSelectedProof(proof)}
                        className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition flex items-center justify-center text-xs font-bold text-white gap-1 cursor-pointer"
                      >
                        <Eye className="w-4 h-4" /> View Full Screenshot
                      </button>
                    </div>
                  )}

                  {proof.status === 'Pending' && (
                    <div className="flex items-center gap-2 pt-2 border-t border-zinc-800">
                      <button
                        onClick={async () => {
                          await verifyMatchProof(proof.id, 'Verified', 'Verified by Admin', adminProfile?.name);
                          alert('Proof Verified successfully!');
                        }}
                        className="flex-1 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-bold transition cursor-pointer"
                      >
                        ✓ Verify Proof
                      </button>
                      <button
                        onClick={async () => {
                          await verifyMatchProof(proof.id, 'Rejected', 'Invalid screenshot or stats mismatch', adminProfile?.name);
                          alert('Proof Rejected');
                        }}
                        className="flex-1 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500 text-rose-300 hover:text-white text-xs font-bold transition border border-rose-500/30 cursor-pointer"
                      >
                        ✗ Reject
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Screenshot Modal */}
          {selectedProof && (
            <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
              <div className="max-w-3xl w-full bg-zinc-900 border border-zinc-800 rounded-2xl p-4 space-y-3 max-h-[90vh] overflow-y-auto">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white">Screenshot Proof - {selectedProof.teamName}</h3>
                  <button onClick={() => setSelectedProof(null)} className="p-1 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white">✕</button>
                </div>
                <img src={selectedProof.screenshotUrl} alt="Proof Full" className="w-full rounded-xl border border-zinc-800" />
              </div>
            </div>
          )}
        </div>
      ) : (
        <>
          {/* Filter */}
          <div className="max-w-md">
            <select
              value={selectedTourn}
              onChange={(e) => setSelectedTourn(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 cursor-pointer"
            >
              <option value="ALL">All Tournaments ({results.length} results)</option>
              {tournaments.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>
        </>
      )}

      {/* Table */}
      {loading ? (
        <LoadingSpinner text="Fetching tournament results from Firestore..." />
      ) : filteredResults.length === 0 ? (
        <EmptyState
          icon={Trophy}
          title="No tournament results declared"
          description="There are currently no final match results recorded in Firebase for this tournament."
          actionLabel="Declare Winner"
          onAction={handleOpenCreate}
        />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-zinc-800 bg-zinc-900/60 shadow-xl">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="border-b border-zinc-800 bg-zinc-950/80 text-[10px] uppercase font-bold text-zinc-400 tracking-wider">
              <tr>
                <th className="px-4 py-3.5">Standing</th>
                <th className="px-4 py-3.5">Tournament & Team</th>
                <th className="px-4 py-3.5">Captain UID</th>
                <th className="px-4 py-3.5 text-center">Kills</th>
                <th className="px-4 py-3.5 text-center">Points</th>
                <th className="px-4 py-3.5">Prize Pool Won</th>
                <th className="px-4 py-3.5">Prize Status</th>
                <th className="px-4 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60">
              {filteredResults.map((r) => (
                <tr key={r.id} className="hover:bg-zinc-800/40 transition">
                  <td className="px-4 py-3">
                    <span
                      className={`inline-flex items-center justify-center w-7 h-7 rounded-lg font-bold text-xs ${
                        r.rank === 1
                          ? 'bg-amber-500 text-zinc-950 shadow-md shadow-amber-500/20'
                          : r.rank === 2
                          ? 'bg-zinc-300 text-zinc-950'
                          : r.rank === 3
                          ? 'bg-amber-700 text-white'
                          : 'bg-zinc-800 text-zinc-400'
                      }`}
                    >
                      #{r.rank}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="font-bold text-white tracking-tight">{r.teamName}</div>
                    <div className="text-[11px] text-zinc-400 mt-0.5">{r.tournamentName}</div>
                  </td>
                  <td className="px-4 py-3 font-mono">
                    <div className="text-amber-400 font-bold">{r.captainFfUid || 'N/A'}</div>
                    <div className="text-[10px] text-zinc-500">{r.captainName}</div>
                  </td>
                  <td className="px-4 py-3 font-mono text-center font-bold text-zinc-200">{r.kills}</td>
                  <td className="px-4 py-3 font-mono text-center font-bold text-amber-400">{r.totalPoints}</td>
                  <td className="px-4 py-3 font-mono">
                    <span className="font-bold text-emerald-400 text-sm">₹{r.prizeMoney}</span>
                  </td>
                  <td className="px-4 py-3">
                    {r.isPrizeCredited ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        <CheckCircle2 className="w-3 h-3" /> Credited to Wallet
                      </span>
                    ) : r.prizeMoney > 0 ? (
                      <button
                        onClick={() => handleOpenCreditPrize(r)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 font-bold text-xs border border-amber-500/20 transition cursor-pointer"
                      >
                        <Wallet className="w-3 h-3" />
                        <span>Credit Prize</span>
                      </button>
                    ) : (
                      <span className="text-[10px] text-zinc-500">No Prize</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => setDeleteConfirmId(r.id)}
                      className="p-1.5 rounded-lg text-zinc-500 hover:text-rose-400 hover:bg-zinc-800 transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Credit Prize Modal */}
      {creditPrizeResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl border border-zinc-800 bg-zinc-900 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" />
              <span>Credit Tournament Prize Money</span>
            </h3>
            <p className="text-xs text-zinc-300">
              You are crediting <strong className="text-emerald-400">₹{creditPrizeResult.prizeMoney}</strong> to the winning captain for{' '}
              <strong>{creditPrizeResult.teamName}</strong> (Rank #{creditPrizeResult.rank}).
            </p>

            <div>
              <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                Winner Account Email in Platform <span className="text-rose-400">*</span>
              </label>
              <input
                type="email"
                required
                placeholder="captain@gmail.com"
                value={winnerEmailInput}
                onChange={(e) => setWinnerEmailInput(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-sm text-white font-mono focus:border-amber-500 focus:outline-none"
              />
              <span className="text-[10px] text-zinc-500 mt-1 block">
                This will atomically create/update their wallet balance and write a certified ledger entry.
              </span>
            </div>

            <div className="flex justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={() => setCreditPrizeResult(null)}
                className="px-4 py-2 rounded-xl border border-zinc-700 text-xs font-semibold text-zinc-300 hover:bg-zinc-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmCreditPrize}
                disabled={actionLoading}
                className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow-lg shadow-amber-500/20 cursor-pointer"
              >
                {actionLoading ? 'Processing...' : 'Transfer to Wallet'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Declare Result Modal */}
      {isModalOpen && editingResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl border border-zinc-800 bg-zinc-900 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white">Declare Tournament Standing</h3>

            <form onSubmit={handleSave} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Tournament</label>
                <select
                  value={editingResult.tournamentId || ''}
                  onChange={(e) => setEditingResult({ ...editingResult, tournamentId: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
                >
                  {tournaments.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Rank Standing</label>
                  <input
                    type="number"
                    min={1}
                    value={editingResult.rank ?? 1}
                    onChange={(e) => setEditingResult({ ...editingResult, rank: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-sm text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Prize Money (₹)</label>
                  <input
                    type="number"
                    min={0}
                    value={editingResult.prizeMoney ?? 0}
                    onChange={(e) => setEditingResult({ ...editingResult, prizeMoney: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-sm text-emerald-400 font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Team Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. GodLike Esports"
                  value={editingResult.teamName || ''}
                  onChange={(e) => setEditingResult({ ...editingResult, teamName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Captain Name</label>
                  <input
                    type="text"
                    value={editingResult.captainName || ''}
                    onChange={(e) => setEditingResult({ ...editingResult, captainName: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Captain FF UID</label>
                  <input
                    type="text"
                    value={editingResult.captainFfUid || ''}
                    onChange={(e) => setEditingResult({ ...editingResult, captainFfUid: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Total Kills</label>
                  <input
                    type="number"
                    min={0}
                    value={editingResult.kills ?? 0}
                    onChange={(e) => setEditingResult({ ...editingResult, kills: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-sm text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Total Points</label>
                  <input
                    type="number"
                    min={0}
                    value={editingResult.totalPoints ?? 0}
                    onChange={(e) => setEditingResult({ ...editingResult, totalPoints: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-sm text-white font-mono"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-zinc-700 text-xs font-semibold text-zinc-300 hover:bg-zinc-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow-lg shadow-amber-500/20 cursor-pointer"
                >
                  Save Standing
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmationModal
        isOpen={!!deleteConfirmId}
        title="Delete Standing Result"
        message="Are you sure you want to remove this standing record?"
        isDangerous
        onConfirm={handleDelete}
        onCancel={() => setDeleteConfirmId(null)}
      />
    </div>
  );
};
