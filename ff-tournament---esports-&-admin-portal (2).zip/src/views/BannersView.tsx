import React, { useEffect, useState } from 'react';
import {
  Image as ImageIcon,
  Plus,
  Trash2,
  Eye,
  EyeOff,
  ExternalLink,
  Edit2,
  Sparkles,
} from 'lucide-react';
import { getBanners, saveBanner, deleteBanner, logAdminActivity } from '../services/adminService';
import { Banner } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useAuth } from '../context/AuthContext';

export const BannersView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Modals
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingBanner, setEditingBanner] = useState<Partial<Banner> | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const loadBanners = async () => {
    try {
      setLoading(true);
      const data = await getBanners();
      setBanners(data);
    } catch (err) {
      console.error('Error loading banners:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBanners();
  }, []);

  const handleOpenCreate = () => {
    setEditingBanner({
      title: '',
      imageUrl: '',
      linkUrl: '',
      order: banners.length + 1,
      isActive: true,
    });
    setIsModalOpen(true);
  };

  const handleToggleActive = async (banner: Banner) => {
    try {
      const next = !banner.isActive;
      await saveBanner({ id: banner.id, isActive: next });
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          next ? 'ACTIVATE_BANNER' : 'DEACTIVATE_BANNER',
          'banners',
          `${next ? 'Activated' : 'Deactivated'} banner "${banner.title}"`,
          banner.id
        );
      }
      await loadBanners();
    } catch (err) {
      console.error('Error toggling banner status:', err);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBanner?.title?.trim() || !editingBanner?.imageUrl?.trim()) {
      alert('Title and Image URL are required');
      return;
    }

    try {
      await saveBanner(editingBanner);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          editingBanner.id ? 'EDIT_BANNER' : 'CREATE_BANNER',
          'banners',
          `Saved banner "${editingBanner.title}"`,
          editingBanner.id
        );
      }
      setIsModalOpen(false);
      setEditingBanner(null);
      await loadBanners();
    } catch (err) {
      console.error('Error saving banner:', err);
      alert('Failed to save banner');
    }
  };

  const handleDelete = async () => {
    if (!deleteConfirmId) return;
    try {
      await deleteBanner(deleteConfirmId);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'DELETE_BANNER',
          'banners',
          `Deleted banner ${deleteConfirmId}`,
          deleteConfirmId
        );
      }
      setDeleteConfirmId(null);
      await loadBanners();
    } catch (err) {
      console.error('Error deleting banner:', err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <ImageIcon className="w-5 h-5 text-amber-400" />
            <span>Hero Banners & Slider Promotions</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Manage top home screen carousel slides, promotional announcements, and direct click-through action links.
          </p>
        </div>
        <button
          id="btn-add-banner"
          onClick={handleOpenCreate}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold transition shadow-lg shadow-amber-500/20 active:scale-95 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Banner</span>
        </button>
      </div>

      {/* Grid */}
      {loading ? (
        <LoadingSpinner text="Fetching promotional banners from Firestore..." />
      ) : banners.length === 0 ? (
        <EmptyState
          icon={ImageIcon}
          title="No banners published"
          description="There are currently no homepage banners in Firebase."
          actionLabel="Create First Banner"
          onAction={handleOpenCreate}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {banners.map((b) => (
            <div
              key={b.id}
              className="rounded-2xl border border-zinc-800 bg-zinc-900/80 overflow-hidden shadow-lg flex flex-col justify-between hover:border-zinc-700 transition"
            >
              <div>
                <div className="relative aspect-video w-full bg-zinc-950 overflow-hidden">
                  <img
                    src={b.imageUrl}
                    alt={b.title}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-2 right-2">
                    <button
                      onClick={() => handleToggleActive(b)}
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 cursor-pointer transition ${
                        b.isActive
                          ? 'bg-emerald-500 text-zinc-950 shadow'
                          : 'bg-zinc-900/90 text-zinc-400 border border-zinc-700'
                      }`}
                    >
                      {b.isActive ? (
                        <>
                          <Eye className="w-3 h-3" /> Active
                        </>
                      ) : (
                        <>
                          <EyeOff className="w-3 h-3" /> Inactive
                        </>
                      )}
                    </button>
                  </div>
                  <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-sm text-[10px] font-mono text-zinc-300">
                    Order #{b.order}
                  </div>
                </div>

                <div className="p-4 space-y-2">
                  <h3 className="text-sm font-bold text-white tracking-tight">{b.title}</h3>
                  {b.linkUrl && (
                    <a
                      href={b.linkUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="text-[11px] text-amber-400 hover:underline flex items-center gap-1 truncate"
                    >
                      <span>{b.linkUrl}</span>
                      <ExternalLink className="w-3 h-3 shrink-0" />
                    </a>
                  )}
                </div>
              </div>

              <div className="p-4 pt-0 flex justify-end gap-2 border-t border-zinc-800/60 mt-2">
                <button
                  onClick={() => {
                    setEditingBanner(b);
                    setIsModalOpen(true);
                  }}
                  className="p-1.5 rounded-lg text-amber-400 hover:bg-zinc-800 transition cursor-pointer"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setDeleteConfirmId(b.id)}
                  className="p-1.5 rounded-lg text-zinc-500 hover:text-rose-400 hover:bg-zinc-800 transition cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Banner Modal */}
      {isModalOpen && editingBanner && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl border border-zinc-800 bg-zinc-900 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white">
              {editingBanner.id ? 'Edit Banner' : 'Create Banner'}
            </h3>

            <form onSubmit={handleSave} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Banner Title <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Free Fire Grand Finals Registration Open"
                  value={editingBanner.title || ''}
                  onChange={(e) => setEditingBanner({ ...editingBanner, title: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Image URL <span className="text-rose-400">*</span>
                </label>
                <input
                  type="url"
                  required
                  placeholder="https://images.unsplash.com/..."
                  value={editingBanner.imageUrl || ''}
                  onChange={(e) => setEditingBanner({ ...editingBanner, imageUrl: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Click-through Redirect Link
                </label>
                <input
                  type="text"
                  placeholder="https://..."
                  value={editingBanner.linkUrl || ''}
                  onChange={(e) => setEditingBanner({ ...editingBanner, linkUrl: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Display Order Priority
                </label>
                <input
                  type="number"
                  min={1}
                  value={editingBanner.order ?? 1}
                  onChange={(e) => setEditingBanner({ ...editingBanner, order: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-sm text-white font-mono"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="chk-banner-active"
                  checked={editingBanner.isActive || false}
                  onChange={(e) => setEditingBanner({ ...editingBanner, isActive: e.target.checked })}
                  className="w-4 h-4 rounded text-amber-500 border-zinc-700 bg-zinc-900 cursor-pointer"
                />
                <label htmlFor="chk-banner-active" className="text-xs text-zinc-300 cursor-pointer">
                  Publish and show on homepage slider immediately
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-zinc-700 text-xs font-semibold text-zinc-300 hover:bg-zinc-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow-lg shadow-amber-500/20 cursor-pointer"
                >
                  Save Banner
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmationModal
        isOpen={!!deleteConfirmId}
        title="Delete Banner"
        message="Are you sure you want to remove this promotional banner from Firebase?"
        isDangerous
        onConfirm={handleDelete}
        onCancel={() => setDeleteConfirmId(null)}
      />
    </div>
  );
};
