import React, { useEffect, useState } from 'react';
import {
  LifeBuoy,
  Search,
  CheckCircle2,
  Clock,
  AlertCircle,
  MessageSquare,
  Send,
  User,
  Shield,
} from 'lucide-react';
import {
  getSupportTickets,
  updateTicketStatus,
  addTicketReply,
  logAdminActivity,
} from '../services/adminService';
import { SupportTicket, TicketStatus } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';
import { useAuth } from '../context/AuthContext';

export const SupportView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Selected Ticket Drawer / Chat
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [replyText, setReplyText] = useState<string>('');
  const [replyLoading, setReplyLoading] = useState<boolean>(false);

  const loadTickets = async () => {
    try {
      setLoading(true);
      const data = await getSupportTickets();
      setTickets(data);
      if (selectedTicket) {
        const updated = data.find((t) => t.id === selectedTicket.id);
        if (updated) setSelectedTicket(updated);
      }
    } catch (err) {
      console.error('Error loading tickets:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTickets();
  }, []);

  const handleStatusChange = async (ticketId: string, newStatus: TicketStatus) => {
    try {
      await updateTicketStatus(ticketId, newStatus);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'UPDATE_TICKET_STATUS',
          'supportTickets',
          `Changed ticket status to ${newStatus}`,
          ticketId
        );
      }
      await loadTickets();
    } catch (err) {
      console.error('Error updating ticket status:', err);
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !replyText.trim() || !adminProfile) return;

    setReplyLoading(true);
    try {
      await addTicketReply(selectedTicket.id, {
        senderEmail: adminProfile.email,
        senderRole: 'ADMIN',
        message: replyText.trim(),
      });

      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'REPLY_SUPPORT_TICKET',
          'supportTickets',
          `Replied to ticket: ${selectedTicket.subject}`,
          selectedTicket.id
        );
      }

      setReplyText('');
      await loadTickets();
    } catch (err) {
      console.error('Error sending reply:', err);
      alert('Failed to send reply');
    } finally {
      setReplyLoading(false);
    }
  };

  const filteredTickets = tickets.filter((t) => {
    const term = search.toLowerCase();
    const matchesSearch =
      t.userEmail?.toLowerCase().includes(term) ||
      t.subject?.toLowerCase().includes(term) ||
      t.category?.toLowerCase().includes(term);
    const matchesStatus = statusFilter === 'ALL' || t.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <LifeBuoy className="w-5 h-5 text-amber-400" />
            <span>Player Support Helpdesk & Dispute Tickets</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Resolve player payment queries, room credential disputes, hacker reports, and account questions.
          </p>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-xl">
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search tickets by user, subject, category..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 cursor-pointer"
          >
            <option value="ALL">All Ticket Statuses ({tickets.length})</option>
            <option value="Open">Open</option>
            <option value="In Progress">In Progress</option>
            <option value="Resolved">Resolved</option>
            <option value="Closed">Closed</option>
          </select>
        </div>
      </div>

      {/* Main Support Layout: Tickets List + Chat Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Tickets List */}
        <div className={selectedTicket ? 'lg:col-span-5' : 'lg:col-span-12'}>
          {loading ? (
            <LoadingSpinner text="Fetching support tickets from Firestore..." />
          ) : filteredTickets.length === 0 ? (
            <EmptyState
              icon={LifeBuoy}
              title="No support tickets found"
              description="There are currently no support inquiries submitted by users."
            />
          ) : (
            <div className="space-y-3">
              {filteredTickets.map((t) => {
                const isSelected = selectedTicket?.id === t.id;
                return (
                  <div
                    key={t.id}
                    onClick={() => setSelectedTicket(t)}
                    className={`p-4 rounded-2xl border transition cursor-pointer ${
                      isSelected
                        ? 'border-amber-500 bg-amber-500/10'
                        : 'border-zinc-800 bg-zinc-900/80 hover:border-zinc-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span
                            className={`text-[9px] font-bold px-2 py-0.5 rounded uppercase font-mono ${
                              t.priority === 'Critical'
                                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                : t.priority === 'High'
                                ? 'bg-orange-500/20 text-orange-300'
                                : 'bg-zinc-800 text-zinc-400'
                            }`}
                          >
                            {t.priority}
                          </span>
                          <span className="text-[10px] text-zinc-500 font-mono uppercase">{t.category}</span>
                        </div>
                        <h4 className="text-sm font-bold text-white mt-1.5">{t.subject}</h4>
                        <span className="text-[11px] text-zinc-400 block mt-0.5">{t.userEmail}</span>
                      </div>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                          t.status === 'Resolved'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : t.status === 'In Progress'
                            ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                            : t.status === 'Closed'
                            ? 'bg-zinc-800 text-zinc-500'
                            : 'bg-amber-500/10 text-amber-400 border border-amber-500/20 animate-pulse'
                        }`}
                      >
                        {t.status}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Ticket Chat & Management Panel */}
        {selectedTicket && (
          <div className="lg:col-span-7">
            <div className="rounded-2xl border border-zinc-800 bg-zinc-900 flex flex-col h-[650px] shadow-2xl overflow-hidden">
              {/* Ticket Top Header */}
              <div className="p-4 border-b border-zinc-800 bg-zinc-950 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-amber-400 font-mono">#{selectedTicket.id.slice(0, 8)}</span>
                    <h3 className="text-sm font-bold text-white truncate max-w-sm">{selectedTicket.subject}</h3>
                  </div>
                  <span className="text-[11px] text-zinc-400">{selectedTicket.userEmail}</span>
                </div>

                {/* Status Dropdown */}
                <select
                  value={selectedTicket.status}
                  onChange={(e) => handleStatusChange(selectedTicket.id, e.target.value as TicketStatus)}
                  className="px-3 py-1 rounded-lg bg-zinc-900 border border-zinc-700 text-xs font-bold text-zinc-200 focus:outline-none focus:border-amber-500 cursor-pointer"
                >
                  <option value="Open">Status: Open</option>
                  <option value="In Progress">Status: In Progress</option>
                  <option value="Resolved">Status: Resolved</option>
                  <option value="Closed">Status: Closed</option>
                </select>
              </div>

              {/* Messages Area */}
              <div className="flex-1 p-4 overflow-y-auto space-y-4">
                {/* Initial Ticket Message */}
                <div className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800/80 space-y-1">
                  <div className="flex items-center justify-between text-[11px] text-zinc-400">
                    <span className="font-semibold text-zinc-200 flex items-center gap-1.5">
                      <User className="w-3 h-3 text-amber-400" />
                      {selectedTicket.userEmail}
                    </span>
                    <span className="font-mono text-[10px]">
                      {new Date(selectedTicket.createdAt).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-xs text-zinc-300 whitespace-pre-wrap">{selectedTicket.message}</p>
                </div>

                {/* Thread Replies */}
                {selectedTicket.replies?.map((rep) => {
                  const isAdmin = rep.senderRole === 'ADMIN';
                  return (
                    <div
                      key={rep.id}
                      className={`p-3.5 rounded-xl border space-y-1 ${
                        isAdmin
                          ? 'bg-amber-500/10 border-amber-500/20 ml-6'
                          : 'bg-zinc-950 border-zinc-800/80 mr-6'
                      }`}
                    >
                      <div className="flex items-center justify-between text-[11px] text-zinc-400">
                        <span
                          className={`font-semibold flex items-center gap-1.5 ${
                            isAdmin ? 'text-amber-400' : 'text-zinc-200'
                          }`}
                        >
                          {isAdmin ? (
                            <>
                              <Shield className="w-3 h-3 text-amber-400" />
                              <span>Support Staff ({rep.senderEmail})</span>
                            </>
                          ) : (
                            <>
                              <User className="w-3 h-3 text-zinc-400" />
                              <span>{rep.senderEmail}</span>
                            </>
                          )}
                        </span>
                        <span className="font-mono text-[10px]">
                          {new Date(rep.createdAt).toLocaleString([], {
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                      <p className="text-xs text-zinc-200 whitespace-pre-wrap">{rep.message}</p>
                    </div>
                  );
                })}
              </div>

              {/* Reply Box */}
              <form onSubmit={handleSendReply} className="p-3 bg-zinc-950 border-t border-zinc-800 flex gap-2">
                <input
                  type="text"
                  placeholder="Type your response to the player..."
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  className="flex-1 px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
                />
                <button
                  type="submit"
                  disabled={replyLoading || !replyText.trim()}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-zinc-950 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send</span>
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
