import React, { useEffect, useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  Calendar,
  DollarSign,
  Trophy,
  Users,
  CreditCard,
  ArrowDownCircle,
  ArrowUpCircle,
  TrendingUp,
} from 'lucide-react';
import {
  getTournaments,
  getRegistrations,
  getDeposits,
  getWithdrawals,
  getWalletTransactions,
  getUsers,
  exportToCsv,
} from '../services/adminService';
import { LoadingSpinner } from '../components/LoadingSpinner';

export const ReportsView: React.FC = () => {
  const [loading, setLoading] = useState<boolean>(true);
  const [tournaments, setTournaments] = useState<any[]>([]);
  const [registrations, setRegistrations] = useState<any[]>([]);
  const [deposits, setDeposits] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);

  useEffect(() => {
    const fetchAll = async () => {
      try {
        setLoading(true);
        const [t, r, d, w, tx, u] = await Promise.all([
          getTournaments(),
          getRegistrations(),
          getDeposits(),
          getWithdrawals(),
          getWalletTransactions(),
          getUsers(),
        ]);
        setTournaments(t);
        setRegistrations(r);
        setDeposits(d);
        setWithdrawals(w);
        setTransactions(tx);
        setUsers(u);
      } catch (err) {
        console.error('Error loading report datasets:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, []);

  const handleExportTournaments = () => {
    exportToCsv('Tournaments_Report', tournaments);
  };

  const handleExportRegistrations = () => {
    exportToCsv('Registrations_Report', registrations);
  };

  const handleExportDeposits = () => {
    exportToCsv('Deposits_Report', deposits);
  };

  const handleExportWithdrawals = () => {
    exportToCsv('Withdrawals_Report', withdrawals);
  };

  const handleExportLedger = () => {
    exportToCsv('Wallet_Transactions_Ledger', transactions);
  };

  const handleExportUsers = () => {
    exportToCsv('Users_Directory', users);
  };

  if (loading) {
    return <LoadingSpinner text="Compiling financial telemetry and audit logs..." />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
          <FileSpreadsheet className="w-5 h-5 text-amber-400" />
          <span>Financial Reports & Data Exports</span>
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Generate audit-ready CSV exports for registrations, payouts, wallet transactions, and revenues.
        </p>
      </div>

      {/* Export Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Card 1: Tournaments */}
        <div className="rounded-2xl border border-[#1E1E24] bg-[#0F1115] p-5 flex flex-col justify-between space-y-4">
          <div>
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mb-3">
              <Trophy className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-white">Tournaments Dataset</h3>
            <p className="text-xs text-slate-400 mt-1">
              All tournaments created, formats, prize pools, entry fees, and completion statuses.
            </p>
            <p className="text-xs font-mono font-bold text-amber-400 mt-2">
              {tournaments.length} Records
            </p>
          </div>
          <button
            onClick={handleExportTournaments}
            className="w-full py-2 px-3 rounded-xl bg-[#0A0A0B] hover:bg-zinc-800 border border-[#1E1E24] text-slate-200 text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Export CSV</span>
          </button>
        </div>

        {/* Card 2: Registrations */}
        <div className="rounded-2xl border border-[#1E1E24] bg-[#0F1115] p-5 flex flex-col justify-between space-y-4">
          <div>
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-3">
              <Users className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-white">Registrations & Teams</h3>
            <p className="text-xs text-slate-400 mt-1">
              Player registration records, team rosters, UID mappings, and payment verification tags.
            </p>
            <p className="text-xs font-mono font-bold text-emerald-400 mt-2">
              {registrations.length} Records
            </p>
          </div>
          <button
            onClick={handleExportRegistrations}
            className="w-full py-2 px-3 rounded-xl bg-[#0A0A0B] hover:bg-zinc-800 border border-[#1E1E24] text-slate-200 text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>
        </div>

        {/* Card 3: Deposits */}
        <div className="rounded-2xl border border-[#1E1E24] bg-[#0F1115] p-5 flex flex-col justify-between space-y-4">
          <div>
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center mb-3">
              <ArrowDownCircle className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-white">Deposit Inflows</h3>
            <p className="text-xs text-slate-400 mt-1">
              Verified UPI & QR user wallet deposits with 12-digit UTR reference numbers.
            </p>
            <p className="text-xs font-mono font-bold text-purple-400 mt-2">
              {deposits.length} Records
            </p>
          </div>
          <button
            onClick={handleExportDeposits}
            className="w-full py-2 px-3 rounded-xl bg-[#0A0A0B] hover:bg-zinc-800 border border-[#1E1E24] text-slate-200 text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-purple-400" />
            <span>Export CSV</span>
          </button>
        </div>

        {/* Card 4: Withdrawals */}
        <div className="rounded-2xl border border-[#1E1E24] bg-[#0F1115] p-5 flex flex-col justify-between space-y-4">
          <div>
            <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center mb-3">
              <ArrowUpCircle className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-white">Payouts & Withdrawals</h3>
            <p className="text-xs text-slate-400 mt-1">
              User withdrawal requests, payout accounts, net disbursed amounts, and transaction IDs.
            </p>
            <p className="text-xs font-mono font-bold text-rose-400 mt-2">
              {withdrawals.length} Records
            </p>
          </div>
          <button
            onClick={handleExportWithdrawals}
            className="w-full py-2 px-3 rounded-xl bg-[#0A0A0B] hover:bg-zinc-800 border border-[#1E1E24] text-slate-200 text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-rose-400" />
            <span>Export CSV</span>
          </button>
        </div>

        {/* Card 5: Wallet Ledger */}
        <div className="rounded-2xl border border-[#1E1E24] bg-[#0F1115] p-5 flex flex-col justify-between space-y-4">
          <div>
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center mb-3">
              <TrendingUp className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-white">Full Wallet Ledger</h3>
            <p className="text-xs text-slate-400 mt-1">
              Immutable log of every deposit, tournament entry fee debit, winnings credit, and adjustment.
            </p>
            <p className="text-xs font-mono font-bold text-cyan-400 mt-2">
              {transactions.length} Records
            </p>
          </div>
          <button
            onClick={handleExportLedger}
            className="w-full py-2 px-3 rounded-xl bg-[#0A0A0B] hover:bg-zinc-800 border border-[#1E1E24] text-slate-200 text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export CSV</span>
          </button>
        </div>

        {/* Card 6: User Directory */}
        <div className="rounded-2xl border border-[#1E1E24] bg-[#0F1115] p-5 flex flex-col justify-between space-y-4">
          <div>
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center mb-3">
              <Users className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-white">User Accounts Directory</h3>
            <p className="text-xs text-slate-400 mt-1">
              Registered users, game UIDs, phone numbers, total winnings, and account statuses.
            </p>
            <p className="text-xs font-mono font-bold text-indigo-400 mt-2">
              {users.length} Records
            </p>
          </div>
          <button
            onClick={handleExportUsers}
            className="w-full py-2 px-3 rounded-xl bg-[#0A0A0B] hover:bg-zinc-800 border border-[#1E1E24] text-slate-200 text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>
    </div>
  );
};
