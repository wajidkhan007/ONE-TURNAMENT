import React, { useEffect, useState } from 'react';
import {
  ArrowDownCircle,
  Search,
  CheckCircle2,
  XCircle,
  Image as ImageIcon,
  Download,
  AlertCircle,
  Wallet,
  ExternalLink,
} from 'lucide-react';
import { getDeposits, approveDeposit, rejectDeposit, logAdminActivity, exportToCsv } from '../services/adminService';
import { DepositRequest } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useAuth } from '../context/AuthContext';

export const DepositsView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [deposits, setDeposits] = useState<DepositRequest[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Preview & Confirmation
  const [viewScreenshotUrl, setViewScreenshotUrl] = useState<string | null>(null);
  const [approveConfirmDeposit, setApproveConfirmDeposit] = useState<DepositRequest | null>(null);
  const [rejectDepositId, setRejectDepositId] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<boolean>(false);

  const loadDeposits = async () => {
    try {
      setLoading(true);
      const data = await getDeposits();
      setDeposits(data);
    } catch (err) {
      console.error('Error loading deposits:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDeposits();
  }, []);

  const handleApprove = async () => {
    if (!approveConfirmDeposit || !adminProfile) return;
    setActionLoading(true);
    try {
      await approveDeposit(approveConfirmDeposit.id, {
        id: adminProfile.id,
        email: adminProfile.email,
        role,
      });

      await logAdminActivity(
        { id: adminProfile.id, email: adminProfile.email, role },
        'APPROVE_DEPOSIT',
        'deposits',
        `Approved deposit of ₹${approveConfirmDeposit.amount} for ${approveConfirmDeposit.userEmail} (UTR: ${approveConfirmDeposit.utrNumber})`,
        approveConfirmDeposit.id
      );

      setApproveConfirmDeposit(null);
      await loadDeposits();
    } catch (err: any) {
      console.error('Error approving deposit:', err);
      alert(err.message || 'Failed to approve deposit');
    } finally {
      setActionLoading(false);
    }
  };

  const handleReject = async (reason?: string) => {
    if (!rejectDepositId || !adminProfile) return;
    setActionLoading(true);
    try {
      const dep = deposits.find((d) => d.id === rejectDepositId);
      await rejectDeposit(rejectDepositId, reason || 'UTR verification failed', {
        id: adminProfile.id,
        email: adminProfile.email,
        role,
      });

      await logAdminActivity(
        { id: adminProfile.id, email: adminProfile.email, role },
        'REJECT_DEPOSIT',
        'deposits',
        `Rejected deposit of ₹${dep?.amount || 0} for ${dep?.userEmail}. Reason: ${reason || 'N/A'}`,
        rejectDepositId
      );

      setRejectDepositId(null);
      await loadDeposits();
    } catch (err) {
      console.error('Error rejecting deposit:', err);
    } finally {
      setActionLoading(false);
    }
  };

  const handleExportCsv = () => {
    const rows = filteredDeposits.map((d) => ({
      ID: d.id,
      UserEmail: d.userEmail,
      UserName: d.userName,
      Amount: d.amount,
      UTR: d.utrNumber,
      Status: d.status,
      Date: new Date(d.createdAt).toLocaleString(),
      ProcessedBy: d.processedBy || '',
      AdminNote: d.adminNote || '',
    }));
    exportToCsv('wallet_deposits', rows);
  };

  const filteredDeposits = deposits.filter((d) => {
    const term = search.toLowerCase();
    const matchesSearch =
      d.userEmail?.toLowerCase().includes(term) ||
      d.userName?.toLowerCase().includes(term) ||
      d.utrNumber?.toLowerCase().includes(term);
    const matchesStatus = statusFilter === 'ALL' || d.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <ArrowDownCircle className="w-5 h-5 text-emerald-400" />
            <span>Wallet Deposit Requests</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Verify user wallet top-up requests, validate banking UTR numbers, and credit user wallet balances atomically.
          </p>
        </div>
        <button
          id="btn-export-deposits-csv"
          onClick={handleExportCsv}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold border border-zinc-700 transition cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Filters & Search */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-xl">
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by User Email, UTR number..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 cursor-pointer"
          >
            <option value="ALL">All Deposit Statuses ({deposits.length})</option>
            <option value="Pending">Pending Verification</option>
            <option value="Approved">Approved (Credited)</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <LoadingSpinner text="Fetching wallet deposits from Firestore..." />
      ) : filteredDeposits.length === 0 ? (
        <EmptyState
          icon={ArrowDownCircle}
          title="No deposit requests found"
          description="There are currently no user wallet deposits recorded in Firebase."
        />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-zinc-800 bg-zinc-900/60 shadow-xl">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="border-b border-zinc-800 bg-zinc-950/80 text-[10px] uppercase font-bold text-zinc-400 tracking-wider">
              <tr>
                <th className="px-4 py-3.5">User</th>
                <th className="px-4 py-3.5">Amount</th>
                <th className="px-4 py-3.5">Bank UTR / Tx ID</th>
                <th className="px-4 py-3.5">Screenshot</th>
                <th className="px-4 py-3.5">Status</th>
                <th className="px-4 py-3.5">Date</th>
                <th className="px-4 py-3.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60">
              {filteredDeposits.map((d) => (
                <tr key={d.id} className="hover:bg-zinc-800/40 transition">
                  <td className="px-4 py-3">
                    <div className="font-bold text-white tracking-tight">{d.userEmail}</div>
                    <div className="text-[11px] text-zinc-400 mt-0.5">{d.userName || 'Player'}</div>
                  </td>
                  <td className="px-4 py-3 font-mono">
                    <span className="font-bold text-emerald-400 text-sm">₹{d.amount}</span>
                  </td>
                  <td className="px-4 py-3 font-mono font-bold text-amber-400">
                    {d.utrNumber || 'N/A'}
                  </td>
                  <td className="px-4 py-3">
                    {d.screenshotUrl ? (
                      <button
                        onClick={() => setViewScreenshotUrl(d.screenshotUrl!)}
                        className="inline-flex items-center gap-1 px-2 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[11px] transition cursor-pointer"
                      >
                        <ImageIcon className="w-3 h-3 text-amber-400" />
                        <span>View Proof</span>
                      </button>
                    ) : (
                      <span className="text-zinc-500 text-[11px]">No proof</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                        d.status === 'Approved'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : d.status === 'Rejected'
                          ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/20 animate-pulse'
                      }`}
                    >
                      {d.status}
                    </span>
                    {d.adminNote && (
                      <span className="block text-[10px] text-zinc-400 mt-1 truncate max-w-[120px]">
                        {d.adminNote}
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-[11px] text-zinc-400 font-mono">
                    {new Date(d.createdAt).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </td>
                  <td className="px-4 py-3 text-right">
                    {d.status === 'Pending' ? (
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setApproveConfirmDeposit(d)}
                          className="px-2.5 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs transition cursor-pointer"
                        >
                          Credit Wallet
                        </button>
                        <button
                          onClick={() => setRejectDepositId(d.id)}
                          className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 font-bold text-xs border border-rose-500/30 transition cursor-pointer"
                        >
                          Reject
                        </button>
                      </div>
                    ) : (
                      <span className="text-[11px] text-zinc-500">
                        {d.status === 'Approved' ? 'Credited' : 'Rejected'}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Screenshot Preview Modal */}
      {viewScreenshotUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="relative max-w-2xl w-full bg-zinc-900 rounded-2xl border border-zinc-800 p-4 shadow-2xl">
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-sm font-bold text-white">Deposit Screenshot / Banking Receipt</h3>
              <button
                onClick={() => setViewScreenshotUrl(null)}
                className="text-zinc-400 hover:text-white p-1 rounded-lg"
              >
                ✕
              </button>
            </div>
            <div className="max-h-[75vh] overflow-auto flex items-center justify-center rounded-xl bg-black p-2">
              <img
                src={viewScreenshotUrl}
                alt="Deposit proof receipt"
                className="max-h-[70vh] object-contain rounded-lg"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="mt-3 flex justify-between items-center">
              <a
                href={viewScreenshotUrl}
                target="_blank"
                rel="noreferrer"
                className="text-xs text-amber-400 hover:underline flex items-center gap-1"
              >
                <span>Open in full resolution</span>
                <ExternalLink className="w-3 h-3" />
              </a>
              <button
                onClick={() => setViewScreenshotUrl(null)}
                className="px-4 py-1.5 rounded-lg bg-zinc-800 text-xs font-semibold text-white hover:bg-zinc-700 cursor-pointer"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Approve Confirmation Modal */}
      {approveConfirmDeposit && (
        <ConfirmationModal
          isOpen={true}
          title="Approve Wallet Deposit"
          message={`Are you sure you want to approve this deposit and atomically credit ₹${approveConfirmDeposit.amount} to ${approveConfirmDeposit.userEmail}'s wallet?`}
          confirmText="Yes, Credit Wallet"
          isDangerous={false}
          isLoading={actionLoading}
          onConfirm={handleApprove}
          onCancel={() => setApproveConfirmDeposit(null)}
        />
      )}

      {/* Reject Modal */}
      <ConfirmationModal
        isOpen={!!rejectDepositId}
        title="Reject Deposit Request"
        message="Please state why this deposit request is being rejected (e.g., UTR not received in bank statement)."
        confirmText="Reject Deposit"
        isDangerous
        requireReason
        isLoading={actionLoading}
        reasonPlaceholder="e.g. Invalid UTR or payment not reflected in bank account..."
        onConfirm={handleReject}
        onCancel={() => setRejectDepositId(null)}
      />
    </div>
  );
};
