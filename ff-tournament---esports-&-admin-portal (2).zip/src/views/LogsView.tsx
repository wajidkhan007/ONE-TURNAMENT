import React, { useEffect, useState } from 'react';
import { History, Shield, Search, RefreshCw, UserCheck } from 'lucide-react';
import { getAdminLogs } from '../services/adminService';
import { AdminLog } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';

export const LogsView: React.FC = () => {
  const [logs, setLogs] = useState<AdminLog[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');

  const loadData = async () => {
    try {
      setLoading(true);
      const data = await getAdminLogs();
      setLogs(data);
    } catch (err) {
      console.error('Error loading admin logs:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const filteredLogs = logs.filter((log) => {
    const term = search.toLowerCase();
    return (
      log.action?.toLowerCase().includes(term) ||
      log.adminEmail?.toLowerCase().includes(term) ||
      log.description?.toLowerCase().includes(term) ||
      log.targetResource?.toLowerCase().includes(term)
    );
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <History className="w-5 h-5 text-amber-400" />
            <span>Admin Activity Audit Trail</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Immutable log of all staff actions, balance adjustments, tournament changes, and approvals.
          </p>
        </div>
        <button
          id="btn-refresh-logs"
          onClick={loadData}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#0F1115] hover:bg-zinc-800 border border-[#1E1E24] text-xs font-semibold text-slate-200 transition cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5 text-amber-400" />
          <span>Refresh Logs</span>
        </button>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          id="input-search-logs"
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by admin email, action, resource..."
          className="w-full pl-9 pr-3 py-2 rounded-xl bg-[#0F1115] border border-[#1E1E24] text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
        />
      </div>

      {/* Logs Table */}
      {loading ? (
        <LoadingSpinner text="Retrieving security audit logs..." />
      ) : filteredLogs.length === 0 ? (
        <EmptyState
          icon={History}
          title="No admin activity logs found"
          description="Admin operations such as creating tournaments or verifying payments will be recorded here."
        />
      ) : (
        <div className="rounded-2xl border border-[#1E1E24] bg-[#0F1115] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0A0A0B] border-b border-[#1E1E24] text-slate-400 uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">Admin</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4">Action</th>
                  <th className="py-3 px-4">Resource</th>
                  <th className="py-3 px-4">Description</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E1E24]">
                {filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-[#0A0A0B]/60 transition">
                    <td className="py-3 px-4 text-slate-400 font-mono text-[11px] whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 font-medium text-white whitespace-nowrap">
                      {log.adminEmail}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-amber-500/10 text-amber-400 border border-amber-500/20">
                        {log.adminRole?.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-200">
                      {log.action}
                    </td>
                    <td className="py-3 px-4 text-slate-400 capitalize">
                      {log.targetResource}
                    </td>
                    <td className="py-3 px-4 text-slate-300">
                      {log.description}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
