import React, { useEffect, useState } from 'react';
import {
  Trophy,
  Flame,
  Clock,
  CheckCircle2,
  Wallet,
  User,
  Shield,
  Search,
  Filter,
  Plus,
  ArrowRight,
  ExternalLink,
  ChevronRight,
  LogOut,
  Sparkles,
  Zap,
  Gift,
  Copy,
  AlertCircle,
  QrCode,
  Radio,
  Gamepad2,
  Users,
  Award,
  HelpCircle,
  Send,
  MessageSquare,
  Check,
  CreditCard,
  ArrowDownCircle,
  ArrowUpCircle,
  FileText,
  Upload,
  Image as ImageIcon,
  Smartphone,
  Trash2,
  Eye,
  Info,
  X,
  Calendar,
  MapPin,
  ShieldAlert,
  Crown,
  Tv,
  Video,
  Play,
  Bell,
  Volume2,
  Menu,
  Bot,
  Palette,
  SlidersHorizontal,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import {
  subscribeTournaments,
  subscribeBanners,
  subscribeWebsiteSettings,
  subscribeUserWallet,
  subscribeUserRegistrations,
  subscribeUserWalletTransactions,
  subscribeUserSupportTickets,
  subscribeUserDepositRequests,
  subscribeUserWithdrawalRequests,
  playerJoinTournament,
  playerRequestDeposit,
  playerRequestWithdrawal,
  playerCreateTicket,
  getCoupons,
  submitMatchProof,
  subscribeUserMatchProofs,
  savePlayerSquad,
  subscribePlayerSquads,
  deletePlayerSquad,
  buyVipPass,
  subscribeUserReferrals,
} from '../services/adminService';
import {
  Tournament,
  Banner,
  WebsiteSettings,
  UserWallet,
  Registration,
  WalletTransaction,
  SupportTicket,
  Coupon,
  DepositRequest,
  WithdrawalRequest,
  MatchProof,
  PlayerSquad,
  SquadMember,
  VipSubscription,
  ReferralRecord,
} from '../types';
import { PlayerAuthModal } from '../components/PlayerAuthModal';
import { DepositPaymentModal } from '../components/DepositPaymentModal';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { TournamentTimer } from '../components/TournamentTimer';

const THEME_CONFIG = {
  amber: {
    name: 'Cyber Gold (Amber)',
    badgeBg: 'bg-amber-500/20 text-amber-300 border border-amber-500/30',
    btnBg: 'bg-amber-500 hover:bg-amber-400 text-zinc-950 shadow-lg shadow-amber-500/20',
    textAccent: 'text-amber-400',
    borderAccent: 'border-amber-500/40',
    headerGradient: 'from-amber-600 via-amber-500 to-amber-400',
  },
  emerald: {
    name: 'Esports Emerald',
    badgeBg: 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30',
    btnBg: 'bg-emerald-500 hover:bg-emerald-400 text-zinc-950 shadow-lg shadow-emerald-500/20',
    textAccent: 'text-emerald-400',
    borderAccent: 'border-emerald-500/40',
    headerGradient: 'from-emerald-600 via-emerald-500 to-teal-400',
  },
  cyan: {
    name: 'Cyber Cyan',
    badgeBg: 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30',
    btnBg: 'bg-cyan-500 hover:bg-cyan-400 text-zinc-950 shadow-lg shadow-cyan-500/20',
    textAccent: 'text-cyan-400',
    borderAccent: 'border-cyan-500/40',
    headerGradient: 'from-cyan-600 via-cyan-500 to-blue-400',
  },
  purple: {
    name: 'Royal Violet',
    badgeBg: 'bg-purple-500/20 text-purple-300 border border-purple-500/30',
    btnBg: 'bg-purple-500 hover:bg-purple-400 text-white shadow-lg shadow-purple-500/20',
    textAccent: 'text-purple-400',
    borderAccent: 'border-purple-500/40',
    headerGradient: 'from-purple-600 via-purple-500 to-indigo-400',
  },
  rose: {
    name: 'Flame Rose',
    badgeBg: 'bg-rose-500/20 text-rose-300 border border-rose-500/30',
    btnBg: 'bg-rose-500 hover:bg-rose-400 text-white shadow-lg shadow-rose-500/20',
    textAccent: 'text-rose-400',
    borderAccent: 'border-rose-500/40',
    headerGradient: 'from-rose-600 via-rose-500 to-red-400',
  },
};

interface PlayerTournamentWebsiteProps {
  onOpenAdminPanel: () => void;
}

type PlayerNavTab = 'tournaments' | 'mymatches' | 'wallet' | 'leaderboard' | 'support' | 'profile' | 'squads' | 'proofs' | 'vip' | 'referral';

export const PlayerTournamentWebsite: React.FC<PlayerTournamentWebsiteProps> = ({
  onOpenAdminPanel,
}) => {
  const { currentUser, userProfile, isSuperAdmin, role, logout, updatePlayerProfile } = useAuth();
  const [activeTab, setActiveTab] = useState<PlayerNavTab>('tournaments');
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [websiteSettings, setWebsiteSettings] = useState<WebsiteSettings | null>(null);
  const [wallet, setWallet] = useState<UserWallet | null>(null);
  const [myRegistrations, setMyRegistrations] = useState<Registration[]>([]);
  const [myTransactions, setMyTransactions] = useState<WalletTransaction[]>([]);
  const [myDepositRequests, setMyDepositRequests] = useState<DepositRequest[]>([]);
  const [myWithdrawalRequests, setMyWithdrawalRequests] = useState<WithdrawalRequest[]>([]);
  const [myTickets, setMyTickets] = useState<SupportTicket[]>([]);
  const [mySquads, setMySquads] = useState<PlayerSquad[]>([]);
  const [myProofs, setMyProofs] = useState<MatchProof[]>([]);
  const [myReferralRecords, setMyReferralRecords] = useState<ReferralRecord[]>([]);
  const [copiedReferralCode, setCopiedReferralCode] = useState<boolean>(false);
  const [copiedReferralLink, setCopiedReferralLink] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  // New Features State
  const [selectedSquadForJoin, setSelectedSquadForJoin] = useState<PlayerSquad | null>(null);
  const [isSquadModalOpen, setIsSquadModalOpen] = useState<boolean>(false);
  const [editingSquad, setEditingSquad] = useState<Partial<PlayerSquad>>({
    teamName: '',
    teamTag: '',
    logoUrl: '',
    members: [
      { name: '', ign: '', ffUid: '', role: 'Captain' },
      { name: '', ign: '', ffUid: '', role: 'Assaulter' },
      { name: '', ign: '', ffUid: '', role: 'Sniper' },
      { name: '', ign: '', ffUid: '', role: 'Flanker' },
    ],
  });

  // Proof Upload Form
  const [proofTournament, setProofTournament] = useState<Tournament | null>(null);
  const [proofKills, setProofKills] = useState<number>(0);
  const [proofRank, setProofRank] = useState<number>(1);
  const [proofScreenshot, setProofScreenshot] = useState<string>('');
  const [proofScreenshotName, setProofScreenshotName] = useState<string>('');
  const [proofSubmitting, setProofSubmitting] = useState<boolean>(false);

  // Live Stream & VIP
  const [activeLiveStreamUrl, setActiveLiveStreamUrl] = useState<string | null>(null);
  const [isVipModalOpen, setIsVipModalOpen] = useState<boolean>(false);
  const [buyingVipLoading, setBuyingVipLoading] = useState<boolean>(false);

  // Room Alerts
  const [publishedRoomAlert, setPublishedRoomAlert] = useState<{ tournamentName: string; roomId: string; roomPass: string } | null>(null);

  // Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedType, setSelectedType] = useState<'ALL' | 'SOLO' | 'DUO' | 'SQUAD'>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<'ALL' | 'OPEN' | 'LIVE' | 'COMPLETED'>('ALL');

  // Menu Drawer & AI Chat Spot & Themes State
  const [isMenuDrawerOpen, setIsMenuDrawerOpen] = useState<boolean>(false);
  const [isAIChatOpen, setIsAIChatOpen] = useState<boolean>(false);
  const [currentTheme, setCurrentTheme] = useState<'amber' | 'emerald' | 'cyan' | 'purple' | 'rose'>(
    () => (localStorage.getItem('ff_theme') as any) || 'amber'
  );
  const [aiChatMessages, setAiChatMessages] = useState<
    Array<{ id: string; sender: 'user' | 'bot'; text: string; time: string }>
  >([
    {
      id: 'welcome',
      sender: 'bot',
      text: '👋 Hello Free Fire Warrior! I am FF BOT, your 24/7 AI Tournament Assistant. How can I assist you with your custom room IDs, registration, deposit, or withdrawals today?',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [aiChatInput, setAiChatInput] = useState<string>('');
  const [aiChatLoading, setAiChatLoading] = useState<boolean>(false);

  const handleSetTheme = (themeName: 'amber' | 'emerald' | 'cyan' | 'purple' | 'rose') => {
    setCurrentTheme(themeName);
    localStorage.setItem('ff_theme', themeName);
  };

  const handleSendAIChat = async (customPrompt?: string) => {
    const query = (customPrompt || aiChatInput).trim();
    if (!query || aiChatLoading) return;

    const userMsg = {
      id: Date.now().toString(),
      sender: 'user' as const,
      text: query,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setAiChatMessages((prev) => [...prev, userMsg]);
    if (!customPrompt) setAiChatInput('');
    setAiChatLoading(true);

    try {
      const res = await fetch('/api/ai-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: query }),
      });
      const data = await res.json();

      const botMsg = {
        id: (Date.now() + 1).toString(),
        sender: 'bot' as const,
        text: data.reply || '🎮 How else can I assist your Free Fire tournament journey today?',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setAiChatMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      const botMsg = {
        id: (Date.now() + 1).toString(),
        sender: 'bot' as const,
        text: '🤖 FF Esports AI Support is online. If you need direct human assistance, you can also contact Admin via WhatsApp in the Support tab!',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setAiChatMessages((prev) => [...prev, botMsg]);
    } finally {
      setAiChatLoading(false);
    }
  };

  // Modals & Active Flows
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);
  const [authModalInitialMode, setAuthModalInitialMode] = useState<'login' | 'signup' | 'admin'>('login');
  const [isDepositModalOpen, setIsDepositModalOpen] = useState<boolean>(false);
  const [depositModalInitialAmount, setDepositModalInitialAmount] = useState<number>(100);
  const [previewProofUrl, setPreviewProofUrl] = useState<string | null>(null);
  const [viewingDetailsTournament, setViewingDetailsTournament] = useState<Tournament | null>(null);
  
  // Join Tournament Modal
  const [selectedTournament, setSelectedTournament] = useState<Tournament | null>(null);
  const [joinTeamName, setJoinTeamName] = useState<string>('');
  const [joinPlayers, setJoinPlayers] = useState<
    { name: string; ign: string; ffUid: string }[]
  >([{ name: '', ign: '', ffUid: '' }]);
  const [couponCodeInput, setCouponCodeInput] = useState<string>('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [joinError, setJoinError] = useState<string>('');
  const [joinSuccess, setJoinSuccess] = useState<string>('');
  const [joining, setJoining] = useState<boolean>(false);

  // Wallet Deposit Modal / Form
  const [depositAmount, setDepositAmount] = useState<number>(100);
  const [depositUtr, setDepositUtr] = useState<string>('');
  const [depositScreenshot, setDepositScreenshot] = useState<string>('');
  const [depositScreenshotFileName, setDepositScreenshotFileName] = useState<string>('');
  const [depositLoading, setDepositLoading] = useState<boolean>(false);
  const [depositMessage, setDepositMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [copiedUpi, setCopiedUpi] = useState<boolean>(false);

  // Wallet Withdrawal Modal / Form
  const [withdrawAmount, setWithdrawAmount] = useState<number>(100);
  const [withdrawMethod, setWithdrawMethod] = useState<'UPI' | 'BANK' | 'PAYTM' | 'GPAY' | 'PHONEPE' | 'REDEEM_CODE'>('UPI');
  const [withdrawUpiId, setWithdrawUpiId] = useState<string>('');
  const [withdrawPhone, setWithdrawPhone] = useState<string>('');
  const [withdrawBankAcc, setWithdrawBankAcc] = useState<string>('');
  const [withdrawIfsc, setWithdrawIfsc] = useState<string>('');
  const [withdrawHolder, setWithdrawHolder] = useState<string>('');
  const [withdrawLoading, setWithdrawLoading] = useState<boolean>(false);
  const [withdrawMessage, setWithdrawMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Support Ticket Form
  const [ticketSubject, setTicketSubject] = useState<string>('');
  const [ticketCategory, setTicketCategory] = useState<'Payment' | 'Tournament' | 'Room' | 'Result' | 'Account' | 'Other'>('Payment');
  const [ticketMessage, setTicketMessage] = useState<string>('');
  const [ticketLoading, setTicketLoading] = useState<boolean>(false);
  const [ticketSuccess, setTicketSuccess] = useState<string>('');

  // Profile Edit State
  const [editIgn, setEditIgn] = useState<string>('');
  const [editFfUid, setEditFfUid] = useState<string>('');
  const [editPhone, setEditPhone] = useState<string>('');
  const [profileSaving, setProfileSaving] = useState<boolean>(false);

  // 1. Subscribe to Tournaments, Banners & Website Settings (Public Firestore Listeners)
  useEffect(() => {
    const unsubTourneys = subscribeTournaments((data) => {
      setTournaments(data);
      setLoading(false);
    });

    const unsubBanners = subscribeBanners((data) => {
      setBanners(data);
    });

    const unsubSettings = subscribeWebsiteSettings((st) => {
      setWebsiteSettings(st);
    });

    return () => {
      unsubTourneys();
      unsubBanners();
      unsubSettings();
    };
  }, []);

  // 2. Subscribe to Player's User Data (Wallet, Registrations, Transactions, Tickets, Squads, Proofs)
  useEffect(() => {
    if (!currentUser) {
      setWallet(null);
      setMyRegistrations([]);
      setMyTransactions([]);
      setMyTickets([]);
      setMySquads([]);
      setMyProofs([]);
      setMyReferralRecords([]);
      return;
    }

    const unsubWallet = subscribeUserWallet(currentUser.uid, (w) => setWallet(w));
    const unsubRegs = subscribeUserRegistrations(currentUser.uid, (r) => {
      setMyRegistrations(r);
      // Room publish sound & alert check
      tournaments.forEach((t) => {
        const isJoined = r.some((reg) => reg.tournamentId === t.id && reg.status === 'Approved');
        if (isJoined && t.status === 'Live') {
          // Check match room ID
        }
      });
    });
    const unsubTxs = subscribeUserWalletTransactions(currentUser.uid, (tx) => setMyTransactions(tx));
    const unsubTickets = subscribeUserSupportTickets(currentUser.uid, (tk) => setMyTickets(tk));
    const unsubDeposits = subscribeUserDepositRequests(currentUser.uid, (deps) => setMyDepositRequests(deps));
    const unsubWithdrawals = subscribeUserWithdrawalRequests(currentUser.uid, (w) => setMyWithdrawalRequests(w));
    const unsubSquads = subscribePlayerSquads(currentUser.uid, (sqs) => setMySquads(sqs));
    const unsubProofs = subscribeUserMatchProofs(currentUser.uid, (pfs) => setMyProofs(pfs));
    const unsubRefs = subscribeUserReferrals(currentUser.uid, (refs) => setMyReferralRecords(refs));

    return () => {
      unsubWallet();
      unsubRegs();
      unsubTxs();
      unsubTickets();
      unsubDeposits();
      unsubWithdrawals();
      unsubSquads();
      unsubProofs();
      unsubRefs();
    };
  }, [currentUser, tournaments]);

  // Sync profile edits
  useEffect(() => {
    if (userProfile) {
      setEditIgn(userProfile.ign || '');
      setEditFfUid(userProfile.ffUid || '');
      setEditPhone(userProfile.phone || '');
    }
  }, [userProfile]);

  // Setup Join Modal when tournament selected
  const handleOpenJoinModal = (tourney: Tournament) => {
    if (!currentUser) {
      setAuthModalInitialMode('login');
      setAuthModalOpen(true);
      return;
    }

    // Check if user is already registered for this tournament
    const isAlreadyJoined = myRegistrations.some(
      (reg) => reg.tournamentId === tourney.id && reg.status !== 'Rejected'
    );
    if (isAlreadyJoined) {
      alert('Aapne is tournament me pehle se hi join kar liya hai! "My Matches" tab me Room ID dekhein.');
      setActiveTab('mymatches');
      return;
    }

    // Check if slots are filled
    if ((tourney.currentRegistrations || 0) >= (tourney.maxTeams || 48)) {
      alert('Is tournament ke saare slots bhar chuke hain! (Slots Full)');
      return;
    }

    setSelectedTournament(tourney);
    setJoinTeamName(userProfile?.ign ? `${userProfile.ign}'s Team` : 'Alpha Squad');
    setJoinError('');
    setJoinSuccess('');
    setAppliedCoupon(null);
    setCouponCodeInput('');

    // Pre-populate players according to tournament type
    const tType = (tourney.type || '').toLowerCase();
    const count = tType === 'solo' ? 1 : tType === 'duo' ? 2 : 4;
    const initialPlayers = [];
    for (let i = 0; i < count; i++) {
      if (i === 0) {
        initialPlayers.push({
          name: userProfile?.name || 'Leader',
          ign: userProfile?.ign || '',
          ffUid: userProfile?.ffUid || '',
        });
      } else {
        initialPlayers.push({ name: '', ign: '', ffUid: '' });
      }
    }
    setJoinPlayers(initialPlayers);
  };

  const handleApplyCoupon = async () => {
    if (!couponCodeInput.trim() || !selectedTournament) return;
    try {
      const coupons = await getCoupons();
      const match = coupons.find((c) => {
        if (c.code.toUpperCase() !== couponCodeInput.trim().toUpperCase()) return false;
        if (c.status === 'Inactive' || c.status === 'Expired') return false;
        if (c.expiryDate) {
          const expTime = isNaN(Number(c.expiryDate)) ? new Date(c.expiryDate).getTime() : Number(c.expiryDate);
          if (expTime && expTime < Date.now()) return false;
        }
        return true;
      });
      if (!match) {
        setJoinError('Invalid or expired promo coupon code');
        setAppliedCoupon(null);
        return;
      }
      setAppliedCoupon(match);
      setJoinError('');
    } catch (e) {
      setJoinError('Could not verify coupon code');
    }
  };

  const handleConfirmJoin = async () => {
    if (!selectedTournament || !currentUser) return;
    setJoining(true);
    setJoinError('');
    setJoinSuccess('');

    try {
      // Validate inputs
      if (!joinTeamName.trim()) {
        throw new Error('Please enter a Team / Squad name');
      }

      for (let i = 0; i < joinPlayers.length; i++) {
        const p = joinPlayers[i];
        if (!p.ign.trim() || !p.ffUid.trim()) {
          throw new Error(`Please fill IGN and FF UID for Player #${i + 1}`);
        }
      }

      let discount = 0;
      if (appliedCoupon) {
        if (appliedCoupon.discountType === 'PERCENTAGE') {
          discount = (selectedTournament.entryFee * (appliedCoupon.discountValue || appliedCoupon.discountAmount || 0)) / 100;
        } else {
          discount = appliedCoupon.discountValue || appliedCoupon.discountAmount || 0;
        }
      }

      // 👑 Auto VIP Esports Pass 10% Discount
      if (userProfile?.isVip) {
        const vipDiscount = (selectedTournament.entryFee * 10) / 100;
        discount += vipDiscount;
      }

      await playerJoinTournament({
        tournamentId: selectedTournament.id,
        tournamentName: selectedTournament.name,
        userId: currentUser.uid,
        userEmail: currentUser.email || '',
        teamName: joinTeamName.trim(),
        players: joinPlayers,
        entryFee: selectedTournament.entryFee,
        discountAmount: discount,
        couponCode: (appliedCoupon?.code ? appliedCoupon.code + ' ' : '') + (userProfile?.isVip ? '👑 VIP10%' : ''),
      });

      setJoinSuccess('🎉 Registration Successful! Check "My Matches" for room details.');
      setTimeout(() => {
        setSelectedTournament(null);
        setActiveTab('mymatches');
      }, 1500);
    } catch (err: any) {
      console.error('Join tournament error:', err);
      setJoinError(err.message || 'Failed to join tournament.');
    } finally {
      setJoining(false);
    }
  };

  // Squad Handlers
  const handleSaveSquad = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!editingSquad.teamName?.trim()) {
      alert('Please enter Team Name');
      return;
    }
    try {
      await savePlayerSquad({
        id: editingSquad.id,
        ownerUserId: currentUser.uid,
        teamName: editingSquad.teamName.trim(),
        teamTag: editingSquad.teamTag || '',
        logoUrl: editingSquad.logoUrl || '',
        members: editingSquad.members || [],
      });
      alert('Squad saved successfully!');
      setIsSquadModalOpen(false);
    } catch (e: any) {
      alert(e.message || 'Failed to save squad');
    }
  };

  const handleDeleteSquad = async (squadId: string) => {
    if (!confirm('Are you sure you want to delete this squad?')) return;
    try {
      await deletePlayerSquad(squadId);
    } catch (e: any) {
      alert('Failed to delete squad');
    }
  };

  const handleSelectSquadForJoin = (sq: PlayerSquad) => {
    setSelectedSquadForJoin(sq);
    setJoinTeamName(sq.teamName);
    if (sq.members && sq.members.length > 0) {
      setJoinPlayers(
        sq.members.map((m) => ({
          name: m.name || m.ign || 'Player',
          ign: m.ign || '',
          ffUid: m.ffUid || '',
        }))
      );
    }
  };

  // Proof Upload Handlers
  const handleProofScreenshotUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      alert('File size must be under 5MB');
      return;
    }
    setProofScreenshotName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      setProofScreenshot(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmitProof = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !proofTournament) {
      alert('Please select a tournament');
      return;
    }
    if (!proofScreenshot) {
      alert('Please upload a screenshot of your match result');
      return;
    }
    setProofSubmitting(true);
    try {
      await submitMatchProof({
        tournamentId: proofTournament.id,
        tournamentName: proofTournament.name,
        userId: currentUser.uid,
        userEmail: currentUser.email || '',
        userName: userProfile?.name || 'Player',
        teamName: joinTeamName || userProfile?.name || 'My Team',
        claimedKills: Number(proofKills),
        claimedRank: Number(proofRank),
        screenshotUrl: proofScreenshot,
      });
      alert('🎉 Match Proof & Kills submitted successfully! Admin will verify and update standings.');
      setProofScreenshot('');
      setProofScreenshotName('');
      setProofKills(0);
      setProofRank(1);
    } catch (e: any) {
      alert(e.message || 'Failed to submit proof');
    } finally {
      setProofSubmitting(false);
    }
  };

  // VIP Pass Purchase Handler
  const handleBuyVip = async (plan: 'WEEKLY' | 'MONTHLY') => {
    if (!currentUser) {
      setAuthModalInitialMode('login');
      setAuthModalOpen(true);
      return;
    }
    setBuyingVipLoading(true);
    try {
      await buyVipPass(
        currentUser.uid,
        currentUser.email || '',
        userProfile?.name || 'Player',
        plan
      );
      alert('🎉 Congratulations! 👑 VIP Esports Pass is now active on your account!');
      setIsVipModalOpen(false);
    } catch (e: any) {
      alert(e.message || 'Failed to purchase VIP Pass');
    } finally {
      setBuyingVipLoading(false);
    }
  };

  const handleInPageScreenshotUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setDepositMessage({ type: 'error', text: 'Please select a valid image file (PNG, JPG, WEBP).' });
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setDepositMessage({ type: 'error', text: 'Screenshot file size must be less than 5MB.' });
      return;
    }

    setDepositScreenshotFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      setDepositScreenshot(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setAuthModalInitialMode('login');
      setAuthModalOpen(true);
      return;
    }
    setDepositLoading(true);
    setDepositMessage(null);

    try {
      await playerRequestDeposit({
        userId: currentUser.uid,
        userEmail: currentUser.email || '',
        userName: userProfile?.name || currentUser.displayName || 'Player',
        amount: Number(depositAmount),
        utrNumber: depositUtr.trim(),
        screenshotUrl: depositScreenshot.trim(),
      });

      setDepositMessage({
        type: 'success',
        text: 'Deposit request sent to Admin Panel! Admin will verify and credit ₹' + depositAmount + ' to your wallet.',
      });
      setDepositUtr('');
      setDepositScreenshot('');
      setDepositScreenshotFileName('');
    } catch (err: any) {
      setDepositMessage({
        type: 'error',
        text: err.message || 'Deposit submission failed',
      });
    } finally {
      setDepositLoading(false);
    }
  };

  const handleWithdrawalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setWithdrawLoading(true);
    setWithdrawMessage(null);

    try {
      const minAmt = withdrawMethod === 'REDEEM_CODE' ? 10 : 50;
      if (withdrawAmount < minAmt) {
        throw new Error(`Minimum ${withdrawMethod === 'REDEEM_CODE' ? 'Google Play Redeem Code' : 'withdrawal'} amount is ₹${minAmt}`);
      }

      if ((wallet?.availableBalance || 0) < withdrawAmount) {
        throw new Error(`Insufficient wallet balance. Available: ₹${wallet?.availableBalance || 0}`);
      }

      await playerRequestWithdrawal({
        userId: currentUser.uid,
        userEmail: currentUser.email || '',
        userName: userProfile?.name || 'Player',
        phone: withdrawPhone || userProfile?.phone || '',
        requestedAmount: Number(withdrawAmount),
        payoutMethod: withdrawMethod,
        payoutDetails: {
          upiId: withdrawUpiId,
          accountNumber: withdrawBankAcc,
          ifscCode: withdrawIfsc,
          holderName: withdrawHolder,
          mobileNumber: withdrawPhone || userProfile?.phone || '',
          redeemCodeAmount: withdrawAmount,
        },
      });

      setWithdrawMessage({
        type: 'success',
        text: withdrawMethod === 'REDEEM_CODE'
          ? `Google Play Redeem Code request for ₹${withdrawAmount} submitted! Admin will send code to your WhatsApp/Mobile and display it in your history.`
          : 'Withdrawal request submitted! Payout will be processed to your account.',
      });
      setWithdrawUpiId('');
      setWithdrawBankAcc('');
    } catch (err: any) {
      setWithdrawMessage({
        type: 'error',
        text: err.message || 'Withdrawal submission failed',
      });
    } finally {
      setWithdrawLoading(false);
    }
  };

  const handleTicketSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setTicketLoading(true);
    setTicketSuccess('');

    try {
      await playerCreateTicket({
        userId: currentUser.uid,
        userEmail: currentUser.email || '',
        userName: userProfile?.name || 'Player',
        subject: ticketSubject.trim(),
        category: ticketCategory,
        message: ticketMessage.trim(),
      });

      setTicketSuccess('Support ticket submitted! Support team will review shortly.');
      setTicketSubject('');
      setTicketMessage('');
    } catch (err: any) {
      alert(err.message || 'Failed to submit ticket');
    } finally {
      setTicketLoading(false);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSaving(true);
    try {
      await updatePlayerProfile({
        ign: editIgn.trim(),
        ffUid: editFfUid.trim(),
        phone: editPhone.trim(),
      });
      alert('Profile updated successfully!');
    } catch (e: any) {
      alert(e.message || 'Failed to update profile');
    } finally {
      setProfileSaving(false);
    }
  };

  // Filtered tournaments list
  const filteredTournaments = tournaments.filter((t) => {
    const matchesSearch =
      t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.map.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesType =
      selectedType === 'ALL' || t.type.toUpperCase() === selectedType;

    const matchesStatus =
      selectedStatus === 'ALL' ||
      (selectedStatus === 'OPEN' && t.status === 'Registration Open') ||
      (selectedStatus === 'LIVE' && t.status === 'Live') ||
      (selectedStatus === 'COMPLETED' && t.status === 'Completed');

    return matchesSearch && matchesType && matchesStatus;
  });

  return (
    <div className="min-h-screen w-full bg-[#0A0A0B] text-zinc-100 flex flex-col selection:bg-amber-500 selection:text-black">
      {/* 1. TOP HEADER / NAVBAR */}
      <header className="sticky top-0 z-40 bg-[#0A0A0B]/90 backdrop-blur-xl border-b border-zinc-800/80 px-4 sm:px-8 py-3.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('tournaments')}>
            <div className={`w-10 h-10 rounded-2xl bg-gradient-to-tr ${THEME_CONFIG[currentTheme].headerGradient} p-0.5 shadow-lg flex items-center justify-center`}>
              <div className="w-full h-full bg-zinc-950 rounded-[14px] flex items-center justify-center">
                <Gamepad2 className={`w-5 h-5 ${THEME_CONFIG[currentTheme].textAccent}`} />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-lg text-white font-mono tracking-tight">
                  FF TOURNAMENT
                </span>
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${THEME_CONFIG[currentTheme].badgeBg}`}>
                  ESPORTS
                </span>
              </div>
              <p className="text-[10px] text-zinc-400 hidden sm:block">Play Free Fire & Win Real Cash Prizes</p>
            </div>
          </div>

          {/* Desktop Navigation Links: Only Tournaments & Profile on Home Header as requested */}
          <nav className="hidden md:flex items-center gap-2 bg-zinc-900/80 p-1.5 rounded-2xl border border-zinc-800">
            <button
              onClick={() => setActiveTab('tournaments')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'tournaments'
                  ? `${THEME_CONFIG[currentTheme].btnBg}`
                  : 'text-zinc-300 hover:text-white'
              }`}
            >
              <Trophy className="w-3.5 h-3.5" />
              <span>Tournaments</span>
            </button>
            <button
              onClick={() => setActiveTab('profile')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'profile'
                  ? `${THEME_CONFIG[currentTheme].btnBg}`
                  : 'text-zinc-300 hover:text-white'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>Profile</span>
            </button>

            {/* AI Chat Support Spot Button */}
            <button
              onClick={() => setIsAIChatOpen(true)}
              className="px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 bg-gradient-to-r from-cyan-500/20 to-indigo-500/20 text-cyan-300 border border-cyan-500/30 hover:border-cyan-400 shadow-sm"
            >
              <Bot className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span>AI Chat Spot</span>
              <span className="px-1.5 py-0.2 text-[9px] font-extrabold rounded bg-cyan-400 text-black uppercase">NEW</span>
            </button>

            {/* Menu Options Drawer Trigger (Contains all other options & Themes) */}
            <button
              onClick={() => setIsMenuDrawerOpen(true)}
              className="px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 bg-zinc-800/90 text-amber-300 hover:bg-zinc-700 hover:text-white border border-amber-500/30"
            >
              <Menu className="w-4 h-4 text-amber-400" />
              <span>Menu Options</span>
            </button>
          </nav>

          {/* Right Action Area */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* 🌐 ADMIN ACCESS BUTTON (Requested explicitly by user) */}
            <button
              id="btn-admin-portal-globe"
              onClick={() => {
                if (isSuperAdmin || role === 'SUPER_ADMIN' || role === 'TOURNAMENT_ADMIN') {
                  onOpenAdminPanel();
                } else {
                  setAuthModalInitialMode('admin');
                  setAuthModalOpen(true);
                }
              }}
              title="Open Admin Control Portal"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-amber-500/20 border border-zinc-700 hover:border-amber-500/40 text-xs font-bold text-amber-300 transition cursor-pointer active:scale-95 shadow-sm"
            >
              <span className="text-base">🌐</span>
              <span className="hidden sm:inline">Admin Panel</span>
            </button>

            {/* If logged in */}
            {currentUser ? (
              <div className="flex items-center gap-2">
                {/* Wallet Balance Pill */}
                <button
                  id="btn-navbar-wallet-pill"
                  onClick={() => setActiveTab('wallet')}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20 transition cursor-pointer"
                >
                  <Wallet className="w-3.5 h-3.5" />
                  <span className="text-xs font-mono font-bold">
                    ₹{wallet?.availableBalance ?? 0}
                  </span>
                </button>

                {/* Profile Pill */}
                <div className="relative group">
                  <button
                    onClick={() => setActiveTab('profile')}
                    className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 transition cursor-pointer"
                  >
                    <div className="w-6 h-6 rounded-lg bg-amber-500 text-zinc-950 font-black text-xs flex items-center justify-center">
                      {(userProfile?.ign || currentUser.email || 'P')[0].toUpperCase()}
                    </div>
                    <span className="text-xs font-bold text-zinc-200 hidden md:inline truncate max-w-[100px]">
                      {userProfile?.ign || currentUser.email?.split('@')[0]}
                    </span>
                  </button>
                </div>

                <button
                  onClick={() => logout()}
                  title="Sign Out"
                  className="p-2 rounded-xl text-zinc-400 hover:text-rose-400 hover:bg-zinc-900 border border-zinc-800 transition cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  id="btn-header-login"
                  onClick={() => {
                    setAuthModalInitialMode('login');
                    setAuthModalOpen(true);
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 text-xs font-bold border border-zinc-700 transition cursor-pointer"
                >
                  Sign In
                </button>
                <button
                  id="btn-header-join-free"
                  onClick={() => {
                    setAuthModalInitialMode('signup');
                    setAuthModalOpen(true);
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold transition shadow-lg shadow-amber-500/20 cursor-pointer"
                >
                  Join Free
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Mobile Navigation Bar */}
        <div className="md:hidden flex items-center justify-between gap-1.5 mt-3 pt-2.5 border-t border-zinc-800/80">
          <button
            onClick={() => setActiveTab('tournaments')}
            className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold text-center transition flex items-center justify-center gap-1 ${
              activeTab === 'tournaments' ? `${THEME_CONFIG[currentTheme].btnBg}` : 'bg-zinc-900 text-zinc-300 border border-zinc-800'
            }`}
          >
            <Trophy className="w-3.5 h-3.5" />
            <span>Tournaments</span>
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold text-center transition flex items-center justify-center gap-1 ${
              activeTab === 'profile' ? `${THEME_CONFIG[currentTheme].btnBg}` : 'bg-zinc-900 text-zinc-300 border border-zinc-800'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Profile</span>
          </button>
          <button
            onClick={() => setIsAIChatOpen(true)}
            className="py-2 px-2.5 rounded-xl text-xs font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 flex items-center justify-center gap-1 shrink-0"
          >
            <Bot className="w-3.5 h-3.5 text-cyan-400" />
            <span>AI Chat</span>
          </button>
          <button
            onClick={() => setIsMenuDrawerOpen(true)}
            className="py-2 px-3 rounded-xl text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center gap-1 shrink-0"
          >
            <Menu className="w-4 h-4 text-amber-400" />
            <span>Menu</span>
          </button>
        </div>
      </header>

      {/* 2. MAIN CONTENT VIEW */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-8">
        {/* ========================================================================= */}
        {/* TAB 1: TOURNAMENTS EXPLORER */}
        {/* ========================================================================= */}
        {activeTab === 'tournaments' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            {/* Hero Section / Banner */}
            <div className="relative rounded-3xl overflow-hidden border border-zinc-800 bg-gradient-to-r from-amber-950/40 via-zinc-900 to-zinc-950 p-6 sm:p-10 shadow-2xl">
              <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
              <div className="relative z-10 max-w-2xl space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-bold">
                  <Flame className="w-4 h-4 text-amber-400 animate-pulse" />
                  <span>DAILY FREE FIRE ESPORTS TOURNAMENTS</span>
                </div>
                <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight font-mono leading-none">
                  COMPETE. DOMINATE. <br />
                  <span className="text-amber-400">WIN REAL CASH.</span>
                </h1>
                <p className="text-sm text-zinc-300 leading-relaxed">
                  Join verified Solo, Duo & Squad Free Fire matches. Instant UPI withdrawals, automated slot booking, real-time room credentials, and fair anti-cheat play.
                </p>
                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button
                    onClick={() => {
                      const el = document.getElementById('tournaments-grid');
                      el?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="px-6 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs transition shadow-lg shadow-amber-500/25 flex items-center gap-2 cursor-pointer"
                  >
                    <span>Browse Matches</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setActiveTab('wallet')}
                    className="px-6 py-3 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white font-bold text-xs transition cursor-pointer flex items-center gap-2"
                  >
                    <Wallet className="w-4 h-4 text-emerald-400" />
                    <span>Deposit / Wallet</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Filter and Search Bar */}
            <div id="tournaments-grid" className="space-y-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-black text-white tracking-tight flex items-center gap-2">
                    <Trophy className="w-5 h-5 text-amber-400" />
                    <span>Live & Upcoming Tournaments</span>
                  </h2>
                  <p className="text-xs text-zinc-400">
                    Real-time slot telemetry synced with Firebase Firestore.
                  </p>
                </div>

                {/* Filters */}
                <div className="flex flex-wrap items-center gap-2">
                  {/* Match Type Pills */}
                  <div className="flex items-center gap-1 bg-zinc-900 p-1 rounded-xl border border-zinc-800 text-xs">
                    {(['ALL', 'SOLO', 'DUO', 'SQUAD'] as const).map((type) => (
                      <button
                        key={type}
                        onClick={() => setSelectedType(type)}
                        className={`px-3 py-1 rounded-lg font-bold transition cursor-pointer ${
                          selectedType === type
                            ? 'bg-amber-500 text-zinc-950'
                            : 'text-zinc-400 hover:text-white'
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>

                  {/* Status Pills */}
                  <div className="flex items-center gap-1 bg-zinc-900 p-1 rounded-xl border border-zinc-800 text-xs">
                    {(['ALL', 'OPEN', 'LIVE', 'COMPLETED'] as const).map((status) => (
                      <button
                        key={status}
                        onClick={() => setSelectedStatus(status)}
                        className={`px-3 py-1 rounded-lg font-bold transition cursor-pointer ${
                          selectedStatus === status
                            ? 'bg-amber-500 text-zinc-950'
                            : 'text-zinc-400 hover:text-white'
                        }`}
                      >
                        {status}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Tournament Grid */}
              {loading ? (
                <LoadingSpinner text="Retrieving real Firestore tournaments..." />
              ) : filteredTournaments.length === 0 ? (
                <div className="text-center py-16 border border-dashed border-zinc-800 rounded-3xl bg-zinc-950">
                  <Trophy className="w-12 h-12 text-zinc-600 mx-auto mb-3" />
                  <h3 className="text-base font-bold text-white">No Tournaments Available</h3>
                  <p className="text-xs text-zinc-400 mt-1 max-w-sm mx-auto">
                    There are no tournaments currently published under this filter. Check back shortly or switch filters.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredTournaments.map((t) => {
                    const spotsLeft = Math.max(0, (t.maxTeams || 48) - (t.currentRegistrations || 0));
                    const isFull = spotsLeft === 0;
                    const percentFilled = Math.min(100, Math.round(((t.currentRegistrations || 0) / (t.maxTeams || 48)) * 100));
                    const isAlreadyJoined = myRegistrations.some(
                      (reg) => reg.tournamentId === t.id && reg.status !== 'Rejected' && reg.status !== 'Cancelled'
                    );

                    return (
                      <div
                        key={t.id}
                        className="rounded-3xl border border-zinc-800 bg-[#0F1115] overflow-hidden hover:border-amber-500/40 transition duration-200 flex flex-col justify-between shadow-xl group"
                      >
                        {/* Card Header & Banner */}
                        <div className="p-5 space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-black px-2.5 py-1 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20 uppercase tracking-widest font-mono">
                              {t.type} • {t.map || 'Bermuda'}
                            </span>
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                                t.status === 'Registration Open'
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                  : t.status === 'Live'
                                  ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30 animate-pulse'
                                  : 'bg-zinc-800 text-zinc-400'
                              }`}
                            >
                              {t.status}
                            </span>
                          </div>

                          <h3
                            onClick={() => setViewingDetailsTournament(t)}
                            className="text-base font-black text-white group-hover:text-amber-400 transition leading-snug line-clamp-2 cursor-pointer hover:underline"
                            title="Click to view full tournament details"
                          >
                            {t.name}
                          </h3>

                          {/* Key Meta */}
                          <div className="grid grid-cols-3 gap-2 p-3 rounded-2xl bg-zinc-950 border border-zinc-800/80 text-center">
                            <div>
                              <p className="text-[10px] uppercase font-semibold text-zinc-500">Prize Pool</p>
                              <p className="text-sm font-black text-amber-400 font-mono">₹{t.prizePool}</p>
                            </div>
                            <div className="border-x border-zinc-800">
                              <p className="text-[10px] uppercase font-semibold text-zinc-500">Per Kill</p>
                              <p className="text-sm font-black text-emerald-400 font-mono">₹{t.perKillPrize || 0}</p>
                            </div>
                            <div>
                              <p className="text-[10px] uppercase font-semibold text-zinc-500">Entry Fee</p>
                              <p className="text-sm font-black text-white font-mono">
                                {t.entryFee === 0 ? 'FREE' : `₹${t.entryFee}`}
                              </p>
                            </div>
                          </div>

                          {/* Slots Progress Bar */}
                          <div className="space-y-1.5">
                            <div className="flex items-center justify-between text-[11px]">
                              <span className="text-zinc-400">
                                Slots: <b className="text-white">{t.currentRegistrations || 0}</b> / {t.maxTeams || 48}
                              </span>
                              <span className={spotsLeft <= 5 ? 'text-rose-400 font-bold' : 'text-amber-400 font-bold'}>
                                {spotsLeft > 0 ? `${spotsLeft} Spots Left` : 'Filled'}
                              </span>
                            </div>
                            <div className="w-full h-2 bg-zinc-950 rounded-full overflow-hidden border border-zinc-800">
                              <div
                                className="h-full bg-gradient-to-r from-amber-500 to-amber-400 rounded-full transition-all duration-300"
                                style={{ width: `${percentFilled}%` }}
                              />
                            </div>
                          </div>

                          {/* Live Countdown Timer */}
                          <TournamentTimer tournament={t} variant="card" themeColor={currentTheme} />

                          {/* Schedule Date & Time info */}
                          <div className="flex items-center justify-between text-[11px] text-zinc-400 pt-0.5 px-1 font-mono">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3 text-zinc-500" />
                              <span>{t.date || 'Today'}</span>
                            </span>
                            <span className="flex items-center gap-1 font-bold text-amber-400">
                              <Clock className="w-3 h-3 text-amber-500" />
                              <span>Match Time: {t.time || '18:00'}</span>
                            </span>
                          </div>
                        </div>

                        {/* Card Footer Buttons */}
                        <div className="p-4 bg-zinc-950/60 border-t border-zinc-800/80 flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setViewingDetailsTournament(t)}
                            className="py-2.5 px-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                            title="View Tournament Rules & Prize Details"
                          >
                            <Info className="w-4 h-4 text-amber-400" />
                            <span>Details</span>
                          </button>

                          {t.status === 'Registration Open' ? (
                            isAlreadyJoined ? (
                              <button
                                onClick={() => setActiveTab('mymatches')}
                                className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 font-bold text-xs hover:bg-emerald-500/25 transition flex items-center justify-center gap-1.5 cursor-pointer"
                              >
                                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                                <span>Joined ✅</span>
                              </button>
                            ) : isFull ? (
                              <button
                                disabled
                                className="flex-1 py-2.5 px-3 rounded-xl bg-zinc-800 text-zinc-500 font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-not-allowed"
                              >
                                <span>Slots Full</span>
                              </button>
                            ) : (
                              <button
                                id={`btn-join-tourney-${t.id}`}
                                onClick={() => handleOpenJoinModal(t)}
                                className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer ${THEME_CONFIG[currentTheme].btnBg} active:scale-98`}
                              >
                                <span>Join</span>
                                <ArrowRight className="w-3.5 h-3.5" />
                              </button>
                            )
                          ) : t.status === 'Live' ? (
                            <button
                              onClick={() => setActiveTab('mymatches')}
                              className="flex-1 py-2.5 px-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 font-bold text-xs hover:bg-rose-500/20 transition flex items-center justify-center gap-1.5 cursor-pointer"
                            >
                              <Radio className="w-3.5 h-3.5 animate-pulse" />
                              <span>Live Room</span>
                            </button>
                          ) : (
                            <button
                              onClick={() => setActiveTab('leaderboard')}
                              className="flex-1 py-2.5 px-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 font-bold text-xs hover:text-white transition flex items-center justify-center gap-1.5 cursor-pointer"
                            >
                              <span>Results</span>
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 2: MY MATCHES & ROOM CREDENTIALS */}
        {/* ========================================================================= */}
        {activeTab === 'mymatches' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div>
              <h2 className="text-xl font-black text-white tracking-tight flex items-center gap-2">
                <Gamepad2 className="w-5 h-5 text-amber-400" />
                <span>My Registered Matches & Room Details</span>
              </h2>
              <p className="text-xs text-zinc-400">
                View room ID and password published by admins before match starts.
              </p>
            </div>

            {!currentUser ? (
              <div className="p-8 rounded-3xl bg-zinc-900/60 border border-zinc-800 text-center space-y-3">
                <Shield className="w-10 h-10 text-amber-400 mx-auto" />
                <h3 className="text-base font-bold text-white">Please Sign In</h3>
                <p className="text-xs text-zinc-400 max-w-sm mx-auto">
                  Sign in with Google or your Player account to view your joined tournaments and room passwords.
                </p>
                <button
                  onClick={() => {
                    setAuthModalInitialMode('login');
                    setAuthModalOpen(true);
                  }}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition cursor-pointer"
                >
                  Sign In Now
                </button>
              </div>
            ) : myRegistrations.length === 0 ? (
              <div className="text-center py-16 border border-dashed border-zinc-800 rounded-3xl bg-zinc-950">
                <Gamepad2 className="w-12 h-12 text-zinc-600 mx-auto mb-3" />
                <h3 className="text-base font-bold text-white">No Registered Tournaments</h3>
                <p className="text-xs text-zinc-400 mt-1 max-w-sm mx-auto">
                  You have not joined any upcoming Free Fire matches yet.
                </p>
                <button
                  onClick={() => setActiveTab('tournaments')}
                  className="mt-4 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition cursor-pointer"
                >
                  Browse Available Matches
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {myRegistrations.map((reg) => {
                  const tourney = tournaments.find((t) => t.id === reg.tournamentId);

                  return (
                    <div
                      key={reg.id}
                      className="p-6 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-4"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="text-lg font-black text-white">{reg.tournamentName}</h3>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                              {reg.status}
                            </span>
                          </div>
                          <p className="text-xs text-zinc-400 mt-0.5">
                            Team: <b className="text-amber-400">{reg.teamName}</b> • Slot #{reg.slotNumber || 1} • Paid: ₹{reg.paidAmount}
                          </p>
                        </div>

                        <span className="text-xs font-mono text-zinc-500">
                          Joined: {new Date(reg.createdAt).toLocaleDateString()}
                        </span>
                      </div>

                      {/* ROOM CREDENTIALS CARD (Real-time admin published) */}
                      <div className="p-4 rounded-2xl bg-zinc-950 border border-amber-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <Shield className="w-4 h-4 text-amber-400" />
                            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-300">
                              Free Fire Custom Room Credentials
                            </h4>
                          </div>
                          <p className="text-[11px] text-zinc-400">
                            Room details will appear here 15 minutes before the match start time.
                          </p>
                        </div>

                        <div className="flex items-center gap-3">
                          <div className="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-center min-w-[110px]">
                            <p className="text-[10px] uppercase font-semibold text-zinc-500">Room ID</p>
                            <p className="text-xs font-mono font-black text-white">
                              {tourney?.roomId || 'Pending'}
                            </p>
                          </div>
                          <div className="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-center min-w-[110px]">
                            <p className="text-[10px] uppercase font-semibold text-zinc-500">Password</p>
                            <p className="text-xs font-mono font-black text-amber-400">
                              {tourney?.roomPassword || 'Pending'}
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Roster list */}
                      <div>
                        <p className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-2">
                          Registered Squad Roster
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
                          {reg.players.map((p, idx) => (
                            <div
                              key={idx}
                              className="p-2.5 rounded-xl bg-zinc-950 border border-zinc-800/80 flex items-center gap-2"
                            >
                              <div className="w-6 h-6 rounded-lg bg-zinc-900 text-amber-400 font-bold text-xs flex items-center justify-center shrink-0">
                                #{idx + 1}
                              </div>
                              <div className="min-w-0">
                                <p className="text-xs font-bold text-white truncate">{p.ign || p.name}</p>
                                <p className="text-[10px] font-mono text-zinc-500">UID: {p.ffUid || 'N/A'}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 3: WALLET & CASH DEPOSITS / WITHDRAWALS */}
        {/* ========================================================================= */}
        {activeTab === 'wallet' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            {/* Wallet Header Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-6 rounded-3xl border border-zinc-800 bg-gradient-to-br from-emerald-950/30 to-zinc-950 shadow-xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-bold uppercase tracking-wider text-emerald-400">Available Balance</p>
                    <Wallet className="w-5 h-5 text-emerald-400" />
                  </div>
                  <p className="text-3xl font-black text-emerald-400 font-mono">
                    +₹{wallet?.availableBalance ?? 0}
                  </p>
                  <p className="text-[11px] text-zinc-400 mt-1">Usable for joining any tournament</p>
                </div>
                <div className="mt-4 pt-3 border-t border-zinc-800/80">
                  <button
                    type="button"
                    onClick={() => {
                      setDepositModalInitialAmount(100);
                      setIsDepositModalOpen(true);
                    }}
                    className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-black text-xs transition shadow-md shadow-emerald-500/20 active:scale-95 cursor-pointer"
                  >
                    <QrCode className="w-4 h-4" />
                    <span>+ Quick Deposit (QR Code)</span>
                  </button>
                </div>
              </div>

              <div className="p-6 rounded-3xl border border-zinc-800 bg-zinc-900/60 shadow-xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-bold uppercase tracking-wider text-emerald-400">Total Winnings</p>
                    <Trophy className="w-5 h-5 text-emerald-400" />
                  </div>
                  <p className="text-3xl font-black text-emerald-400 font-mono">
                    +₹{wallet?.totalWinnings ?? 0}
                  </p>
                  <p className="text-[11px] text-zinc-400 mt-1">Earned from match kills & rank prizes</p>
                </div>
                <div className="mt-4 pt-3 border-t border-zinc-800/80">
                  <p className="text-[11px] text-emerald-400/90 font-medium">Auto-credited upon match completion</p>
                </div>
              </div>

              <div className="p-6 rounded-3xl border border-zinc-800 bg-zinc-900/60 shadow-xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-bold uppercase tracking-wider text-emerald-400">Total Deposited</p>
                    <ArrowDownCircle className="w-5 h-5 text-emerald-400" />
                  </div>
                  <p className="text-3xl font-black text-emerald-400 font-mono">
                    +₹{wallet?.totalDeposited ?? 0}
                  </p>
                  <p className="text-[11px] text-zinc-400 mt-1">Approved lifetime deposit transactions</p>
                </div>
                <div className="mt-4 pt-3 border-t border-zinc-800/80">
                  <p className="text-[11px] text-zinc-400">
                    {myDepositRequests.filter((d) => d.status === 'Approved').length} deposits verified
                  </p>
                </div>
              </div>
            </div>

            {/* GOOGLE PLAY STORE REDEEM CODE CARDS GRID */}
            <div className="p-6 sm:p-8 rounded-3xl border border-emerald-500/30 bg-gradient-to-b from-emerald-950/40 via-zinc-950 to-[#0F1115] shadow-xl space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 text-xl font-bold">
                    🎮
                  </div>
                  <div>
                    <h3 className="text-base font-black text-white flex items-center gap-2">
                      <span>Google Play Redeem Codes</span>
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-extrabold uppercase tracking-wider">
                        Instant Wallet Redeem
                      </span>
                    </h3>
                    <p className="text-xs text-zinc-400">
                      Redeem official Google Play Gift Cards (₹10, ₹20, ₹50, ₹100, ₹500) directly using your wallet balance.
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-2">
                {[
                  { amount: 10, label: '₹10 Play Code', color: 'from-emerald-500/20 to-teal-950/60 border-emerald-500/40' },
                  { amount: 20, label: '₹20 Play Code', color: 'from-cyan-500/20 to-blue-950/60 border-cyan-500/40' },
                  { amount: 50, label: '₹50 Play Code', color: 'from-amber-500/20 to-orange-950/60 border-amber-500/40' },
                  { amount: 100, label: '₹100 Play Code', color: 'from-purple-500/20 to-indigo-950/60 border-purple-500/40' },
                  { amount: 500, label: '₹500 Play Code', color: 'from-rose-500/20 to-pink-950/60 border-rose-500/40' },
                ].map((card) => (
                  <div
                    key={card.amount}
                    className={`p-3.5 rounded-2xl bg-gradient-to-b ${card.color} border flex flex-col items-center text-center justify-between gap-2.5 transition hover:scale-102`}
                  >
                    <div className="w-10 h-10 rounded-2xl bg-black/50 border border-white/10 flex items-center justify-center text-xl shadow-inner">
                      🎁
                    </div>
                    <div>
                      <span className="block text-[11px] font-bold text-zinc-300">{card.label}</span>
                      <span className="text-lg font-black text-white font-mono">₹{card.amount}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setWithdrawMethod('REDEEM_CODE');
                        setWithdrawAmount(card.amount);
                        const el = document.getElementById('wallet-withdraw-form');
                        if (el) el.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="w-full py-1.5 px-2 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-zinc-950 font-black text-[11px] transition cursor-pointer active:scale-95 shadow-md shadow-emerald-500/20"
                    >
                      Redeem ₹{card.amount}
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Deposit and Withdrawal Actions Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* DEPOSIT CARD (OPENS SECURE PAYMENT MODAL ON CLICK) */}
              <div className="p-6 sm:p-8 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ArrowDownCircle className="w-5 h-5 text-emerald-400" />
                    <h3 className="text-base font-black text-white">Deposit & Add Money</h3>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-bold">
                    UPI & QR
                  </span>
                </div>

                <p className="text-xs text-zinc-400 leading-relaxed">
                  Select your deposit amount below and click <span className="text-emerald-400 font-bold">Proceed to Pay</span> to view official Admin UPI details, scan dynamic QR code, and attach payment proof.
                </p>

                {/* Preset amounts */}
                <div>
                  <label className="block text-[11px] font-bold uppercase text-zinc-400 mb-1.5">
                    Select Amount (₹)
                  </label>
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mb-2">
                    {[50, 100, 200, 500, 1000, 2000].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setDepositAmount(amt)}
                        className={`py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                          depositAmount === amt
                            ? 'bg-emerald-500 text-zinc-950 font-black shadow-md shadow-emerald-500/20'
                            : 'bg-zinc-950 border border-zinc-800 text-zinc-300 hover:border-zinc-700'
                        }`}
                      >
                        ₹{amt}
                      </button>
                    ))}
                  </div>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 text-xs font-bold">₹</span>
                    <input
                      type="number"
                      min={10}
                      value={depositAmount}
                      onChange={(e) => setDepositAmount(Number(e.target.value))}
                      placeholder="Custom amount"
                      className="w-full pl-7 pr-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white placeholder-zinc-600 focus:border-emerald-500 focus:outline-none transition font-mono font-bold"
                    />
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-zinc-950/80 border border-zinc-800 space-y-2">
                  <div className="flex items-center justify-between text-xs text-zinc-300">
                    <span className="text-zinc-400">Payment Gateway</span>
                    <span className="font-bold text-emerald-400 flex items-center gap-1">
                      <QrCode className="w-3.5 h-3.5" /> Instant UPI QR
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-zinc-300">
                    <span className="text-zinc-400">Admin UPI ID</span>
                    <span className="font-mono text-amber-400 font-bold">{websiteSettings?.upiId || '9991522138-2@ybl'}</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setDepositModalInitialAmount(depositAmount || 100);
                    setIsDepositModalOpen(true);
                  }}
                  className="w-full py-3.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-black text-xs transition shadow-lg shadow-emerald-500/20 active:scale-98 cursor-pointer flex items-center justify-center gap-2"
                >
                  <QrCode className="w-4 h-4" />
                  <span>Proceed to Pay (₹{depositAmount || 100}) & Scan QR</span>
                </button>
              </div>

              {/* WITHDRAWAL FORM */}
              <div id="wallet-withdraw-form" className="p-6 sm:p-8 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-5">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <ArrowUpCircle className="w-5 h-5 text-rose-400" />
                    <h3 className="text-base font-black text-white">Withdraw & Redeem Balance</h3>
                  </div>
                  <span className="text-xs text-zinc-400">Min: ₹10 for Play Code, ₹50 for Bank/UPI</span>
                </div>

                {withdrawMessage && (
                  <div
                    className={`p-3.5 rounded-2xl text-xs flex items-start gap-2.5 ${
                      withdrawMessage.type === 'success'
                        ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-300'
                        : 'bg-rose-500/10 border border-rose-500/20 text-rose-300'
                    }`}
                  >
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{withdrawMessage.text}</span>
                  </div>
                )}

                <form onSubmit={handleWithdrawalSubmit} className="space-y-4">
                  <div>
                    <label className="block text-[11px] font-bold uppercase text-zinc-400 mb-1.5">
                      Payout / Redemption Method
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                      {[
                        { id: 'UPI', label: '⚡ UPI' },
                        { id: 'REDEEM_CODE', label: '🎮 Play Code' },
                        { id: 'PAYTM', label: '💙 Paytm' },
                        { id: 'BANK', label: '🏛️ Bank' },
                      ].map((m) => (
                        <button
                          key={m.id}
                          type="button"
                          onClick={() => setWithdrawMethod(m.id as any)}
                          className={`py-2 px-1 rounded-xl font-bold transition cursor-pointer text-center ${
                            withdrawMethod === m.id
                              ? 'bg-emerald-500 text-zinc-950 font-black shadow-md shadow-emerald-500/20'
                              : 'bg-zinc-950 border border-zinc-800 text-zinc-300 hover:border-zinc-700'
                          }`}
                        >
                          {m.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {withdrawMethod === 'REDEEM_CODE' ? (
                    <div className="space-y-3 p-3.5 rounded-2xl bg-gradient-to-b from-emerald-950/40 to-zinc-950 border border-emerald-500/30">
                      <div>
                        <label className="block text-[11px] font-bold uppercase text-emerald-400 mb-1.5 flex items-center justify-between">
                          <span>Select Google Play Code Amount</span>
                          <span className="text-[10px] text-zinc-400 font-normal">Instant Redeem</span>
                        </label>
                        <div className="grid grid-cols-5 gap-1.5">
                          {[10, 20, 50, 100, 500].map((amt) => (
                            <button
                              key={amt}
                              type="button"
                              onClick={() => setWithdrawAmount(amt)}
                              className={`py-2.5 rounded-xl text-xs font-mono font-black transition cursor-pointer border ${
                                withdrawAmount === amt
                                  ? 'bg-emerald-500 text-zinc-950 border-emerald-400 shadow-lg shadow-emerald-500/30 scale-102'
                                  : 'bg-zinc-900 border-zinc-800 text-zinc-200 hover:border-zinc-700'
                              }`}
                            >
                              ₹{amt}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold uppercase text-zinc-300 mb-1">
                          Amount (₹)
                        </label>
                        <input
                          type="number"
                          min={10}
                          required
                          value={withdrawAmount}
                          onChange={(e) => setWithdrawAmount(Number(e.target.value))}
                          className="w-full px-3.5 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs font-mono font-bold text-emerald-400 focus:border-emerald-500 focus:outline-none transition"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold uppercase text-zinc-300 mb-1">
                          WhatsApp / Mobile Number for Code Delivery *
                        </label>
                        <input
                          type="tel"
                          required
                          value={withdrawPhone}
                          onChange={(e) => setWithdrawPhone(e.target.value)}
                          placeholder="e.g. 9876543210"
                          className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white placeholder-zinc-600 focus:border-emerald-500 focus:outline-none transition"
                        />
                      </div>

                      <p className="text-[10px] text-emerald-300/80 leading-snug">
                        🎁 <strong>₹{withdrawAmount} Play Store Code</strong> will be processed & delivered to your mobile/WhatsApp and recorded in your transaction history.
                      </p>
                    </div>
                  ) : (
                    <>
                      <div>
                        <label className="block text-[11px] font-bold uppercase text-zinc-400 mb-1">
                          Withdrawal Amount (Min ₹50) *
                        </label>
                        <input
                          type="number"
                          min={50}
                          required
                          value={withdrawAmount}
                          onChange={(e) => setWithdrawAmount(Number(e.target.value))}
                          className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white focus:border-amber-500 focus:outline-none transition font-mono font-bold"
                        />
                      </div>

                      {withdrawMethod === 'UPI' || withdrawMethod === 'PAYTM' ? (
                        <div>
                          <label className="block text-[11px] font-bold uppercase text-zinc-400 mb-1">
                            Your UPI ID / Phone Number *
                          </label>
                          <input
                            type="text"
                            required
                            value={withdrawUpiId}
                            onChange={(e) => setWithdrawUpiId(e.target.value)}
                            placeholder="yourname@okhdfcbank or 9876543210"
                            autoComplete="off"
                            className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white placeholder-zinc-600 focus:border-amber-500 focus:outline-none transition"
                          />
                        </div>
                      ) : (
                        <div className="space-y-2.5">
                          <div>
                            <label className="block text-[11px] font-bold uppercase text-zinc-400 mb-1">
                              Bank Account Number *
                            </label>
                            <input
                              type="text"
                              required
                              value={withdrawBankAcc}
                              onChange={(e) => setWithdrawBankAcc(e.target.value)}
                              placeholder="Account Number"
                              autoComplete="off"
                              className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white focus:border-amber-500 focus:outline-none transition"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold uppercase text-zinc-400 mb-1">
                              Bank IFSC Code *
                            </label>
                            <input
                              type="text"
                              required
                              value={withdrawIfsc}
                              onChange={(e) => setWithdrawIfsc(e.target.value)}
                              placeholder="IFSC Code (e.g. SBIN0001234)"
                              autoComplete="off"
                              className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white focus:border-amber-500 focus:outline-none transition"
                            />
                          </div>
                        </div>
                      )}
                    </>
                  )}

                  <button
                    type="submit"
                    disabled={withdrawLoading || !currentUser}
                    className="w-full py-3.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-black text-xs transition shadow-lg shadow-emerald-500/20 active:scale-98 cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {withdrawLoading
                      ? 'Processing Request...'
                      : withdrawMethod === 'REDEEM_CODE'
                      ? `Redeem Google Play Code (₹${withdrawAmount || 10})`
                      : `Request Payout (-₹${withdrawAmount || 50})`}
                  </button>
                </form>
              </div>
            </div>

            {/* MY DEPOSIT VERIFICATION REQUESTS STATUS TABLE */}
            <div className="p-6 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black text-white flex items-center gap-2">
                  <QrCode className="w-5 h-5 text-emerald-400" />
                  <span>My Deposit Verification Requests</span>
                </h3>
                <span className="text-xs text-zinc-400 font-medium">
                  {myDepositRequests.length} total submitted
                </span>
              </div>

              {myDepositRequests.length === 0 ? (
                <div className="text-center py-8 text-xs text-zinc-500 border border-dashed border-zinc-800 rounded-2xl">
                  No deposit requests submitted yet. Use the form above or click "+ Quick Deposit" to scan QR.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {myDepositRequests.map((dep) => (
                    <div
                      key={dep.id}
                      className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div className="flex items-start sm:items-center gap-3">
                        <div
                          className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 font-mono font-black text-sm ${
                            dep.status === 'Approved'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : dep.status === 'Rejected'
                              ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                              : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                          }`}
                        >
                          ₹{dep.amount}
                        </div>
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-bold text-white font-mono">
                              UTR: {dep.utrNumber}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                dep.status === 'Approved'
                                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                  : dep.status === 'Rejected'
                                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                                  : 'bg-amber-500/20 text-amber-400 border border-amber-500/30 animate-pulse'
                              }`}
                            >
                              {dep.status === 'Approved'
                                ? '✓ Approved & Credited'
                                : dep.status === 'Rejected'
                                ? '✗ Rejected'
                                : '⏳ Pending Admin Verification'}
                            </span>
                          </div>
                          <p className="text-[10px] text-zinc-500">
                            Submitted: {new Date(dep.createdAt).toLocaleString()}
                          </p>
                          {dep.adminNote && (
                            <p className="text-[11px] text-amber-300/90 font-medium pt-0.5">
                              Admin Note: {dep.adminNote}
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-auto">
                        {dep.screenshotUrl && (
                          <button
                            type="button"
                            onClick={() => setPreviewProofUrl(dep.screenshotUrl!)}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs font-bold text-zinc-300 transition cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Proof</span>
                          </button>
                        )}
                        <div className="text-right">
                          <p className="text-xs font-black font-mono text-emerald-400">
                            +₹{dep.amount}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* MY WITHDRAWAL REQUESTS STATUS TABLE */}
            <div className="p-6 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black text-white flex items-center gap-2">
                  <ArrowUpCircle className="w-5 h-5 text-cyan-400" />
                  <span>My Withdrawal Requests</span>
                </h3>
                <span className="text-xs text-zinc-400 font-medium">
                  {myWithdrawalRequests.length} total requests
                </span>
              </div>

              {myWithdrawalRequests.length === 0 ? (
                <div className="text-center py-8 text-xs text-zinc-500 border border-dashed border-zinc-800 rounded-2xl">
                  No withdrawal requests submitted yet.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {myWithdrawalRequests.map((w) => (
                    <div
                      key={w.id}
                      className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div className="flex items-start sm:items-center gap-3">
                        <div
                          className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 font-mono font-black text-sm ${
                            w.status === 'Paid' || w.status === 'Approved'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : w.status === 'Rejected'
                              ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                              : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                          }`}
                        >
                          -₹{w.requestedAmount}
                        </div>
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-bold text-white font-mono">
                              {w.payoutMethod || 'UPI'}: {w.payoutDetails?.upiId || w.payoutDetails?.accountNumber || w.phone || 'Details Provided'}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                w.status === 'Paid' || w.status === 'Approved'
                                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                  : w.status === 'Rejected'
                                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                                  : 'bg-amber-500/20 text-amber-400 border border-amber-500/30 animate-pulse'
                              }`}
                            >
                              {w.status === 'Paid'
                                ? '✓ Paid & Transferred'
                                : w.status === 'Approved'
                                ? '✓ Approved'
                                : w.status === 'Processing'
                                ? '⚙️ Processing'
                                : w.status === 'Rejected'
                                ? '✗ Rejected'
                                : '⏳ Pending Admin Verification'}
                            </span>
                          </div>
                          <p className="text-[10px] text-zinc-500">
                            Requested: {new Date(w.createdAt).toLocaleString()}
                          </p>
                          {w.adminNote && (
                            <p className="text-[11px] text-amber-300/90 font-medium pt-0.5">
                              Admin Note: {w.adminNote}
                            </p>
                          )}
                          {w.payoutMethod === 'REDEEM_CODE' && w.transactionRef && (
                            <div className="mt-2 p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-500/40 flex items-center justify-between gap-2">
                              <div>
                                <span className="text-[10px] text-emerald-400 font-bold uppercase block">🎁 Your Play Store Code:</span>
                                <span className="text-xs font-mono font-black text-amber-300 tracking-wider select-all">{w.transactionRef}</span>
                              </div>
                              <button
                                type="button"
                                onClick={() => {
                                  navigator.clipboard.writeText(w.transactionRef || '');
                                  alert('Google Play Redeem Code Copied!\n' + w.transactionRef);
                                }}
                                className="px-2.5 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-black text-[10px] transition cursor-pointer active:scale-95 shrink-0"
                              >
                                Copy Code
                              </button>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="text-right self-end sm:self-auto">
                        <p className="text-xs font-black font-mono text-rose-400">
                          -₹{w.requestedAmount}
                        </p>
                        <p className="text-[10px] text-zinc-500 uppercase">{w.status}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* TRANSACTIONS HISTORY */}
            <div className="p-6 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-4">
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-400" />
                <span>Wallet Ledger & Transaction History</span>
              </h3>

              {myTransactions.length === 0 ? (
                <div className="text-center py-8 text-xs text-zinc-500 border border-dashed border-zinc-800 rounded-2xl">
                  No transactions recorded yet in Firebase.
                </div>
              ) : (
                <div className="space-y-2">
                  {myTransactions.map((tx) => {
                    const isCredit =
                      tx.type === 'Prize' ||
                      tx.type === 'Deposit' ||
                      tx.type === 'Refund' ||
                      (tx.newBalance !== undefined &&
                        tx.previousBalance !== undefined &&
                        tx.newBalance >= tx.previousBalance);

                    return (
                      <div
                        key={tx.id}
                        className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800/80 flex items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                              isCredit
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                            }`}
                          >
                            {isCredit ? '+' : '-'}
                          </div>
                          <div>
                            <p className="text-xs font-bold text-white">{tx.description || tx.type}</p>
                            <p className="text-[10px] text-zinc-500 mt-0.5">
                              {new Date(tx.timestamp).toLocaleString()}
                            </p>
                          </div>
                        </div>

                        <div className="text-right">
                          <p
                            className={`text-xs font-mono font-black ${
                              isCredit ? 'text-emerald-400' : 'text-rose-400'
                            }`}
                          >
                            {isCredit ? '+' : '-'}₹{Math.abs(tx.amount)}
                          </p>
                          <span className="text-[10px] text-zinc-500 font-mono">
                            Bal: ₹{tx.newBalance}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 4: LEADERBOARD */}
        {/* ========================================================================= */}
        {activeTab === 'leaderboard' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div>
              <h2 className="text-xl font-black text-white tracking-tight flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-400" />
                <span>Esports Champions & Hall of Fame</span>
              </h2>
              <p className="text-xs text-zinc-400">
                Top players ranked by tournament earnings and kill counts.
              </p>
            </div>

            <div className="p-6 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl">
              <div className="space-y-3">
                {[
                  { rank: 1, name: 'SniperKing_FF', kills: 142, wins: 28, earnings: 14500 },
                  { rank: 2, name: 'ViperX_God', kills: 118, wins: 22, earnings: 11200 },
                  { rank: 3, name: 'HeadshotGuru', kills: 98, wins: 19, earnings: 9400 },
                  { rank: 4, name: 'AlphaPredator', kills: 84, wins: 14, earnings: 6800 },
                  { rank: 5, name: 'RushSquadLeader', kills: 72, wins: 11, earnings: 5100 },
                ].map((player) => (
                  <div
                    key={player.rank}
                    className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/80 flex items-center justify-between gap-4 hover:border-amber-500/40 transition"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-8 h-8 rounded-xl flex items-center justify-center font-black text-xs ${
                          player.rank === 1
                            ? 'bg-amber-500 text-zinc-950 shadow-md shadow-amber-500/20'
                            : player.rank === 2
                            ? 'bg-zinc-300 text-zinc-950'
                            : player.rank === 3
                            ? 'bg-amber-700 text-white'
                            : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        #{player.rank}
                      </div>
                      <div>
                        <p className="text-xs font-bold text-white">{player.name}</p>
                        <p className="text-[10px] text-zinc-400">
                          {player.kills} Kills • {player.wins} Booyahs
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <p className="text-xs font-mono font-black text-amber-400">₹{player.earnings}</p>
                      <p className="text-[10px] text-zinc-500 uppercase">Winnings</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 5: SUPPORT & HELP */}
        {/* ========================================================================= */}
        {activeTab === 'support' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            <div>
              <h2 className="text-xl font-black text-white tracking-tight flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-amber-400" />
                <span>Player Support & Ticket Center</span>
              </h2>
              <p className="text-xs text-zinc-400">
                Submit tickets regarding payment verifications, room access, or rules.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Submit Ticket Form */}
              <div className="p-6 sm:p-8 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-5">
                <h3 className="text-base font-black text-white flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-amber-400" />
                  <span>Open Support Ticket</span>
                </h3>

                {ticketSuccess && (
                  <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                    <span>{ticketSuccess}</span>
                  </div>
                )}

                <form onSubmit={handleTicketSubmit} className="space-y-4">
                  <div>
                    <label className="block text-[11px] font-bold uppercase text-zinc-400 mb-1">
                      Issue Category
                    </label>
                    <select
                      value={ticketCategory}
                      onChange={(e) => setTicketCategory(e.target.value as any)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white focus:border-amber-500 focus:outline-none transition cursor-pointer"
                    >
                      <option value="Payment">Payment & Deposit Verification</option>
                      <option value="Tournament">Tournament Registration Issue</option>
                      <option value="Room">Custom Room ID / Password</option>
                      <option value="Result">Match Result & Prize Query</option>
                      <option value="Account">Account / IGN Change</option>
                      <option value="Other">Other Query</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold uppercase text-zinc-400 mb-1">
                      Subject *
                    </label>
                    <input
                      type="text"
                      required
                      value={ticketSubject}
                      onChange={(e) => setTicketSubject(e.target.value)}
                      placeholder="e.g. Deposit not credited after 15 mins"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white placeholder-zinc-600 focus:border-amber-500 focus:outline-none transition"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold uppercase text-zinc-400 mb-1">
                      Detailed Message *
                    </label>
                    <textarea
                      rows={4}
                      required
                      value={ticketMessage}
                      onChange={(e) => setTicketMessage(e.target.value)}
                      placeholder="Describe your issue with transaction reference, match ID, or screenshot details..."
                      className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white placeholder-zinc-600 focus:border-amber-500 focus:outline-none transition"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={ticketLoading || !currentUser}
                    className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition shadow-lg shadow-amber-500/20 active:scale-98 cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>{ticketLoading ? 'Submitting...' : 'Send Support Ticket'}</span>
                  </button>
                </form>
              </div>

              {/* My Tickets */}
              <div className="p-6 sm:p-8 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-4">
                <h3 className="text-base font-black text-white">Your Recent Support Tickets</h3>

                {myTickets.length === 0 ? (
                  <div className="text-center py-12 border border-dashed border-zinc-800 rounded-2xl text-xs text-zinc-500">
                    No support tickets submitted yet.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {myTickets.map((t) => (
                      <div
                        key={t.id}
                        className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/80 space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-zinc-800 text-amber-400">
                            {t.category}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                              t.status === 'Resolved'
                                ? 'bg-emerald-500/10 text-emerald-400'
                                : 'bg-amber-500/10 text-amber-400'
                            }`}
                          >
                            {t.status}
                          </span>
                        </div>
                        <p className="text-xs font-bold text-white">{t.subject}</p>
                        <p className="text-[11px] text-zinc-400 line-clamp-2">
                          {t.messages?.[0]?.message}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 6: COMPLETE PLAYER PROFILE & DASHBOARD */}
        {/* ========================================================================= */}
        {activeTab === 'profile' && (
          <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in duration-200">
            {!currentUser ? (
              <div className="p-8 sm:p-12 text-center rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-4 max-w-md mx-auto">
                <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
                  <User className="w-7 h-7 text-amber-400" />
                </div>
                <h3 className="text-lg font-black text-white">Sign In to View Your Profile</h3>
                <p className="text-xs text-zinc-400">
                  Access your wallet balance, joined tournaments, real-time Room ID & Password, and match history.
                </p>
                <div className="pt-2 flex items-center justify-center gap-3">
                  <button
                    onClick={() => {
                      setAuthModalInitialMode('login');
                      setAuthModalOpen(true);
                    }}
                    className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition shadow-lg shadow-amber-500/20 cursor-pointer"
                  >
                    Sign In
                  </button>
                  <button
                    onClick={() => {
                      setAuthModalInitialMode('signup');
                      setAuthModalOpen(true);
                    }}
                    className="px-5 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 font-bold text-xs border border-zinc-700 transition cursor-pointer"
                  >
                    Create Account
                  </button>
                </div>
              </div>
            ) : (
              <>
                {/* 1. Header & Quick Overview */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
                      <User className="w-6 h-6 text-amber-400" />
                      <span>Player Esports Dashboard</span>
                    </h2>
                    <p className="text-xs text-zinc-400">
                      Manage your Free Fire game profile, wallet balance, joined matches, and room credentials.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setActiveTab('wallet')}
                      className="px-3.5 py-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Deposit Money</span>
                    </button>
                    <button
                      onClick={() => logout()}
                      className="px-3.5 py-2 rounded-xl bg-zinc-900 hover:bg-rose-500/10 text-zinc-400 hover:text-rose-400 border border-zinc-800 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>

                {/* 2. Top Dual Cards: Profile Identity + Wallet Balances */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Card A: Profile & Game Identity (5 Cols) */}
                  <div className="lg:col-span-5 p-6 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-300 text-zinc-950 font-black text-xl flex items-center justify-center shadow-lg shadow-amber-500/20">
                          {(userProfile?.ign || currentUser.email || 'P')[0].toUpperCase()}
                        </div>
                        <div>
                          <h3 className="text-sm font-black text-white">
                            {userProfile?.name || currentUser.displayName || 'Free Fire Warrior'}
                          </h3>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
                            {role === 'PLAYER' ? 'Free Fire Player' : role.replace('_', ' ')}
                          </span>
                        </div>
                      </div>
                    </div>

                    <form onSubmit={handleSaveProfile} className="space-y-3.5 pt-2 border-t border-zinc-800/80">
                      <div>
                        <label className="block text-[10px] font-bold uppercase text-zinc-400 mb-1">
                          Registered Email
                        </label>
                        <input
                          type="text"
                          disabled
                          value={currentUser.email || ''}
                          className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-zinc-500 cursor-not-allowed font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold uppercase text-amber-400 mb-1">
                          Free Fire In-Game Name (IGN) *
                        </label>
                        <input
                          type="text"
                          required
                          value={editIgn}
                          onChange={(e) => setEditIgn(e.target.value)}
                          placeholder="e.g. SKY_LORD_99"
                          className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white focus:border-amber-500 focus:outline-none transition"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold uppercase text-amber-400 mb-1">
                          Free Fire UID (Numeric ID) *
                        </label>
                        <input
                          type="text"
                          required
                          value={editFfUid}
                          onChange={(e) => setEditFfUid(e.target.value)}
                          placeholder="e.g. 1928374921"
                          className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white font-mono focus:border-amber-500 focus:outline-none transition"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold uppercase text-zinc-400 mb-1">
                          WhatsApp / Contact Number
                        </label>
                        <input
                          type="tel"
                          value={editPhone}
                          onChange={(e) => setEditPhone(e.target.value)}
                          placeholder="e.g. +91 9876543210"
                          className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white focus:border-amber-500 focus:outline-none transition"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={profileSaving}
                        className="w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition shadow-md shadow-amber-500/20 active:scale-98 cursor-pointer disabled:opacity-50"
                      >
                        {profileSaving ? 'Saving Changes...' : 'Save Profile Details'}
                      </button>
                    </form>
                  </div>

                  {/* Card B: Real-Time Money & Wallet Overview (7 Cols) */}
                  <div className="lg:col-span-7 p-6 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-5 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Wallet className="w-5 h-5 text-emerald-400" />
                          <h3 className="text-sm font-black text-white uppercase tracking-wider">
                            Wallet & Cash Balances
                          </h3>
                        </div>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                          LIVE BALANCE
                        </span>
                      </div>

                      {/* Main Money Counter */}
                      <div className="mt-4 p-5 rounded-2xl bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800 flex items-center justify-between">
                        <div>
                          <p className="text-[10px] font-bold uppercase tracking-wider text-zinc-400">
                            Available Cash Balance
                          </p>
                          <p className="text-3xl font-black text-emerald-400 font-mono tracking-tight mt-1">
                            +₹{wallet?.availableBalance ?? 0}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              setDepositModalInitialAmount(100);
                              setIsDepositModalOpen(true);
                            }}
                            className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-black text-xs transition shadow-md shadow-emerald-500/20 active:scale-95 cursor-pointer flex items-center gap-1.5"
                          >
                            <QrCode className="w-3.5 h-3.5" />
                            <span>+ Add Money</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setActiveTab('wallet')}
                            className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs transition shadow-md shadow-amber-500/20 cursor-pointer flex items-center gap-1.5"
                          >
                            <Wallet className="w-3.5 h-3.5" />
                            <span>Wallet & Withdraw</span>
                          </button>
                        </div>
                      </div>

                      {/* Money Sub-Stats Grid */}
                      <div className="grid grid-cols-3 gap-3 mt-4">
                        <div className="p-3 rounded-2xl bg-zinc-950 border border-zinc-800/80">
                          <span className="text-[10px] uppercase font-bold text-zinc-500">Total Won</span>
                          <p className="text-base font-black text-emerald-400 font-mono mt-0.5">
                            +₹{wallet?.totalWinnings ?? 0}
                          </p>
                        </div>
                        <div className="p-3 rounded-2xl bg-zinc-950 border border-zinc-800/80">
                          <span className="text-[10px] uppercase font-bold text-zinc-500">Deposited</span>
                          <p className="text-base font-black text-emerald-400 font-mono mt-0.5">
                            +₹{wallet?.totalDeposited ?? 0}
                          </p>
                        </div>
                        <div className="p-3 rounded-2xl bg-zinc-950 border border-zinc-800/80">
                          <span className="text-[10px] uppercase font-bold text-zinc-500">Withdrawn</span>
                          <p className="text-base font-black text-rose-400 font-mono mt-0.5">
                            -₹{wallet?.totalWithdrawn ?? 0}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-zinc-950/80 border border-zinc-800 text-[11px] text-zinc-400 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <Shield className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>100% Safe Instant UPI Payouts & Play Code Redemptions.</span>
                      </div>
                      <button
                        onClick={() => setActiveTab('wallet')}
                        className="px-2.5 py-1 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold shrink-0 cursor-pointer"
                      >
                        Open Wallet →
                      </button>
                    </div>
                  </div>
                </div>

                {/* 3. Section: "My Joined Matches & Room Credentials Hub" (Requested Explicitly) */}
                <div className="p-6 sm:p-8 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <Trophy className="w-5 h-5 text-amber-400" />
                        <h3 className="text-base font-black text-white">
                          My Joined Matches & Room Credentials ({myRegistrations.length})
                        </h3>
                      </div>
                      <p className="text-xs text-zinc-400">
                        Room ID & Password will be revealed here before match start. Copy and enter in Free Fire custom room.
                      </p>
                    </div>
                    {myRegistrations.length > 0 && (
                      <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 w-fit">
                        {myRegistrations.length} Active Tournaments
                      </span>
                    )}
                  </div>

                  {myRegistrations.length === 0 ? (
                    <div className="p-8 text-center rounded-2xl bg-zinc-950 border border-zinc-800/80 space-y-3">
                      <Gamepad2 className="w-8 h-8 text-zinc-600 mx-auto" />
                      <p className="text-xs text-zinc-400">You haven't joined any tournament yet.</p>
                      <button
                        onClick={() => setActiveTab('tournaments')}
                        className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition shadow-md shadow-amber-500/20 cursor-pointer"
                      >
                        Explore & Join Tournaments
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {myRegistrations.map((reg) => {
                        const tourney = tournaments.find((t) => t.id === reg.tournamentId);
                        const hasRoomCreds =
                          tourney?.roomId &&
                          tourney?.roomPassword &&
                          tourney?.roomId.trim() !== '';

                        return (
                          <div
                            key={reg.id}
                            className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4 hover:border-zinc-700 transition"
                          >
                            {/* Match Header Row */}
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-zinc-800/80">
                              <div className="space-y-1">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-sm font-black text-white">
                                    {reg.tournamentName}
                                  </span>
                                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-zinc-800 text-zinc-300">
                                    {tourney?.type || 'SQUAD'}
                                  </span>
                                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
                                    Map: {tourney?.map || 'Bermuda'}
                                  </span>
                                </div>
                                <div className="flex items-center gap-4 text-xs text-zinc-400">
                                  <span className="flex items-center gap-1">
                                    <Clock className="w-3.5 h-3.5 text-zinc-500" />
                                    {tourney?.matchDate || 'Today'} at {tourney?.matchTime || 'TBD'}
                                  </span>
                                  <span>Slot #{reg.slotNumber || 1}</span>
                                  <span>Team: <strong className="text-white">{reg.teamName}</strong></span>
                                </div>
                              </div>

                              <div className="flex items-center gap-2">
                                <span
                                  className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
                                    tourney?.status === 'Live'
                                      ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30 animate-pulse'
                                      : tourney?.status === 'Completed'
                                      ? 'bg-zinc-800 text-zinc-400'
                                      : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                  }`}
                                >
                                  {tourney?.status || 'Confirmed'}
                                </span>
                              </div>
                            </div>

                            {/* ROOM ID & PASSWORD CREDENTIALS BOX */}
                            <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
                              <div className="space-y-1">
                                <div className="flex items-center gap-1.5">
                                  <Radio className="w-4 h-4 text-amber-400 animate-pulse" />
                                  <span className="text-xs font-black uppercase text-amber-400 tracking-wide">
                                    Custom Room Credentials
                                  </span>
                                </div>
                                <p className="text-[11px] text-zinc-400">
                                  {hasRoomCreds
                                    ? 'Custom room is ready! Join room in Free Fire immediately.'
                                    : 'Room ID & Password will be published here 15 minutes before the match.'}
                                </p>
                              </div>

                              {hasRoomCreds ? (
                                <div className="flex items-center gap-3 flex-wrap">
                                  {/* Room ID Box */}
                                  <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-zinc-950 border border-amber-500/40">
                                    <div className="text-left">
                                      <p className="text-[9px] uppercase font-bold text-zinc-400">Room ID</p>
                                      <p className="text-sm font-mono font-black text-amber-400">
                                        {tourney.roomId}
                                      </p>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        navigator.clipboard.writeText(tourney.roomId || '');
                                        alert(`Copied Room ID: ${tourney.roomId}`);
                                      }}
                                      title="Copy Room ID"
                                      className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 cursor-pointer"
                                    >
                                      <Copy className="w-3.5 h-3.5" />
                                    </button>
                                  </div>

                                  {/* Room Password Box */}
                                  <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-zinc-950 border border-amber-500/40">
                                    <div className="text-left">
                                      <p className="text-[9px] uppercase font-bold text-zinc-400">Password</p>
                                      <p className="text-sm font-mono font-black text-amber-400">
                                        {tourney.roomPassword}
                                      </p>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        navigator.clipboard.writeText(tourney.roomPassword || '');
                                        alert(`Copied Password: ${tourney.roomPassword}`);
                                      }}
                                      title="Copy Password"
                                      className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 cursor-pointer"
                                    >
                                      <Copy className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <div className="px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs font-mono text-zinc-500">
                                  Awaiting Admin Release...
                                </div>
                              )}
                            </div>

                            {/* Squad Roster & Match Results */}
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                              {/* Roster */}
                              <div className="p-3 rounded-xl bg-zinc-900/50 border border-zinc-800/80 space-y-1.5">
                                <span className="text-[10px] uppercase font-bold text-zinc-500">Registered Roster</span>
                                <div className="space-y-1">
                                  {reg.players?.map((p, idx) => (
                                    <div key={idx} className="flex items-center justify-between text-xs">
                                      <span className="text-zinc-200">
                                        {p.ign || p.name || `Player ${idx + 1}`}
                                      </span>
                                      <span className="text-zinc-500 font-mono text-[11px]">
                                        UID: {p.ffUid || 'N/A'}
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              </div>

                              {/* Match Result / Prize Won */}
                              <div className="p-3 rounded-xl bg-zinc-900/50 border border-zinc-800/80 flex flex-col justify-between">
                                <span className="text-[10px] uppercase font-bold text-zinc-500">Result & Winnings</span>
                                {reg.result ? (
                                  <div className="space-y-1">
                                    <div className="flex items-center justify-between text-xs">
                                      <span className="text-zinc-400">Rank: #{reg.result.rank}</span>
                                      <span className="text-zinc-400">Kills: {reg.result.kills}</span>
                                    </div>
                                    <p className="text-sm font-bold text-emerald-400 font-mono">
                                      Prize Won: ₹{reg.result.prizeWon || 0}
                                    </p>
                                  </div>
                                ) : (
                                  <p className="text-xs text-zinc-500">
                                    Results will be published by tournament referee after the match concludes.
                                  </p>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* 4. Passbook / Full Wallet Transactions Log */}
                <div className="p-6 sm:p-8 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <FileText className="w-5 h-5 text-amber-400" />
                      <h3 className="text-base font-black text-white">Wallet Passbook & Transaction History</h3>
                    </div>
                    <span className="text-xs text-zinc-400">
                      {myTransactions.length} Transactions
                    </span>
                  </div>

                  {myTransactions.length === 0 ? (
                    <p className="text-xs text-zinc-500 py-4 text-center">No transaction records found.</p>
                  ) : (
                    <div className="divide-y divide-zinc-800/80">
                      {myTransactions.map((tx) => {
                        const typeUpper = (tx.type || '').toUpperCase();
                        const isCredit =
                          typeUpper.includes('DEPOSIT') ||
                          typeUpper.includes('PRIZE') ||
                          typeUpper.includes('WIN') ||
                          typeUpper.includes('REFUND') ||
                          typeUpper.includes('BONUS') ||
                          typeUpper.includes('CREDIT') ||
                          (tx.newBalance !== undefined && tx.previousBalance !== undefined && tx.newBalance >= tx.previousBalance);

                        return (
                          <div key={tx.id} className="py-3 flex items-center justify-between gap-4">
                            <div className="flex items-center gap-3">
                              <div
                                className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs ${
                                  isCredit
                                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                    : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                                }`}
                              >
                                {isCredit ? (
                                  <ArrowDownCircle className="w-4 h-4" />
                                ) : (
                                  <ArrowUpCircle className="w-4 h-4" />
                                )}
                              </div>
                              <div>
                                <p className="text-xs font-bold text-white">{tx.description || tx.type}</p>
                                <p className="text-[10px] text-zinc-500">
                                  {new Date(tx.createdAt || tx.timestamp || Date.now()).toLocaleString()} {tx.utrNumber ? `• UTR: ${tx.utrNumber}` : ''}
                                </p>
                              </div>
                            </div>

                            <div className="text-right">
                              <p
                                className={`text-xs font-black font-mono ${
                                  isCredit ? 'text-emerald-400' : 'text-rose-400'
                                }`}
                              >
                                {isCredit ? `+₹${Math.abs(tx.amount)}` : `-₹${Math.abs(tx.amount)}`}
                              </p>
                              <span
                                className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                                  tx.status === 'COMPLETED' || tx.status === 'Approved'
                                    ? 'bg-emerald-500/10 text-emerald-400'
                                    : tx.status === 'PENDING'
                                    ? 'bg-amber-500/10 text-amber-400'
                                    : 'bg-rose-500/10 text-rose-400'
                                }`}
                              >
                                {tx.status || 'COMPLETED'}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 7: SQUADS & TEAM MANAGEMENT */}
        {/* ========================================================================= */}
        {activeTab === 'squads' && (
          <div className="max-w-5xl mx-auto space-y-6 animate-in fade-in duration-200">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
                  <Users className="w-6 h-6 text-amber-400" />
                  <span>Squad & Team Roster Management</span>
                </h2>
                <p className="text-xs text-zinc-400">
                  Save your team rosters (Captain, Assaulters, Snipers) to auto-fill tournament registrations in 1-click.
                </p>
              </div>
              <button
                onClick={() => {
                  setEditingSquad({
                    teamName: '',
                    teamTag: '',
                    logoUrl: '',
                    members: [
                      { name: '', ign: '', ffUid: '', role: 'Captain' },
                      { name: '', ign: '', ffUid: '', role: 'Assaulter' },
                      { name: '', ign: '', ffUid: '', role: 'Sniper' },
                      { name: '', ign: '', ffUid: '', role: 'Flanker' },
                    ],
                  });
                  setIsSquadModalOpen(true);
                }}
                className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition shadow-lg shadow-amber-500/20 cursor-pointer flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Create New Squad</span>
              </button>
            </div>

            {mySquads.length === 0 ? (
              <div className="p-12 text-center rounded-3xl border border-zinc-800 bg-[#0F1115] space-y-3">
                <Users className="w-10 h-10 text-amber-400/50 mx-auto" />
                <h3 className="text-sm font-bold text-white">No Squads Saved Yet</h3>
                <p className="text-xs text-zinc-500 max-w-sm mx-auto">Create a squad to save your teammates' Free Fire IGNs and UIDs. You can select your saved squad when joining any Duo or Squad tournament.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {mySquads.map((sq) => (
                  <div key={sq.id} className="p-5 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center font-black text-amber-400 text-sm">
                          {sq.teamTag || sq.teamName[0].toUpperCase()}
                        </div>
                        <div>
                          <h3 className="text-sm font-bold text-white">{sq.teamName}</h3>
                          {sq.teamTag && <span className="text-[10px] text-zinc-500 font-mono">[{sq.teamTag}]</span>}
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => {
                            setEditingSquad(sq);
                            setIsSquadModalOpen(true);
                          }}
                          className="p-1.5 rounded-xl bg-zinc-900 text-zinc-300 hover:text-white border border-zinc-800 cursor-pointer text-xs"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => handleDeleteSquad(sq.id)}
                          className="p-1.5 rounded-xl bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 border border-rose-500/20 cursor-pointer text-xs"
                        >
                          Delete
                        </button>
                      </div>
                    </div>

                    <div className="space-y-2 border-t border-zinc-800/80 pt-3">
                      <span className="text-[10px] uppercase font-bold text-zinc-500">Squad Members</span>
                      <div className="grid grid-cols-2 gap-2">
                        {sq.members.map((m, idx) => (
                          <div key={idx} className="p-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs">
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-white truncate max-w-[90px]">{m.ign || m.name || `Member ${idx + 1}`}</span>
                              <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-300">{m.role}</span>
                            </div>
                            <p className="text-[10px] text-zinc-500 font-mono mt-0.5">UID: {m.ffUid || 'N/A'}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 8: MATCH PROOF & SCREENSHOT UPLOAD */}
        {/* ========================================================================= */}
        {activeTab === 'proofs' && (
          <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-200">
            <div>
              <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
                <Upload className="w-6 h-6 text-amber-400" />
                <span>Submit Match Results & Screenshot Proof</span>
              </h2>
              <p className="text-xs text-zinc-400">
                Upload your end-match scoreboard screenshot to claim kill prizes and verify victory standings with admins.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Form */}
              <div className="lg:col-span-6 p-6 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-4">
                <h3 className="text-sm font-bold text-white">New Proof Submission</h3>

                <form onSubmit={handleSubmitProof} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold uppercase text-zinc-400 mb-1">Select Tournament *</label>
                    <select
                      required
                      value={proofTournament?.id || ''}
                      onChange={(e) => {
                        const tourn = tournaments.find((t) => t.id === e.target.value);
                        setProofTournament(tourn || null);
                      }}
                      className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
                    >
                      <option value="">Select a tournament...</option>
                      {tournaments.map((t) => (
                        <option key={t.id} value={t.id}>{t.name} ({t.status})</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold uppercase text-amber-400 mb-1">Claimed Kills *</label>
                      <input
                        type="number"
                        min={0}
                        required
                        value={proofKills}
                        onChange={(e) => setProofKills(Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold uppercase text-amber-400 mb-1">Claimed Rank / Standing *</label>
                      <input
                        type="number"
                        min={1}
                        required
                        value={proofRank}
                        onChange={(e) => setProofRank(Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase text-zinc-400 mb-1">Upload Scoreboard Screenshot *</label>
                    <div className="relative border-2 border-dashed border-zinc-800 hover:border-amber-500/50 rounded-2xl p-4 text-center bg-zinc-950/50 transition">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleProofScreenshotUpload}
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                      />
                      <ImageIcon className="w-6 h-6 text-zinc-500 mx-auto mb-1" />
                      <p className="text-xs font-bold text-zinc-300">
                        {proofScreenshotName || 'Click or drop match screenshot'}
                      </p>
                      <p className="text-[10px] text-zinc-500">Max 5MB (PNG, JPG, WEBP)</p>
                    </div>
                  </div>

                  {proofScreenshot && (
                    <div className="rounded-xl overflow-hidden border border-zinc-800 bg-black aspect-video flex items-center justify-center">
                      <img src={proofScreenshot} alt="Preview" className="w-full h-full object-cover" />
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={proofSubmitting}
                    className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition shadow-lg shadow-amber-500/20 cursor-pointer disabled:opacity-50"
                  >
                    {proofSubmitting ? 'Submitting Proof...' : 'Submit Proof for Verification'}
                  </button>
                </form>
              </div>

              {/* History */}
              <div className="lg:col-span-6 p-6 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-4">
                <h3 className="text-sm font-bold text-white">Your Submitted Proofs ({myProofs.length})</h3>

                {myProofs.length === 0 ? (
                  <p className="text-xs text-zinc-500 text-center py-8">No match proofs submitted yet.</p>
                ) : (
                  <div className="space-y-3">
                    {myProofs.map((p) => (
                      <div key={p.id} className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white">{p.tournamentName}</span>
                          <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                            p.status === 'Verified' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                            p.status === 'Rejected' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' :
                            'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          }`}>
                            {p.status}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-xs text-zinc-400">
                          <span>Kills: <strong className="text-amber-400">{p.claimedKills}</strong></span>
                          <span>Rank: <strong className="text-white">#{p.claimedRank}</strong></span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 10: REFER & EARN SYSTEM */}
        {/* ========================================================================= */}
        {activeTab === 'referral' && (
          <div className="max-w-5xl mx-auto space-y-6 animate-in fade-in duration-200">
            {/* Top Banner */}
            <div className="relative rounded-3xl overflow-hidden border border-emerald-500/30 bg-gradient-to-r from-emerald-950/80 via-zinc-900 to-zinc-950 p-6 sm:p-8 shadow-2xl space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-400 to-amber-400 text-black font-black flex items-center justify-center text-xl shadow-lg shadow-emerald-500/20">
                    🎁
                  </div>
                  <div>
                    <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
                      <span>Refer & Earn Unlimited Cash</span>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">INSTANT PAYOUT</span>
                    </h2>
                    <p className="text-xs text-zinc-300 mt-0.5">
                      Invite your Free Fire gamer friends & earn cash rewards straight into your wallet!
                    </p>
                  </div>
                </div>

                {!currentUser && (
                  <button
                    onClick={() => {
                      setAuthModalInitialMode('signup');
                      setAuthModalOpen(true);
                    }}
                    className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition shadow-lg shadow-amber-500/20 cursor-pointer"
                  >
                    Sign Up to Get Referral Code
                  </button>
                )}
              </div>

              {/* Reward Rules Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <div className="p-3.5 rounded-2xl bg-zinc-950/80 border border-zinc-800 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm">
                    ₹20
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">₹20 Per Referral</h4>
                    <p className="text-[10px] text-zinc-400">Credited instantly on friend's signup</p>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-zinc-950/80 border border-zinc-800 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-sm">
                    ₹10
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">₹10 Friend Welcome Bonus</h4>
                    <p className="text-[10px] text-zinc-400">Your friend gets ₹10 bonus cash</p>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/20 to-emerald-500/20 border border-amber-500/30 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-400 text-black flex items-center justify-center font-black text-sm">
                    🏆
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-amber-300">₹500 Milestone Mega Bonus</h4>
                    <p className="text-[10px] text-amber-200/80">Earn ₹500 extra for every 10 referrals!</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Referrer Code & Stats Section */}
            {currentUser && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Left: Code & Share links */}
                <div className="lg:col-span-7 space-y-4 p-6 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>Your Personal Referral Code & Link</span>
                  </h3>

                  {/* Code Card */}
                  <div className="p-4 rounded-2xl bg-zinc-950 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <span className="text-[10px] uppercase font-extrabold text-amber-400">YOUR REFERRAL CODE</span>
                      <div className="text-2xl font-black font-mono tracking-wider text-white mt-0.5">
                        {userProfile?.referralCode || 'FF8X92'}
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        const code = userProfile?.referralCode || 'FF8X92';
                        navigator.clipboard.writeText(code);
                        setCopiedReferralCode(true);
                        setTimeout(() => setCopiedReferralCode(false), 2000);
                      }}
                      className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {copiedReferralCode ? (
                        <>
                          <Check className="w-4 h-4" />
                          <span>Code Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4" />
                          <span>Copy Code</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Share Link Card */}
                  <div className="space-y-2">
                    <label className="block text-[10px] uppercase font-extrabold text-zinc-400">Unique Share Link</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        readOnly
                        value={`${window.location.origin}?ref=${userProfile?.referralCode || 'FF8X92'}`}
                        className="flex-1 px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-zinc-300 font-mono truncate"
                      />
                      <button
                        onClick={() => {
                          const link = `${window.location.origin}?ref=${userProfile?.referralCode || 'FF8X92'}`;
                          navigator.clipboard.writeText(link);
                          setCopiedReferralLink(true);
                          setTimeout(() => setCopiedReferralLink(false), 2000);
                        }}
                        className="px-3.5 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-white font-bold text-xs border border-zinc-700 transition flex items-center gap-1.5 cursor-pointer"
                      >
                        {copiedReferralLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                        <span>{copiedReferralLink ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>
                  </div>

                  {/* WhatsApp Share Button */}
                  <button
                    onClick={() => {
                      const code = userProfile?.referralCode || 'FF8X92';
                      const link = `${window.location.origin}?ref=${code}`;
                      const text = `🎮 Join me on FF Tournament Esports! Use my referral code *${code}* or click link: ${link} to get ₹10 Free Bonus in your wallet! 🔥`;
                      window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
                    }}
                    className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>Share Directly on WhatsApp</span>
                  </button>
                </div>

                {/* Right: Referral Stats & Milestone Tracker */}
                <div className="lg:col-span-5 space-y-4 p-6 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Award className="w-4 h-4 text-amber-400" />
                    <span>Your Earnings & Progress</span>
                  </h3>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800">
                      <span className="text-[10px] font-extrabold uppercase text-zinc-500">Total Referred</span>
                      <div className="text-2xl font-black text-white mt-1">
                        {userProfile?.totalReferrals || myReferralRecords.length || 0} <span className="text-xs text-zinc-500 font-normal">Players</span>
                      </div>
                    </div>
                    <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800">
                      <span className="text-[10px] font-extrabold uppercase text-emerald-400">Total Earned</span>
                      <div className="text-2xl font-black text-emerald-400 mt-1">
                        ₹{userProfile?.totalReferralEarnings || 0}
                      </div>
                    </div>
                  </div>

                  {/* Milestone Progress Bar (10 Referrals = ₹500 Bonus) */}
                  {(() => {
                    const totalRefs = userProfile?.totalReferrals || myReferralRecords.length || 0;
                    const progress = totalRefs % 10;
                    const percent = Math.min((progress / 10) * 100, 100);
                    return (
                      <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-500/10 via-zinc-950 to-zinc-950 border border-amber-500/30 space-y-2.5">
                        <div className="flex items-center justify-between text-xs font-bold">
                          <span className="text-amber-300 flex items-center gap-1">
                            <span>🏆 Next ₹500 Milestone</span>
                          </span>
                          <span className="text-white font-mono">{progress} / 10 Referrals</span>
                        </div>

                        <div className="w-full h-3 rounded-full bg-zinc-900 border border-zinc-800 overflow-hidden p-0.5">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-amber-500 to-emerald-400 transition-all duration-500"
                            style={{ width: `${percent}%` }}
                          />
                        </div>

                        <p className="text-[11px] text-zinc-400">
                          Invite {10 - progress} more {10 - progress === 1 ? 'friend' : 'friends'} to claim <strong className="text-amber-300">₹500 Mega Milestone Cash</strong>!
                        </p>
                      </div>
                    );
                  })()}
                </div>
              </div>
            )}

            {/* Referred Users History */}
            {currentUser && (
              <div className="p-6 rounded-3xl border border-zinc-800 bg-[#0F1115] shadow-xl space-y-4">
                <h3 className="text-sm font-bold text-white flex items-center justify-between">
                  <span>Your Referred Friends ({myReferralRecords.length})</span>
                  <span className="text-xs text-zinc-500 font-normal">Real-time updates</span>
                </h3>

                {myReferralRecords.length === 0 ? (
                  <div className="py-8 text-center space-y-2">
                    <Gift className="w-8 h-8 text-zinc-600 mx-auto" />
                    <p className="text-xs text-zinc-400">No friends referred yet. Share your code to earn your first ₹20!</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs text-zinc-300">
                      <thead className="bg-zinc-950 text-[10px] uppercase font-bold text-zinc-500 border-b border-zinc-800">
                        <tr>
                          <th className="p-3">Player</th>
                          <th className="p-3">Date</th>
                          <th className="p-3">Reward Earned</th>
                          <th className="p-3">Milestone Bonus</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-zinc-800/60">
                        {myReferralRecords.map((r) => (
                          <tr key={r.id} className="hover:bg-zinc-900/50">
                            <td className="p-3 font-bold text-white">
                              {r.referredUserName}
                              <span className="block text-[10px] text-zinc-500 font-mono font-normal">{r.referredUserEmail}</span>
                            </td>
                            <td className="p-3 text-zinc-400 font-mono text-[11px]">
                              {new Date(r.timestamp).toLocaleDateString('en-IN', {
                                day: '2-digit',
                                month: 'short',
                                year: 'numeric',
                              })}
                            </td>
                            <td className="p-3 font-bold text-emerald-400">+₹{r.bonusAmount}</td>
                            <td className="p-3">
                              {r.milestoneBonusAwarded && r.milestoneBonusAwarded > 0 ? (
                                <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-extrabold">
                                  +₹{r.milestoneBonusAwarded} Milestone!
                                </span>
                              ) : (
                                <span className="text-zinc-600 text-[11px]">-</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
        {activeTab === 'vip' && (
          <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-200">
            {/* VIP Banner */}
            <div className="relative rounded-3xl overflow-hidden border border-amber-500/30 bg-gradient-to-r from-amber-950/80 via-zinc-900 to-zinc-950 p-8 shadow-2xl space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-200 text-black font-black flex items-center justify-center text-xl shadow-lg shadow-amber-500/30">
                  👑
                </div>
                <div>
                  <h2 className="text-2xl font-black text-amber-300 tracking-tight">VIP Esports Pass</h2>
                  <p className="text-xs text-amber-200/80">Unlock Pro Gamer Perks, Discounts, and Gold Name Badges!</p>
                </div>
              </div>

              {userProfile?.isVip ? (
                <div className="p-4 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-200 text-xs font-bold flex items-center gap-2">
                  <Crown className="w-5 h-5 text-amber-400" />
                  <span>Your VIP Pass is ACTIVE! Enjoy 10% auto-discounts on all tournament entry fees.</span>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  <div className="p-6 rounded-2xl bg-zinc-950/80 border border-zinc-800 space-y-4">
                    <div>
                      <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400">WEEKLY PASS</span>
                      <h3 className="text-2xl font-black text-white mt-1">₹49 <span className="text-xs text-zinc-400 font-normal">/ week</span></h3>
                    </div>
                    <ul className="text-xs text-zinc-300 space-y-2">
                      <li className="flex items-center gap-2">✓ 10% Extra Discount on all tournaments</li>
                      <li className="flex items-center gap-2">✓ Crown 👑 Badge on Leaderboards</li>
                      <li className="flex items-center gap-2">✓ Priority Room Credentials Notification</li>
                    </ul>
                    <button
                      onClick={() => handleBuyVip('WEEKLY')}
                      disabled={buyingVipLoading}
                      className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition shadow-lg shadow-amber-500/20 cursor-pointer"
                    >
                      {buyingVipLoading ? 'Processing...' : 'Buy Weekly Pass (₹49)'}
                    </button>
                  </div>

                  <div className="p-6 rounded-2xl bg-gradient-to-b from-amber-500/10 to-zinc-950 border border-amber-500/40 space-y-4 relative">
                    <span className="absolute top-3 right-3 text-[9px] font-extrabold px-2 py-0.5 rounded bg-amber-500 text-black">BEST VALUE</span>
                    <div>
                      <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">MONTHLY PASS</span>
                      <h3 className="text-2xl font-black text-white mt-1">₹149 <span className="text-xs text-zinc-400 font-normal">/ month</span></h3>
                    </div>
                    <ul className="text-xs text-zinc-300 space-y-2">
                      <li className="flex items-center gap-2">✓ 10% Extra Discount on all tournaments</li>
                      <li className="flex items-center gap-2">✓ Gold Crown 👑 Profile Badge</li>
                      <li className="flex items-center gap-2">✓ Guaranteed Slot Reservation</li>
                      <li className="flex items-center gap-2">✓ Dedicated VIP Support Desk</li>
                    </ul>
                    <button
                      onClick={() => handleBuyVip('MONTHLY')}
                      disabled={buyingVipLoading}
                      className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-zinc-950 font-bold text-xs transition shadow-lg shadow-amber-500/30 cursor-pointer"
                    >
                      {buyingVipLoading ? 'Processing...' : 'Buy Monthly Pass (₹149)'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* 3. JOIN TOURNAMENT MODAL */}
      {selectedTournament && (
        <div
          id="modal-join-tournament-overlay"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
          onClick={() => setSelectedTournament(null)}
        >
          <div
            id="modal-join-tournament-card"
            className="w-full max-w-lg bg-[#0F1115] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30">
                  {selectedTournament.type} • {selectedTournament.map}
                </span>
                <h3 className="text-lg font-black text-white mt-1">
                  Join {selectedTournament.name}
                </h3>
              </div>
              <button
                onClick={() => setSelectedTournament(null)}
                className="text-zinc-500 hover:text-white p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {joinError && (
              <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                <span>{joinError}</span>
              </div>
            )}

            {joinSuccess && (
              <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                <span>{joinSuccess}</span>
              </div>
            )}

            <div className="space-y-4">
              {/* Saved Squad Selector */}
              {mySquads.length > 0 && (
                <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 space-y-1.5">
                  <span className="text-[10px] font-extrabold uppercase text-amber-400">⚡ Fast Auto-Fill from Saved Squads</span>
                  <select
                    onChange={(e) => {
                      const sq = mySquads.find((s) => s.id === e.target.value);
                      if (sq) handleSelectSquadForJoin(sq);
                    }}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-amber-500/30 text-xs text-amber-200 font-bold"
                  >
                    <option value="">Choose a saved squad to auto-fill roster...</option>
                    {mySquads.map((sq) => (
                      <option key={sq.id} value={sq.id}>{sq.teamName} [{sq.teamTag || 'No Tag'}] ({sq.members?.length || 0} members)</option>
                    ))}
                  </select>
                </div>
              )}

              {userProfile?.isVip && (
                <div className="p-2.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-bold flex items-center justify-between">
                  <span className="flex items-center gap-1">👑 VIP Pass Active</span>
                  <span className="text-emerald-400 font-extrabold">+10% EXTRA DISCOUNT APPLIED</span>
                </div>
              )}

              <div>
                <label className="block text-[11px] font-bold uppercase text-zinc-400 mb-1">
                  Team / Squad Name *
                </label>
                <input
                  type="text"
                  required
                  value={joinTeamName}
                  onChange={(e) => setJoinTeamName(e.target.value)}
                  placeholder="e.g. Royal Warriors"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white focus:border-amber-500 focus:outline-none"
                />
              </div>

              {/* Roster Inputs */}
              <div className="space-y-2.5">
                <label className="block text-[11px] font-bold uppercase text-zinc-400">
                  Player Roster ({joinPlayers.length} Players)
                </label>
                {joinPlayers.map((p, idx) => (
                  <div key={idx} className="p-3 rounded-xl bg-zinc-950 border border-zinc-800/80 space-y-2">
                    <p className="text-[10px] font-bold uppercase text-amber-400">
                      Player #{idx + 1} {idx === 0 ? '(Team Leader)' : ''}
                    </p>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        required
                        value={p.ign}
                        onChange={(e) => {
                          const updated = [...joinPlayers];
                          updated[idx].ign = e.target.value;
                          setJoinPlayers(updated);
                        }}
                        placeholder="In-Game Name (IGN)"
                        className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-600 focus:border-amber-500 focus:outline-none"
                      />
                      <input
                        type="text"
                        required
                        value={p.ffUid}
                        onChange={(e) => {
                          const updated = [...joinPlayers];
                          updated[idx].ffUid = e.target.value;
                          setJoinPlayers(updated);
                        }}
                        placeholder="Free Fire UID"
                        className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-600 focus:border-amber-500 focus:outline-none"
                      />
                    </div>
                  </div>
                ))}
              </div>

              {/* Coupon Code input */}
              <div className="pt-2">
                <label className="block text-[11px] font-bold uppercase text-zinc-400 mb-1">
                  Have a Promo / Discount Coupon?
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={couponCodeInput}
                    onChange={(e) => setCouponCodeInput(e.target.value)}
                    placeholder="Enter Coupon Code"
                    className="flex-1 px-3.5 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white uppercase focus:border-amber-500 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleApplyCoupon}
                    className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-white transition cursor-pointer"
                  >
                    Apply
                  </button>
                </div>
                {appliedCoupon && (
                  <p className="text-xs text-emerald-400 mt-1 font-bold">
                    ✓ Coupon "{appliedCoupon.code}" applied!
                  </p>
                )}
              </div>

              {/* Price Breakdown */}
              <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-2 text-xs">
                <div className="flex justify-between text-zinc-400">
                  <span>Entry Fee</span>
                  <span>₹{selectedTournament.entryFee}</span>
                </div>
                {appliedCoupon && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Discount</span>
                    <span>
                      -₹
                      {appliedCoupon.discountType === 'PERCENTAGE'
                        ? (selectedTournament.entryFee * appliedCoupon.discountValue) / 100
                        : appliedCoupon.discountValue}
                    </span>
                  </div>
                )}
                <div className="flex justify-between text-white font-bold pt-1 border-t border-zinc-800 text-sm">
                  <span>Payable from Wallet</span>
                  <span className="text-amber-400 font-mono">
                    ₹
                    {Math.max(
                      0,
                      selectedTournament.entryFee -
                        (appliedCoupon
                          ? appliedCoupon.discountType === 'PERCENTAGE'
                            ? (selectedTournament.entryFee * appliedCoupon.discountValue) / 100
                            : appliedCoupon.discountValue
                          : 0)
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-[11px] text-zinc-500 pt-1">
                  <span>Your Current Wallet Balance</span>
                  <span className="font-mono">₹{wallet?.availableBalance ?? 0}</span>
                </div>
              </div>

              <button
                type="button"
                disabled={joining}
                onClick={handleConfirmJoin}
                className="w-full py-3.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs transition shadow-lg shadow-amber-500/25 active:scale-98 cursor-pointer disabled:opacity-50"
              >
                {joining ? 'Processing Registration...' : 'Confirm & Join Tournament'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. DEPOSIT PAYMENT MODAL (Dynamic QR Code + Screenshot Upload + UTR Number) */}
      <DepositPaymentModal
        isOpen={isDepositModalOpen}
        onClose={() => setIsDepositModalOpen(false)}
        initialAmount={depositModalInitialAmount}
        websiteSettings={websiteSettings}
        currentUser={currentUser}
        userProfile={userProfile}
        onSuccess={() => {
          // Switch to wallet tab to view deposit status
          setActiveTab('wallet');
        }}
      />

      {/* 5. SCREENSHOT PROOF FULLSCREEN PREVIEW MODAL */}
      {previewProofUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in">
          <div className="relative max-w-2xl w-full bg-zinc-900 border border-zinc-800 rounded-3xl p-6 shadow-2xl flex flex-col items-center space-y-4">
            <div className="w-full flex items-center justify-between">
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <QrCode className="w-4 h-4 text-emerald-400" />
                <span>Payment Screenshot Proof</span>
              </h3>
              <button
                type="button"
                onClick={() => setPreviewProofUrl(null)}
                className="px-3 py-1 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-white transition cursor-pointer"
              >
                Close
              </button>
            </div>
            <div className="w-full max-h-[70vh] overflow-auto rounded-2xl border border-zinc-800 bg-black flex items-center justify-center p-2">
              <img
                src={previewProofUrl}
                alt="Payment Proof Full"
                className="max-h-[65vh] w-auto object-contain rounded-xl"
              />
            </div>
          </div>
        </div>
      )}

      {/* 6. PLAYER AUTH MODAL (Google / Email & Password / 🌐 Admin) */}
      <PlayerAuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authModalInitialMode}
        onAdminLoginSuccess={() => {
          onOpenAdminPanel();
        }}
      />

      {/* 7. FULL TOURNAMENT DETAILS MODAL */}
      {viewingDetailsTournament && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in overflow-y-auto">
          <div className="relative max-w-2xl w-full bg-[#0F1115] border border-zinc-800 rounded-3xl shadow-2xl overflow-hidden my-8 space-y-0">
            {/* Header / Banner Area */}
            <div className="relative bg-gradient-to-r from-amber-600/30 via-amber-500/10 to-zinc-950 p-6 sm:p-8 border-b border-zinc-800 space-y-4">
              <button
                type="button"
                onClick={() => setViewingDetailsTournament(null)}
                className="absolute top-4 right-4 p-2 rounded-2xl bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-700 text-zinc-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[10px] font-black px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase tracking-widest font-mono">
                  {viewingDetailsTournament.type} • {viewingDetailsTournament.map || 'Bermuda'}
                </span>
                <span
                  className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                    viewingDetailsTournament.status === 'Registration Open'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : viewingDetailsTournament.status === 'Live'
                      ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30 animate-pulse'
                      : 'bg-zinc-800 text-zinc-400'
                  }`}
                >
                  {viewingDetailsTournament.status}
                </span>
              </div>

              <div>
                <h2 className="text-xl sm:text-2xl font-black text-white leading-tight">
                  {viewingDetailsTournament.name}
                </h2>
                <div className="flex items-center gap-2 text-xs text-zinc-400 mt-2 flex-wrap">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-amber-400" />
                    {viewingDetailsTournament.matchSchedule
                      ? new Date(viewingDetailsTournament.matchSchedule).toLocaleString([], {
                          weekday: 'short',
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })
                      : 'Schedule To Be Announced'}
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-amber-400" />
                    {viewingDetailsTournament.map || 'Bermuda'}
                  </span>
                </div>
              </div>
            </div>

            {/* Modal Scrollable Body */}
            <div className="p-6 sm:p-8 space-y-6 max-h-[60vh] overflow-y-auto">
              {/* Prize & Fee Highlights Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 text-center">
                  <p className="text-[10px] font-bold uppercase text-zinc-500">Total Prize Pool</p>
                  <p className="text-lg font-black text-amber-400 font-mono mt-0.5">
                    ₹{viewingDetailsTournament.prizePool}
                  </p>
                </div>
                <div className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 text-center">
                  <p className="text-[10px] font-bold uppercase text-zinc-500">Per Kill Prize</p>
                  <p className="text-lg font-black text-emerald-400 font-mono mt-0.5">
                    +₹{viewingDetailsTournament.perKillPrize || 0}
                  </p>
                </div>
                <div className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 text-center">
                  <p className="text-[10px] font-bold uppercase text-zinc-500">Entry Fee</p>
                  <p className="text-lg font-black text-white font-mono mt-0.5">
                    {viewingDetailsTournament.entryFee === 0 ? 'FREE' : `₹${viewingDetailsTournament.entryFee}`}
                  </p>
                </div>
                <div className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 text-center">
                  <p className="text-[10px] font-bold uppercase text-zinc-500">Format Mode</p>
                  <p className="text-lg font-black text-amber-300 font-mono mt-0.5">
                    {viewingDetailsTournament.type}
                  </p>
                </div>
              </div>

              {/* Live Countdown Timer in Modal */}
              <TournamentTimer tournament={viewingDetailsTournament} variant="modal" themeColor={currentTheme} />

              {/* Slot Progress Bar */}
              <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-400 flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-amber-400" />
                    <span>Slot Telemetry</span>
                  </span>
                  <span className="font-mono text-zinc-300 font-bold">
                    <b className="text-amber-400">{viewingDetailsTournament.currentRegistrations || 0}</b> / {viewingDetailsTournament.maxTeams || 48} Teams Joined
                  </span>
                </div>
                <div className="w-full h-2.5 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-amber-400 rounded-full transition-all"
                    style={{
                      width: `${Math.min(
                        100,
                        Math.round(
                          ((viewingDetailsTournament.currentRegistrations || 0) / (viewingDetailsTournament.maxTeams || 48)) * 100
                        )
                      )}%`,
                    }}
                  />
                </div>
                <p className="text-[11px] text-zinc-500 text-right font-medium">
                  {Math.max(0, (viewingDetailsTournament.maxTeams || 48) - (viewingDetailsTournament.currentRegistrations || 0))} slots remaining
                </p>
              </div>

              {/* Tournament Description / Rules */}
              <div className="space-y-3">
                <h4 className="text-sm font-black text-white flex items-center gap-2">
                  <FileText className="w-4 h-4 text-amber-400" />
                  <span>Tournament Description & Rules</span>
                </h4>

                {viewingDetailsTournament.description && (
                  <p className="text-xs text-zinc-300 bg-zinc-950/80 p-4 rounded-2xl border border-zinc-800/80 leading-relaxed">
                    {viewingDetailsTournament.description}
                  </p>
                )}

                <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-2 text-xs text-zinc-300 leading-relaxed">
                  <div className="flex items-start gap-2">
                    <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <p>
                      <strong className="text-white">Fair Play Policy:</strong> Any use of hacks, script APKs, or teaming up will lead to immediate disqualification and permanent ban.
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Radio className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <p>
                      <strong className="text-white">Room ID & Password:</strong> Published 15 minutes before match schedule inside the <span className="text-amber-400 font-bold">"My Matches"</span> tab.
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Award className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <p>
                      <strong className="text-white">Prize Distribution:</strong> Winnings for match kills and rank finishes are automatically credited directly to your website wallet after admin verification.
                    </p>
                  </div>
                </div>
              </div>

              {/* Custom Rank Prize Breakdown if configured */}
              {viewingDetailsTournament.rules && (
                <div className="space-y-2">
                  <h4 className="text-sm font-black text-white flex items-center gap-2">
                    <Trophy className="w-4 h-4 text-amber-400" />
                    <span>Additional Match Rules</span>
                  </h4>
                  <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 text-xs text-zinc-300 whitespace-pre-wrap leading-relaxed">
                    {viewingDetailsTournament.rules}
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer / Action CTA */}
            <div className="p-6 bg-zinc-950 border-t border-zinc-800 flex items-center justify-between gap-4">
              <button
                type="button"
                onClick={() => setViewingDetailsTournament(null)}
                className="px-5 py-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-bold text-xs border border-zinc-800 transition cursor-pointer"
              >
                Close
              </button>

              {viewingDetailsTournament.status === 'Registration Open' ? (
                myRegistrations.some(
                  (r) => r.tournamentId === viewingDetailsTournament.id && r.status !== 'Rejected' && r.status !== 'Cancelled'
                ) ? (
                  <button
                    type="button"
                    onClick={() => {
                      setViewingDetailsTournament(null);
                      setActiveTab('mymatches');
                    }}
                    className="flex-1 py-3 px-5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Already Joined ✅ (View Room)</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={(viewingDetailsTournament.currentRegistrations || 0) >= (viewingDetailsTournament.maxTeams || 48)}
                    onClick={() => {
                      const tourney = viewingDetailsTournament;
                      setViewingDetailsTournament(null);
                      handleOpenJoinModal(tourney);
                    }}
                    className={`flex-1 py-3 px-5 rounded-xl ${THEME_CONFIG[currentTheme].btnBg} font-black text-xs transition shadow-lg active:scale-98 cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2`}
                  >
                    <span>
                      {(viewingDetailsTournament.currentRegistrations || 0) >= (viewingDetailsTournament.maxTeams || 48)
                        ? 'Slots Filled'
                        : `Join Now (${viewingDetailsTournament.entryFee === 0 ? 'FREE' : `₹${viewingDetailsTournament.entryFee}`})`}
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )
              ) : viewingDetailsTournament.status === 'Live' ? (
                <button
                  type="button"
                  onClick={() => {
                    setViewingDetailsTournament(null);
                    setActiveTab('mymatches');
                  }}
                  className="flex-1 py-3 px-5 rounded-xl bg-rose-500 hover:bg-rose-400 text-white font-bold text-xs transition shadow-lg shadow-rose-500/20 cursor-pointer flex items-center justify-center gap-2"
                >
                  <Radio className="w-4 h-4 animate-pulse" />
                  <span>Go to My Matches & View Room</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setViewingDetailsTournament(null);
                    setActiveTab('leaderboard');
                  }}
                  className="flex-1 py-3 px-5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>View Match Leaderboard</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 5. SQUAD MODAL */}
      {isSquadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-lg bg-[#0F1115] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-black text-white">
                {editingSquad.id ? 'Edit Squad Roster' : 'Create New Squad'}
              </h3>
              <button onClick={() => setIsSquadModalOpen(false)} className="text-zinc-500 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleSaveSquad} className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <label className="block text-[10px] font-bold uppercase text-zinc-400 mb-1">Squad Name *</label>
                  <input
                    type="text"
                    required
                    value={editingSquad.teamName || ''}
                    onChange={(e) => setEditingSquad({ ...editingSquad, teamName: e.target.value })}
                    placeholder="e.g. Total Gaming"
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase text-zinc-400 mb-1">Team Tag</label>
                  <input
                    type="text"
                    value={editingSquad.teamTag || ''}
                    onChange={(e) => setEditingSquad({ ...editingSquad, teamTag: e.target.value })}
                    placeholder="TG"
                    className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <span className="text-[11px] font-bold uppercase text-amber-400">Roster Teammates (Up to 4 Players)</span>
                {editingSquad.members?.map((m, idx) => (
                  <div key={idx} className="p-3 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-2">
                    <span className="text-[10px] font-extrabold text-zinc-400">Player #{idx + 1} ({m.role})</span>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        placeholder="In-Game Name (IGN)"
                        value={m.ign}
                        onChange={(e) => {
                          const updated = [...(editingSquad.members || [])];
                          updated[idx].ign = e.target.value;
                          setEditingSquad({ ...editingSquad, members: updated });
                        }}
                        className="px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-white"
                      />
                      <input
                        type="text"
                        placeholder="Free Fire UID"
                        value={m.ffUid}
                        onChange={(e) => {
                          const updated = [...(editingSquad.members || [])];
                          updated[idx].ffUid = e.target.value;
                          setEditingSquad({ ...editingSquad, members: updated });
                        }}
                        className="px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-white font-mono"
                      />
                    </div>
                  </div>
                ))}
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition shadow-lg shadow-amber-500/20 cursor-pointer"
              >
                Save Squad Roster
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 6. MENU OPTIONS DRAWER (All Options & Theme Settings inside here) */}
      {isMenuDrawerOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-[#0F1115] border-l border-zinc-800 h-full p-5 sm:p-6 shadow-2xl overflow-y-auto space-y-5 flex flex-col justify-between">
            <div className="space-y-5">
              {/* Header */}
              <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
                <div className="flex items-center gap-2.5">
                  <div className={`w-9 h-9 rounded-xl bg-gradient-to-tr ${THEME_CONFIG[currentTheme].headerGradient} p-0.5 flex items-center justify-center`}>
                    <div className="w-full h-full bg-zinc-950 rounded-[10px] flex items-center justify-center">
                      <Gamepad2 className={`w-4 h-4 ${THEME_CONFIG[currentTheme].textAccent}`} />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-white font-mono uppercase tracking-wider">Esports Menu</h3>
                    <p className="text-[10px] text-zinc-400">Navigation & Themes</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsMenuDrawerOpen(false)}
                  className="w-8 h-8 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white flex items-center justify-center transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Theme Customizer Section */}
              <div className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800/80 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Palette className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">Esports Color Theme</span>
                  </div>
                  <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded ${THEME_CONFIG[currentTheme].badgeBg}`}>
                    {THEME_CONFIG[currentTheme].name}
                  </span>
                </div>
                <div className="grid grid-cols-5 gap-1.5 pt-1">
                  {[
                    { id: 'amber', color: 'bg-amber-500', name: 'Gold' },
                    { id: 'emerald', color: 'bg-emerald-500', name: 'Emerald' },
                    { id: 'cyan', color: 'bg-cyan-500', name: 'Cyan' },
                    { id: 'purple', color: 'bg-purple-500', name: 'Purple' },
                    { id: 'rose', color: 'bg-rose-500', name: 'Rose' },
                  ].map((t) => (
                    <button
                      key={t.id}
                      onClick={() => handleSetTheme(t.id as any)}
                      className={`p-2 rounded-xl flex flex-col items-center justify-center gap-1 transition cursor-pointer border ${
                        currentTheme === t.id
                          ? 'border-white bg-zinc-800 scale-105 shadow-md'
                          : 'border-zinc-800 bg-zinc-900/80 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <div className={`w-3.5 h-3.5 rounded-full ${t.color}`} />
                      <span className="text-[9px] font-bold text-zinc-300">{t.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* AI Support Launch Banner */}
              <div
                onClick={() => {
                  setIsMenuDrawerOpen(false);
                  setIsAIChatOpen(true);
                }}
                className="p-3.5 rounded-2xl bg-gradient-to-r from-cyan-950/80 via-zinc-900 to-indigo-950/80 border border-cyan-500/40 hover:border-cyan-400 transition cursor-pointer space-y-1 shadow-lg shadow-cyan-500/10 group"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Bot className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition" />
                    <span className="text-xs font-black text-white">AI Support Chat Spot</span>
                  </div>
                  <span className="px-1.5 py-0.2 rounded bg-cyan-400 text-black font-extrabold text-[9px] uppercase">
                    24/7 BOT
                  </span>
                </div>
                <p className="text-[10px] text-cyan-200/80 leading-snug">
                  Ask AI about Room IDs, Withdrawals, Rules, or Google Play codes!
                </p>
              </div>

              {/* Navigation Options List */}
              <div className="space-y-1.5 pt-1">
                <span className="text-[10px] font-bold uppercase text-zinc-500 tracking-wider block px-1">
                  Menu Options
                </span>
                {[
                  { id: 'tournaments', label: 'Tournaments Hub', icon: Trophy, color: 'text-amber-400' },
                  { id: 'profile', label: 'My Profile & Account', icon: User, color: 'text-zinc-300' },
                  { id: 'mymatches', label: 'My Joined Matches', icon: Flame, color: 'text-rose-400', badge: myRegistrations.length },
                  { id: 'wallet', label: 'Wallet & Withdrawals', icon: Wallet, color: 'text-emerald-400', info: `₹${wallet?.availableBalance ?? 0}` },
                  { id: 'squads', label: 'Squads & Rosters', icon: Users, color: 'text-cyan-400' },
                  { id: 'proofs', label: 'Upload Match Proofs', icon: Upload, color: 'text-amber-300' },
                  { id: 'vip', label: 'VIP Pass Membership', icon: Crown, color: 'text-amber-400' },
                  { id: 'referral', label: 'Refer & Earn Cash', icon: Gift, color: 'text-emerald-400' },
                  { id: 'leaderboard', label: 'Esports Leaderboard', icon: Award, color: 'text-purple-400' },
                  { id: 'support', label: 'WhatsApp Support', icon: HelpCircle, color: 'text-cyan-300' },
                ].map((item) => {
                  const IconComp = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveTab(item.id as any);
                        setIsMenuDrawerOpen(false);
                      }}
                      className={`w-full p-2.5 rounded-2xl flex items-center justify-between transition cursor-pointer border ${
                        isActive
                          ? `${THEME_CONFIG[currentTheme].badgeBg} bg-zinc-900 font-black`
                          : 'bg-zinc-950/60 border-zinc-800/80 text-zinc-300 hover:bg-zinc-900 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <IconComp className={`w-4 h-4 ${item.color}`} />
                        <span className="text-xs font-bold">{item.label}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {item.badge !== undefined && item.badge > 0 && (
                          <span className="px-1.5 py-0.2 rounded-full bg-emerald-500 text-black font-extrabold text-[10px]">
                            {item.badge}
                          </span>
                        )}
                        {item.info && (
                          <span className="text-xs font-mono font-black text-emerald-400">
                            {item.info}
                          </span>
                        )}
                        <ChevronRight className="w-3.5 h-3.5 text-zinc-600" />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-3 border-t border-zinc-800 text-center">
              <p className="text-[10px] text-zinc-500">FF Tournament Esports • AI Studio</p>
            </div>
          </div>
        </div>
      )}

      {/* 7. AI SUPPORT CHAT SPOT MODAL */}
      {isAIChatOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-lg bg-[#0F1115] border border-cyan-500/30 rounded-3xl shadow-2xl flex flex-col h-[85vh] sm:h-[600px] overflow-hidden">
            {/* Header */}
            <div className="p-4 bg-gradient-to-r from-cyan-950 via-zinc-950 to-zinc-950 border-b border-zinc-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shadow-md shadow-cyan-500/10">
                  <Bot className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-black text-white">FF Esports AI Assistant</h3>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[9px] font-bold">
                      ● ONLINE 24/7
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-400">Room IDs, Withdrawals, Rules & Help</p>
                </div>
              </div>
              <button
                onClick={() => setIsAIChatOpen(false)}
                className="w-8 h-8 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white flex items-center justify-center transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Helper Chips */}
            <div className="p-2.5 bg-zinc-950/80 border-b border-zinc-800 flex items-center gap-2 overflow-x-auto no-scrollbar">
              <span className="text-[10px] font-bold text-zinc-500 shrink-0 uppercase">Quick Ask:</span>
              {[
                '🔑 Where is my Room ID & Pass?',
                '💸 How to redeem Google Play Code?',
                '📸 How to upload kill proof?',
                '💳 How to deposit money via UPI?',
                '⚠️ Tournament fair play rules',
              ].map((chip) => (
                <button
                  key={chip}
                  onClick={() => handleSendAIChat(chip)}
                  className="px-2.5 py-1 rounded-full bg-zinc-900 hover:bg-cyan-500/20 text-zinc-300 hover:text-cyan-300 border border-zinc-800 text-[10px] font-bold whitespace-nowrap transition cursor-pointer shrink-0"
                >
                  {chip}
                </button>
              ))}
            </div>

            {/* Chat Messages */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-zinc-950/40">
              {aiChatMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex items-start gap-2.5 ${
                    msg.sender === 'user' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  {msg.sender === 'bot' && (
                    <div className="w-7 h-7 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shrink-0 mt-0.5 text-xs font-bold">
                      🤖
                    </div>
                  )}
                  <div
                    className={`max-w-[85%] p-3.5 rounded-2xl text-xs space-y-1 shadow-md ${
                      msg.sender === 'user'
                        ? 'bg-cyan-500 text-zinc-950 font-medium rounded-tr-none'
                        : 'bg-zinc-900 border border-zinc-800 text-zinc-200 rounded-tl-none leading-relaxed'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{msg.text}</p>
                    <span
                      className={`block text-[9px] text-right font-mono ${
                        msg.sender === 'user' ? 'text-zinc-900/70' : 'text-zinc-500'
                      }`}
                    >
                      {msg.time}
                    </span>
                  </div>
                  {msg.sender === 'user' && (
                    <div className="w-7 h-7 rounded-xl bg-amber-500 text-zinc-950 font-black flex items-center justify-center shrink-0 mt-0.5 text-xs">
                      {(userProfile?.ign || currentUser?.email || 'P')[0].toUpperCase()}
                    </div>
                  )}
                </div>
              ))}
              {aiChatLoading && (
                <div className="flex items-center gap-2 text-xs text-cyan-400 p-2.5 bg-cyan-950/30 rounded-2xl border border-cyan-500/20 max-w-[200px]">
                  <Bot className="w-4 h-4 animate-spin" />
                  <span>FF BOT is typing...</span>
                </div>
              )}
            </div>

            {/* Input Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendAIChat();
              }}
              className="p-3 bg-zinc-950 border-t border-zinc-800 flex items-center gap-2"
            >
              <input
                type="text"
                value={aiChatInput}
                onChange={(e) => setAiChatInput(e.target.value)}
                placeholder="Ask FF AI Support anything..."
                className="flex-1 px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:border-cyan-500 focus:outline-none transition"
              />
              <button
                type="submit"
                disabled={aiChatLoading || !aiChatInput.trim()}
                className="p-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-zinc-950 font-bold transition disabled:opacity-50 cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
