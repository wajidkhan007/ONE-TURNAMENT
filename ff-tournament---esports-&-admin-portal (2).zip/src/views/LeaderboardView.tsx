import React, { useEffect, useState } from 'react';
import {
  BarChart3,
  Plus,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  Search,
  Trophy,
  Flame,
  Award,
} from 'lucide-react';
import {
  getLeaderboards,
  saveLeaderboardEntry,
  deleteLeaderboardEntry,
  getTournaments,
  logAdminActivity,
} from '../services/adminService';
import { LeaderboardEntry, Tournament } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useAuth } from '../context/AuthContext';

export const LeaderboardView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedTourn, setSelectedTourn] = useState<string>('ALL');

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingEntry, setEditingEntry] = useState<Partial<LeaderboardEntry> | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const loadData = async () => {
    try {
      setLoading(true);
      const [leads, tours] = await Promise.all([getLeaderboards(), getTournaments()]);
      setEntries(leads);
      setTournaments(tours);
    } catch (err) {
      console.error('Error loading leaderboard:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleOpenCreate = () => {
    setEditingEntry({
      tournamentId: tournaments[0]?.id || '',
      matchNumber: 1,
      rank: entries.length + 1,
      teamName: '',
      playerNames: [''],
      captainFfUid: '',
      kills: 0,
      placementPoints: 12,
      prizeAmount: 0,
      isPublished: true,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (entry: LeaderboardEntry) => {
    setEditingEntry({ ...entry });
    setIsModalOpen(true);
  };

  const handleTogglePublish = async (entry: LeaderboardEntry) => {
    try {
      const next = !entry.isPublished;
      await saveLeaderboardEntry({ id: entry.id, isPublished: next });
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          next ? 'PUBLISH_LEADERBOARD_ENTRY' : 'HIDE_LEADERBOARD_ENTRY',
          'leaderboards',
          `${next ? 'Published' : 'Hidden'} leaderboard rank #${entry.rank} (${entry.teamName})`,
          entry.id
        );
      }
      await loadData();
    } catch (err) {
      console.error('Error updating leaderboard publish status:', err);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEntry?.teamName?.trim()) {
      alert('Team Name is required');
      return;
    }

    try {
      await saveLeaderboardEntry(editingEntry);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          editingEntry.id ? 'EDIT_LEADERBOARD' : 'CREATE_LEADERBOARD',
          'leaderboards',
          `Saved leaderboard entry for Team: ${editingEntry.teamName} (Rank #${editingEntry.rank})`,
          editingEntry.id
        );
      }
      setIsModalOpen(false);
      setEditingEntry(null);
      await loadData();
    } catch (err) {
      console.error('Error saving leaderboard entry:', err);
      alert('Failed to save leaderboard score');
    }
  };

  const handleDelete = async () => {
    if (!deleteConfirmId) return;
    try {
      await deleteLeaderboardEntry(deleteConfirmId);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'DELETE_LEADERBOARD_ENTRY',
          'leaderboards',
          `Deleted leaderboard entry ${deleteConfirmId}`,
          deleteConfirmId
        );
      }
      setDeleteConfirmId(null);
      await loadData();
    } catch (err) {
      console.error('Error deleting leaderboard entry:', err);
    }
  };

  const filteredEntries = entries.filter((e) => {
    if (selectedTourn === 'ALL') return true;
    return e.tournamentId === selectedTourn;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-amber-400" />
            <span>Tournament Leaderboard & Points Table</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Manage match rankings, kills, placement points, and auto-calculate standings based on official Free Fire esports rules.
          </p>
        </div>
        <button
          id="btn-add-leaderboard-score"
          onClick={handleOpenCreate}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold transition shadow-lg shadow-amber-500/20 active:scale-95 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Score / Team</span>
        </button>
      </div>

      {/* Tournament Filter */}
      <div className="max-w-md">
        <select
          value={selectedTourn}
          onChange={(e) => setSelectedTourn(e.target.value)}
          className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 cursor-pointer"
        >
          <option value="ALL">All Tournaments ({entries.length} entries)</option>
          {tournaments.map((t) => (
            <option key={t.id} value={t.id}>
              {t.name}
            </option>
          ))}
        </select>
      </div>

      {/* Table */}
      {loading ? (
        <LoadingSpinner text="Fetching leaderboard records from Firestore..." />
      ) : filteredEntries.length === 0 ? (
        <EmptyState
          icon={BarChart3}
          title="No leaderboard entries found"
          description="There are currently no scores published for the selected tournament in Firebase."
          actionLabel="Add Score"
          onAction={handleOpenCreate}
        />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-zinc-800 bg-zinc-900/60 shadow-xl">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="border-b border-zinc-800 bg-zinc-950/80 text-[10px] uppercase font-bold text-zinc-400 tracking-wider">
              <tr>
                <th className="px-4 py-3.5">Rank</th>
                <th className="px-4 py-3.5">Team & Captain UID</th>
                <th className="px-4 py-3.5 text-center">Kills</th>
                <th className="px-4 py-3.5 text-center">Kill Pts</th>
                <th className="px-4 py-3.5 text-center">Place Pts</th>
                <th className="px-4 py-3.5 text-center">Total Points</th>
                <th className="px-4 py-3.5">Status</th>
                <th className="px-4 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60 font-mono">
              {filteredEntries.map((item) => (
                <tr key={item.id} className="hover:bg-zinc-800/40 transition">
                  <td className="px-4 py-3">
                    <span
                      className={`inline-flex items-center justify-center w-7 h-7 rounded-lg font-bold text-xs ${
                        item.rank === 1
                          ? 'bg-amber-500 text-zinc-950 shadow-md shadow-amber-500/20'
                          : item.rank === 2
                          ? 'bg-zinc-300 text-zinc-950'
                          : item.rank === 3
                          ? 'bg-amber-700 text-white'
                          : 'bg-zinc-800 text-zinc-400'
                      }`}
                    >
                      #{item.rank}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-sans">
                    <div className="font-bold text-white tracking-tight">{item.teamName}</div>
                    {item.captainFfUid && (
                      <div className="text-[11px] text-zinc-500 font-mono">UID: {item.captainFfUid}</div>
                    )}
                  </td>
                  <td className="px-4 py-3 text-center text-zinc-200 font-bold">{item.kills}</td>
                  <td className="px-4 py-3 text-center text-zinc-400">{item.killPoints}</td>
                  <td className="px-4 py-3 text-center text-zinc-400">{item.placementPoints}</td>
                  <td className="px-4 py-3 text-center text-amber-400 font-extrabold text-sm">
                    {item.totalPoints}
                  </td>
                  <td className="px-4 py-3 font-sans">
                    <button
                      onClick={() => handleTogglePublish(item)}
                      className={`text-[10px] font-bold px-2 py-0.5 rounded cursor-pointer ${
                        item.isPublished
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'bg-zinc-800 text-zinc-500'
                      }`}
                    >
                      {item.isPublished ? 'Published' : 'Hidden'}
                    </button>
                  </td>
                  <td className="px-4 py-3 text-right font-sans">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(item)}
                        className="p-1.5 rounded-lg text-amber-400 hover:bg-zinc-800 transition cursor-pointer"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setDeleteConfirmId(item.id)}
                        className="p-1.5 rounded-lg text-rose-400 hover:bg-zinc-800 transition cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Score Modal */}
      {isModalOpen && editingEntry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl border border-zinc-800 bg-zinc-900 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white">
              {editingEntry.id ? 'Edit Leaderboard Score' : 'Add Team Score'}
            </h3>

            <form onSubmit={handleSave} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Tournament</label>
                <select
                  value={editingEntry.tournamentId || ''}
                  onChange={(e) => setEditingEntry({ ...editingEntry, tournamentId: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
                >
                  {tournaments.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Rank</label>
                  <input
                    type="number"
                    min={1}
                    value={editingEntry.rank ?? 1}
                    onChange={(e) => setEditingEntry({ ...editingEntry, rank: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-sm text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Match #</label>
                  <input
                    type="number"
                    min={1}
                    value={editingEntry.matchNumber ?? 1}
                    onChange={(e) => setEditingEntry({ ...editingEntry, matchNumber: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-sm text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Team Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Total Gaming Esports"
                  value={editingEntry.teamName || ''}
                  onChange={(e) => setEditingEntry({ ...editingEntry, teamName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Captain UID (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. 19284012"
                  value={editingEntry.captainFfUid || ''}
                  onChange={(e) => setEditingEntry({ ...editingEntry, captainFfUid: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Kills</label>
                  <input
                    type="number"
                    min={0}
                    value={editingEntry.kills ?? 0}
                    onChange={(e) => setEditingEntry({ ...editingEntry, kills: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-sm text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">Placement Points</label>
                  <input
                    type="number"
                    min={0}
                    value={editingEntry.placementPoints ?? 0}
                    onChange={(e) => setEditingEntry({ ...editingEntry, placementPoints: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-sm text-white font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="chk-lead-publish"
                  checked={editingEntry.isPublished || false}
                  onChange={(e) => setEditingEntry({ ...editingEntry, isPublished: e.target.checked })}
                  className="w-4 h-4 rounded text-amber-500 border-zinc-700 bg-zinc-900 cursor-pointer"
                />
                <label htmlFor="chk-lead-publish" className="text-xs text-zinc-300 cursor-pointer">
                  Publish to public leaderboard immediately
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-zinc-700 text-xs font-semibold text-zinc-300 hover:bg-zinc-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow-lg shadow-amber-500/20 cursor-pointer"
                >
                  Save Score
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmationModal
        isOpen={!!deleteConfirmId}
        title="Delete Leaderboard Entry"
        message="Are you sure you want to delete this leaderboard score?"
        isDangerous
        onConfirm={handleDelete}
        onCancel={() => setDeleteConfirmId(null)}
      />
    </div>
  );
};
