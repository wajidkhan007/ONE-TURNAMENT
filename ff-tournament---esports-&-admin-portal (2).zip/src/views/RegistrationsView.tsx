import React, { useEffect, useState } from 'react';
import {
  Users,
  Search,
  CheckCircle2,
  XCircle,
  Clock,
  Download,
  Eye,
  Trash2,
  Phone,
  Mail,
  ShieldAlert,
  ExternalLink,
} from 'lucide-react';
import {
  getRegistrations,
  updateRegistrationStatus,
  deleteRegistration,
  getTournaments,
  exportToCsv,
  logAdminActivity,
} from '../services/adminService';
import { Registration, Tournament, RegistrationStatus } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useAuth } from '../context/AuthContext';

export const RegistrationsView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');
  const [tournFilter, setTournFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Drawer / modal states
  const [selectedReg, setSelectedReg] = useState<Registration | null>(null);
  const [rejectModalId, setRejectModalId] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const loadData = async () => {
    try {
      setLoading(true);
      const [regsData, toursData] = await Promise.all([
        getRegistrations(),
        getTournaments(),
      ]);
      setRegistrations(regsData);
      setTournaments(toursData);
    } catch (err) {
      console.error('Error loading registrations:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleApprove = async (reg: Registration) => {
    try {
      await updateRegistrationStatus(reg.id, 'Approved', adminProfile?.email || 'admin');
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'APPROVE_REGISTRATION',
          'registrations',
          `Approved registration for Team: ${reg.teamName} in ${reg.tournamentName}`,
          reg.id
        );
      }
      await loadData();
    } catch (err) {
      console.error('Error approving registration:', err);
    }
  };

  const handleRejectConfirm = async (reason?: string) => {
    if (!rejectModalId) return;
    try {
      const reg = registrations.find((r) => r.id === rejectModalId);
      await updateRegistrationStatus(rejectModalId, 'Rejected', adminProfile?.email || 'admin', reason);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'REJECT_REGISTRATION',
          'registrations',
          `Rejected registration for Team: ${reg?.teamName || rejectModalId}. Reason: ${reason || 'N/A'}`,
          rejectModalId
        );
      }
      setRejectModalId(null);
      await loadData();
    } catch (err) {
      console.error('Error rejecting registration:', err);
    }
  };

  const handleDelete = async () => {
    if (!deleteConfirmId) return;
    try {
      await deleteRegistration(deleteConfirmId);
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'DELETE_REGISTRATION',
          'registrations',
          `Deleted registration ${deleteConfirmId}`,
          deleteConfirmId
        );
      }
      setDeleteConfirmId(null);
      await loadData();
    } catch (err) {
      console.error('Error deleting registration:', err);
    }
  };

  const handleExportCsv = () => {
    const rows = filteredRegistrations.map((r) => ({
      ID: r.id,
      Tournament: r.tournamentName,
      TeamName: r.teamName,
      CaptainName: r.captainName,
      CaptainEmail: r.captainEmail,
      CaptainPhone: r.captainPhone,
      CaptainFF_UID: r.captainFfUid,
      CaptainIGN: r.captainIgn,
      Format: r.type,
      EntryFeePaid: r.paidAmount || r.entryFee,
      PaymentMethod: r.paymentMethod,
      UTR: r.utrNumber || '',
      Status: r.status,
      RegistrationDate: new Date(r.registeredAt).toLocaleString(),
    }));
    exportToCsv('tournament_registrations', rows);
  };

  const filteredRegistrations = registrations.filter((r) => {
    const term = search.toLowerCase();
    const matchesSearch =
      r.teamName?.toLowerCase().includes(term) ||
      r.captainName?.toLowerCase().includes(term) ||
      r.captainFfUid?.toLowerCase().includes(term) ||
      r.captainIgn?.toLowerCase().includes(term) ||
      r.captainPhone?.includes(term) ||
      r.tournamentName?.toLowerCase().includes(term);
    const matchesTourn = tournFilter === 'ALL' || r.tournamentId === tournFilter;
    const matchesStatus = statusFilter === 'ALL' || r.status === statusFilter;
    return matchesSearch && matchesTourn && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-400" />
            <span>Registration Management</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Verify player Free Fire UIDs, in-game names, captain contacts, and approve/reject team registrations.
          </p>
        </div>
        <button
          id="btn-export-registrations-csv"
          onClick={handleExportCsv}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold border border-zinc-700 transition cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Filters & Search */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="input-search-registrations"
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search Captain, Team, UID, IGN, Phone..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div>
          <select
            value={tournFilter}
            onChange={(e) => setTournFilter(e.target.value)}
            className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 cursor-pointer"
          >
            <option value="ALL">All Tournaments</option>
            {tournaments.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 cursor-pointer"
          >
            <option value="ALL">All Statuses ({registrations.length})</option>
            <option value="Pending">Pending Approval</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <LoadingSpinner text="Fetching real registrations from Firestore..." />
      ) : filteredRegistrations.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No registrations found"
          description="There are currently no team registrations recorded for the selected filter in Firebase."
        />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-zinc-800 bg-zinc-900/60 shadow-xl">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="border-b border-zinc-800 bg-zinc-950/80 text-[10px] uppercase font-bold text-zinc-400 tracking-wider">
              <tr>
                <th className="px-4 py-3.5">Team & Captain</th>
                <th className="px-4 py-3.5">Free Fire UID / IGN</th>
                <th className="px-4 py-3.5">Tournament</th>
                <th className="px-4 py-3.5">Fee Paid</th>
                <th className="px-4 py-3.5">Status</th>
                <th className="px-4 py-3.5">Date</th>
                <th className="px-4 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60">
              {filteredRegistrations.map((r) => (
                <tr key={r.id} className="hover:bg-zinc-800/40 transition">
                  <td className="px-4 py-3">
                    <div className="font-bold text-white tracking-tight">{r.teamName || r.captainName}</div>
                    <div className="text-[11px] text-zinc-400 mt-0.5">{r.captainName} • {r.captainPhone}</div>
                  </td>
                  <td className="px-4 py-3 font-mono">
                    <div className="text-amber-400 font-bold">{r.captainFfUid || 'N/A'}</div>
                    <div className="text-[11px] text-zinc-400">{r.captainIgn || 'IGN Not Set'}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-zinc-200 font-medium truncate max-w-[180px]">{r.tournamentName}</div>
                    <div className="text-[10px] text-amber-400/80 font-mono font-semibold">{r.type}</div>
                  </td>
                  <td className="px-4 py-3 font-mono">
                    <span className="font-bold text-emerald-400">₹{r.paidAmount || r.entryFee}</span>
                    <span className="text-[10px] text-zinc-500 block">via {r.paymentMethod}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                        r.status === 'Approved'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : r.status === 'Rejected'
                          ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/20 animate-pulse'
                      }`}
                    >
                      {r.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-[11px] text-zinc-400 font-mono">
                    {new Date(r.registeredAt).toLocaleDateString()}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => setSelectedReg(r)}
                        title="View Full Roster"
                        className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      {r.status === 'Pending' && (
                        <>
                          <button
                            onClick={() => handleApprove(r)}
                            title="Approve Registration"
                            className="p-1.5 rounded-lg text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/20 transition cursor-pointer"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setRejectModalId(r.id)}
                            title="Reject Registration"
                            className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-500/20 transition cursor-pointer"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}
                      <button
                        onClick={() => setDeleteConfirmId(r.id)}
                        title="Delete Record"
                        className="p-1.5 rounded-lg text-zinc-500 hover:text-rose-400 hover:bg-zinc-800 transition cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Roster & Detail Modal */}
      {selectedReg && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-lg rounded-2xl border border-zinc-800 bg-zinc-900 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div>
                <h3 className="text-base font-bold text-white">{selectedReg.teamName}</h3>
                <p className="text-xs text-amber-400 font-mono">{selectedReg.tournamentName}</p>
              </div>
              <button
                onClick={() => setSelectedReg(null)}
                className="text-zinc-400 hover:text-white p-1 rounded-lg"
              >
                ✕
              </button>
            </div>

            {/* Captain Details */}
            <div className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-2">
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
                Captain / Leader
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-zinc-500 text-[10px]">Name:</span>
                  <p className="text-white font-semibold">{selectedReg.captainName}</p>
                </div>
                <div>
                  <span className="text-zinc-500 text-[10px]">Free Fire UID:</span>
                  <p className="text-amber-400 font-mono font-bold">{selectedReg.captainFfUid}</p>
                </div>
                <div>
                  <span className="text-zinc-500 text-[10px]">Phone:</span>
                  <p className="text-zinc-300 font-mono">{selectedReg.captainPhone}</p>
                </div>
                <div>
                  <span className="text-zinc-500 text-[10px]">In-Game Name (IGN):</span>
                  <p className="text-zinc-300 font-medium">{selectedReg.captainIgn}</p>
                </div>
              </div>
            </div>

            {/* Players Roster */}
            {selectedReg.players && selectedReg.players.length > 0 && (
              <div className="space-y-2">
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
                  Squad Players Roster ({selectedReg.players.length})
                </span>
                <div className="space-y-1.5 max-h-40 overflow-y-auto">
                  {selectedReg.players.map((p, idx) => (
                    <div
                      key={idx}
                      className="p-2 rounded-lg bg-zinc-950 border border-zinc-800/80 flex items-center justify-between text-xs font-mono"
                    >
                      <span className="text-zinc-300">{p.name || `Player ${idx + 1}`} ({p.ign})</span>
                      <span className="text-amber-400 font-bold">UID: {p.ffUid}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Payment & Status */}
            <div className="grid grid-cols-2 gap-2 p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-xs">
              <div>
                <span className="text-[10px] text-zinc-500">Payment Status:</span>
                <p className="font-bold text-emerald-400 font-mono">
                  ₹{selectedReg.paidAmount || selectedReg.entryFee} ({selectedReg.paymentMethod})
                </p>
                {selectedReg.utrNumber && (
                  <p className="text-[10px] text-zinc-400 mt-0.5">UTR: {selectedReg.utrNumber}</p>
                )}
              </div>
              <div>
                <span className="text-[10px] text-zinc-500">Registration Status:</span>
                <p className="font-bold text-amber-400 uppercase">{selectedReg.status}</p>
                {selectedReg.rejectionReason && (
                  <p className="text-[10px] text-rose-400 mt-0.5">Reason: {selectedReg.rejectionReason}</p>
                )}
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedReg(null)}
                className="px-4 py-2 rounded-xl bg-zinc-800 text-xs font-bold text-white hover:bg-zinc-700 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject with Reason Modal */}
      <ConfirmationModal
        isOpen={!!rejectModalId}
        title="Reject Registration"
        message="Please provide a clear reason for rejecting this team's registration (e.g., Invalid Free Fire UID, Payment UTR mismatch, Emulator detected)."
        confirmText="Reject Registration"
        isDangerous
        requireReason
        reasonPlaceholder="e.g. Invalid UID or payment screenshot not verified..."
        onConfirm={handleRejectConfirm}
        onCancel={() => setRejectModalId(null)}
      />

      {/* Delete Record Modal */}
      <ConfirmationModal
        isOpen={!!deleteConfirmId}
        title="Delete Registration Record"
        message="Are you sure you want to permanently delete this registration record from Firestore?"
        confirmText="Delete Record"
        isDangerous
        onConfirm={handleDelete}
        onCancel={() => setDeleteConfirmId(null)}
      />
    </div>
  );
};
