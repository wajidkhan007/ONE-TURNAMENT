import React, { useEffect, useState } from 'react';
import {
  ArrowUpCircle,
  Search,
  CheckCircle2,
  XCircle,
  Clock,
  Download,
  AlertCircle,
  CreditCard,
  Building,
  Smartphone,
  ExternalLink,
} from 'lucide-react';
import { getWithdrawals, updateWithdrawalStatus, logAdminActivity, exportToCsv } from '../services/adminService';
import { WithdrawalRequest, WithdrawalStatus } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { EmptyState } from '../components/EmptyState';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useAuth } from '../context/AuthContext';

export const WithdrawalsView: React.FC = () => {
  const { adminProfile, currentUser, role } = useAuth();
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Actions modal
  const [selectedReq, setSelectedReq] = useState<WithdrawalRequest | null>(null);
  const [markPaidReq, setMarkPaidReq] = useState<WithdrawalRequest | null>(null);
  const [payoutTxRef, setPayoutTxRef] = useState<string>('');
  const [rejectReqId, setRejectReqId] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<boolean>(false);

  const loadWithdrawals = async () => {
    try {
      setLoading(true);
      const data = await getWithdrawals();
      setWithdrawals(data);
    } catch (err) {
      console.error('Error loading withdrawals:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadWithdrawals();
  }, []);

  const handleSetStatus = async (
    requestId: string,
    newStatus: WithdrawalStatus,
    note?: string,
    txRef?: string
  ) => {
    const activeAdmin = adminProfile || (currentUser ? { id: currentUser.uid, email: currentUser.email || 'admin@ff.com', role: role || 'SUPER_ADMIN' } : null);
    if (!activeAdmin) {
      alert('Admin session not detected. Please sign in as admin again.');
      return;
    }
    setActionLoading(true);
    try {
      await updateWithdrawalStatus(
        requestId,
        newStatus,
        { id: activeAdmin.id, email: activeAdmin.email, role: activeAdmin.role },
        note,
        txRef
      );

      await logAdminActivity(
        { id: activeAdmin.id, email: activeAdmin.email, role: activeAdmin.role },
        'WITHDRAWAL_STATUS_CHANGE',
        'withdrawalRequests',
        `Changed withdrawal status to ${newStatus} (TxRef: ${txRef || 'N/A'})`,
        requestId
      );

      setMarkPaidReq(null);
      setRejectReqId(null);
      setPayoutTxRef('');
      await loadWithdrawals();
    } catch (err: any) {
      console.error('Error updating withdrawal status:', err);
      alert(err.message || 'Failed to update withdrawal status');
    } finally {
      setActionLoading(false);
    }
  };

  const handleMarkPaidConfirm = async () => {
    if (!markPaidReq) return;
    if (!payoutTxRef.trim()) {
      alert('Please enter the Banking/UPI Transaction Reference ID before marking as paid.');
      return;
    }
    await handleSetStatus(markPaidReq.id, 'Paid', `Payout sent via ${markPaidReq.payoutMethod}`, payoutTxRef);
  };

  const handleExportCsv = () => {
    const rows = filteredWithdrawals.map((w) => ({
      ID: w.id,
      UserEmail: w.userEmail,
      UserName: w.userName,
      Phone: w.phone,
      RequestedAmount: w.requestedAmount,
      Fee: w.feeAmount,
      NetAmount: w.netAmount,
      PayoutMethod: w.payoutMethod,
      UPI_ID: w.payoutDetails?.upiId || '',
      Bank_Account: w.payoutDetails?.accountNumber || '',
      IFSC: w.payoutDetails?.ifscCode || '',
      Status: w.status,
      TransactionRef: w.transactionRef || '',
      RequestDate: new Date(w.createdAt).toLocaleString(),
      ProcessedBy: w.processedBy || '',
    }));
    exportToCsv('withdrawal_requests', rows);
  };

  const filteredWithdrawals = withdrawals.filter((w) => {
    const term = search.toLowerCase();
    const matchesSearch =
      w.userEmail?.toLowerCase().includes(term) ||
      w.userName?.toLowerCase().includes(term) ||
      w.phone?.includes(term) ||
      w.payoutDetails?.upiId?.toLowerCase().includes(term);
    const matchesStatus = statusFilter === 'ALL' || w.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <ArrowUpCircle className="w-5 h-5 text-rose-400" />
            <span>Withdrawal Requests & Payout Control</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Process player prize cashouts, verify bank/UPI accounts, mark processed payouts, and manage refunds.
          </p>
        </div>
        <button
          id="btn-export-withdrawals-csv"
          onClick={handleExportCsv}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold border border-zinc-700 transition cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Filters & Search */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-xl">
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by User Email, Phone, UPI ID..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 cursor-pointer"
          >
            <option value="ALL">All Statuses ({withdrawals.length})</option>
            <option value="Pending">Pending</option>
            <option value="Processing">Processing</option>
            <option value="Approved">Approved</option>
            <option value="Paid">Paid (Completed)</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <LoadingSpinner text="Fetching withdrawal requests from Firestore..." />
      ) : filteredWithdrawals.length === 0 ? (
        <EmptyState
          icon={ArrowUpCircle}
          title="No withdrawal requests found"
          description="There are currently no player withdrawal requests recorded in Firebase."
        />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-zinc-800 bg-zinc-900/60 shadow-xl">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="border-b border-zinc-800 bg-zinc-950/80 text-[10px] uppercase font-bold text-zinc-400 tracking-wider">
              <tr>
                <th className="px-4 py-3.5">User & Contact</th>
                <th className="px-4 py-3.5">Net Payout</th>
                <th className="px-4 py-3.5">Payout Method & Details</th>
                <th className="px-4 py-3.5">Status</th>
                <th className="px-4 py-3.5">Date</th>
                <th className="px-4 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60">
              {filteredWithdrawals.map((w) => (
                <tr key={w.id} className="hover:bg-zinc-800/40 transition">
                  <td className="px-4 py-3">
                    <div className="font-bold text-white tracking-tight">{w.userEmail}</div>
                    <div className="text-[11px] text-zinc-400 mt-0.5">{w.userName} • {w.phone}</div>
                  </td>
                  <td className="px-4 py-3 font-mono">
                    <span className="font-bold text-rose-400 text-sm">₹{w.netAmount || w.requestedAmount}</span>
                    {w.feeAmount > 0 && (
                      <span className="text-[10px] text-zinc-500 block">Fee: ₹{w.feeAmount}</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1 text-zinc-200 font-bold">
                      <span className="px-1.5 py-0.5 rounded bg-zinc-800 text-[10px] text-amber-400 uppercase font-mono">
                        {w.payoutMethod}
                      </span>
                    </div>
                    <div className="text-[11px] text-zinc-300 font-mono mt-1">
                      {w.payoutMethod === 'REDEEM_CODE' ? (
                        <span className="text-emerald-400 font-bold">🎁 Google Play Code Request ({w.phone || w.userEmail})</span>
                      ) : w.payoutDetails?.upiId ? (
                        <span>UPI: {w.payoutDetails.upiId}</span>
                      ) : w.payoutDetails?.accountNumber ? (
                        <span>
                          Acc: {w.payoutDetails.accountNumber} ({w.payoutDetails.ifscCode})
                        </span>
                      ) : (
                        <span>{w.payoutDetails?.mobileNumber || 'No payout detail'}</span>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                        w.status === 'Paid'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : w.status === 'Processing'
                          ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                          : w.status === 'Rejected'
                          ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/20 animate-pulse'
                      }`}
                    >
                      {w.status}
                    </span>
                    {w.transactionRef && (
                      <span className="block text-[10px] text-zinc-500 font-mono mt-1">
                        Ref: {w.transactionRef}
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-[11px] text-zinc-400 font-mono">
                    {new Date(w.createdAt).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      {w.status === 'Pending' && (
                        <button
                          onClick={() => handleSetStatus(w.id, 'Processing', 'Admin started processing payout')}
                          className="px-2.5 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 font-bold text-xs border border-cyan-500/30 transition cursor-pointer"
                        >
                          Process
                        </button>
                      )}

                      {w.status !== 'Paid' && w.status !== 'Rejected' && (
                        <>
                          <button
                            onClick={() => setMarkPaidReq(w)}
                            className="px-2.5 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs transition cursor-pointer"
                          >
                            Mark Paid
                          </button>
                          <button
                            onClick={() => setRejectReqId(w.id)}
                            className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 font-bold text-xs border border-rose-500/30 transition cursor-pointer"
                          >
                            Reject & Refund
                          </button>
                        </>
                      )}

                      {w.status === 'Paid' && (
                        <span className="text-[11px] font-mono text-emerald-400 font-bold">✓ Completed</span>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Mark Paid Modal with Banking Reference ID */}
      {markPaidReq && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl border border-zinc-800 bg-zinc-900 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white">Record Payout Confirmation</h3>
            <p className="text-xs text-zinc-300">
              You are recording payout of <strong className="text-emerald-400">₹{markPaidReq.netAmount || markPaidReq.requestedAmount}</strong> to{' '}
              <strong>{markPaidReq.userEmail}</strong>.
            </p>

            <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-xs font-mono">
              <p className="text-zinc-400">Method: <span className="text-emerald-400 font-bold">{markPaidReq.payoutMethod === 'REDEEM_CODE' ? '🎁 Google Play Redeem Code' : markPaidReq.payoutMethod}</span></p>
              <p className="text-zinc-400 mt-1">Delivery Mobile/WhatsApp: <span className="text-amber-400 font-bold">{markPaidReq.phone || markPaidReq.userEmail}</span></p>
              {markPaidReq.payoutDetails?.upiId && (
                <p className="text-zinc-400 mt-1">UPI ID: <span className="text-amber-400">{markPaidReq.payoutDetails.upiId}</span></p>
              )}
              {markPaidReq.payoutDetails?.accountNumber && (
                <p className="text-zinc-400 mt-1">
                  Bank: <span className="text-white">{markPaidReq.payoutDetails.bankName}</span> • Acc: <span className="text-amber-400">{markPaidReq.payoutDetails.accountNumber}</span> (IFSC: {markPaidReq.payoutDetails.ifscCode})
                </p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1.5">
                {markPaidReq.payoutMethod === 'REDEEM_CODE' ? 'Google Play Redeem Code (16-Digit Code)' : 'Bank / UPI Transaction Reference (UTR)'} <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                placeholder={markPaidReq.payoutMethod === 'REDEEM_CODE' ? 'e.g. GPLAY-9812-4819-2810' : 'e.g. 420912384912'}
                value={payoutTxRef}
                onChange={(e) => setPayoutTxRef(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-sm text-amber-400 font-mono focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div className="flex justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={() => setMarkPaidReq(null)}
                className="px-4 py-2 rounded-xl border border-zinc-700 text-xs font-semibold text-zinc-300 hover:bg-zinc-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleMarkPaidConfirm}
                disabled={actionLoading}
                className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs shadow-lg shadow-emerald-500/20 cursor-pointer"
              >
                {actionLoading ? 'Saving...' : 'Confirm Paid'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject & Refund Modal */}
      <ConfirmationModal
        isOpen={!!rejectReqId}
        title="Reject Withdrawal & Refund Balance"
        message="Rejecting this withdrawal will automatically refund the requested amount back to the player's available wallet balance. Please specify the reason."
        confirmText="Reject & Refund"
        isDangerous
        requireReason
        isLoading={actionLoading}
        reasonPlaceholder="e.g. Incorrect UPI ID or Bank account name mismatch..."
        onConfirm={(reason) => handleSetStatus(rejectReqId!, 'Rejected', reason)}
        onCancel={() => setRejectReqId(null)}
      />
    </div>
  );
};
