import React, { useEffect, useState } from 'react';
import {
  Settings,
  QrCode,
  CreditCard,
  Mail,
  Instagram,
  Phone,
  MessageSquare,
  Save,
  CheckCircle2,
  FileText,
  HelpCircle,
  Plus,
  Trash2,
} from 'lucide-react';
import {
  getWebsiteSettings,
  saveWebsiteSettings,
  logAdminActivity,
} from '../services/adminService';
import { WebsiteSettings } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { useAuth } from '../context/AuthContext';

export const SettingsView: React.FC = () => {
  const { adminProfile, role } = useAuth();
  const [settings, setSettings] = useState<WebsiteSettings | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [success, setSuccess] = useState<boolean>(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const data = await getWebsiteSettings();
      setSettings(data);
    } catch (err) {
      console.error('Error loading settings:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    setSaving(true);
    setSuccess(false);
    try {
      await saveWebsiteSettings({
        ...settings,
        updatedBy: adminProfile?.email || 'admin',
      });
      if (adminProfile) {
        await logAdminActivity(
          { id: adminProfile.id, email: adminProfile.email, role },
          'UPDATE_SETTINGS',
          'websiteSettings',
          'Updated platform general and UPI payment credentials'
        );
      }
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      console.error('Error saving settings:', err);
      alert('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleAddFaq = () => {
    if (!settings) return;
    setSettings({
      ...settings,
      faqList: [...settings.faqList, { question: '', answer: '' }],
    });
  };

  const handleRemoveFaq = (index: number) => {
    if (!settings) return;
    const newFaq = [...settings.faqList];
    newFaq.splice(index, 1);
    setSettings({ ...settings, faqList: newFaq });
  };

  const handleFaqChange = (index: number, field: 'question' | 'answer', val: string) => {
    if (!settings) return;
    const newFaq = [...settings.faqList];
    newFaq[index][field] = val;
    setSettings({ ...settings, faqList: newFaq });
  };

  if (loading) {
    return <LoadingSpinner text="Retrieving platform settings..." />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
          <Settings className="w-5 h-5 text-amber-400" />
          <span>Website & UPI Payment Settings</span>
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Configure official UPI IDs, QR code payment parameters, contact handles, and website legal terms.
        </p>
      </div>

      {success && (
        <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>Settings saved and synchronized with Firestore!</span>
        </div>
      )}

      {settings && (
        <form onSubmit={handleSave} className="space-y-6">
          {/* UPI & Payment Credentials Card */}
          <div className="rounded-2xl border border-[#1E1E24] bg-[#0F1115] p-6 space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <QrCode className="w-4 h-4 text-amber-400" />
                <span>Admin Official UPI Gateway & QR Setup</span>
              </h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                ACTIVE GATEWAY
              </span>
            </div>

            <p className="text-xs text-slate-400">
              Set your real Admin UPI ID. Players on the website will scan this dynamic QR Code or copy this UPI ID to add money to their wallets.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Official Admin UPI ID / VPA *
                </label>
                <input
                  type="text"
                  required
                  value={settings.upiId}
                  onChange={(e) => setSettings({ ...settings, upiId: e.target.value.trim() })}
                  placeholder="e.g. wajidwajidkhan203@okhdfcbank"
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-sm text-amber-400 font-mono focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  UPI Account Holder Name *
                </label>
                <input
                  type="text"
                  required
                  value={settings.upiAccountHolder}
                  onChange={(e) => setSettings({ ...settings, upiAccountHolder: e.target.value })}
                  placeholder="e.g. FF Tournament Official / Wajid Khan"
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-sm text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            {/* Live QR Preview & Testing */}
            <div className="p-4 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] flex flex-col sm:flex-row items-center gap-4">
              <div className="bg-white p-2 rounded-xl shrink-0 shadow-md">
                <img
                  src={
                    settings.qrCodeUrl ||
                    `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(
                      `upi://pay?pa=${settings.upiId}&pn=${encodeURIComponent(
                        settings.upiAccountHolder || 'FF Tournament'
                      )}&cu=INR`
                    )}`
                  }
                  alt="Admin UPI QR"
                  className="w-28 h-28 object-contain"
                />
              </div>
              <div className="space-y-1.5 text-center sm:text-left">
                <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 text-[10px] font-bold">
                  <span>LIVE GENERATED PAYMENT QR</span>
                </div>
                <p className="text-xs font-bold text-white font-mono">{settings.upiId || 'No UPI ID set'}</p>
                <p className="text-[11px] text-slate-400">
                  Scanning this QR code automatically opens PhonePe, Google Pay, or Paytm with your Admin UPI ID prefilled.
                </p>
              </div>
            </div>

            {/* Deposit & Withdrawal Limits */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-2">
              <div>
                <label className="block text-[11px] font-semibold uppercase text-slate-400 mb-1">
                  Min Deposit (₹)
                </label>
                <input
                  type="number"
                  min={1}
                  value={settings.minDepositAmount ?? 20}
                  onChange={(e) => setSettings({ ...settings, minDepositAmount: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold uppercase text-slate-400 mb-1">
                  Max Deposit (₹)
                </label>
                <input
                  type="number"
                  min={100}
                  value={settings.maxDepositAmount ?? 10000}
                  onChange={(e) => setSettings({ ...settings, maxDepositAmount: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold uppercase text-slate-400 mb-1">
                  Min Withdrawal (₹)
                </label>
                <input
                  type="number"
                  min={1}
                  value={settings.minWithdrawAmount ?? 50}
                  onChange={(e) => setSettings({ ...settings, minWithdrawAmount: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold uppercase text-slate-400 mb-1">
                  Max Withdrawal (₹)
                </label>
                <input
                  type="number"
                  min={500}
                  value={settings.maxWithdrawAmount ?? 25000}
                  onChange={(e) => setSettings({ ...settings, maxWithdrawAmount: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-slate-400 mb-1 flex items-center justify-between">
                <span>Custom Static QR Code Image (Upload File or Enter URL)</span>
                {settings.qrCodeUrl && (
                  <button
                    type="button"
                    onClick={() => setSettings({ ...settings, qrCodeUrl: '' })}
                    className="text-[10px] text-amber-400 hover:underline font-bold cursor-pointer"
                  >
                    Reset to Live Dynamic QR
                  </button>
                )}
              </label>

              <div className="space-y-2">
                <div className="flex flex-col sm:flex-row items-center gap-2">
                  <label className="flex-1 w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] hover:border-amber-500/50 text-xs text-slate-300 flex items-center justify-between cursor-pointer transition">
                    <span>
                      {settings.qrCodeUrl
                        ? settings.qrCodeUrl.startsWith('data:')
                          ? '✅ Uploaded Custom QR Image (Base64)'
                          : settings.qrCodeUrl
                        : '📁 Choose QR Image File (PNG, JPG, WEBP)...'}
                    </span>
                    <span className="px-2 py-1 rounded bg-amber-500/10 text-amber-400 text-[10px] font-bold">
                      Upload QR
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        if (file.size > 5 * 1024 * 1024) {
                          alert('QR image file size exceeds 5MB limit.');
                          return;
                        }
                        const reader = new FileReader();
                        reader.onload = (ev) => {
                          if (ev.target?.result) {
                            setSettings({
                              ...settings,
                              qrCodeUrl: ev.target.result as string,
                            });
                          }
                        };
                        reader.readAsDataURL(file);
                      }}
                    />
                  </label>
                </div>

                <input
                  type="text"
                  value={settings.qrCodeUrl || ''}
                  onChange={(e) => setSettings({ ...settings, qrCodeUrl: e.target.value })}
                  placeholder="Or paste QR Image URL (leave blank to use auto-generated QR)"
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                Payment Verification Instructions
              </label>
              <textarea
                rows={3}
                value={settings.paymentInstructions}
                onChange={(e) => setSettings({ ...settings, paymentInstructions: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white"
              />
            </div>
          </div>

          {/* General Brand & Contacts */}
          <div className="rounded-2xl border border-[#1E1E24] bg-[#0F1115] p-6 space-y-4">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Phone className="w-4 h-4 text-amber-400" />
              <span>Brand Identity & Contact Support</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Website Name
                </label>
                <input
                  type="text"
                  required
                  value={settings.websiteName}
                  onChange={(e) => setSettings({ ...settings, websiteName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-sm text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Tagline
                </label>
                <input
                  type="text"
                  value={settings.tagline}
                  onChange={(e) => setSettings({ ...settings, tagline: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-sm text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Official Support Email
                </label>
                <input
                  type="email"
                  value={settings.contactGmail}
                  onChange={(e) => setSettings({ ...settings, contactGmail: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Instagram Handle
                </label>
                <input
                  type="text"
                  value={settings.instagramHandle}
                  onChange={(e) => setSettings({ ...settings, instagramHandle: e.target.value })}
                  placeholder="@wsk_khan_1010"
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  WhatsApp Support Number
                </label>
                <input
                  type="text"
                  value={settings.whatsAppNumber}
                  onChange={(e) => setSettings({ ...settings, whatsAppNumber: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Support Helpline Phone
                </label>
                <input
                  type="text"
                  value={settings.supportPhone}
                  onChange={(e) => setSettings({ ...settings, supportPhone: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white"
                />
              </div>
            </div>
          </div>

          {/* Legal Texts & FAQs */}
          <div className="rounded-2xl border border-[#1E1E24] bg-[#0F1115] p-6 space-y-4">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-400" />
              <span>Rules, About & FAQs</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  About Platform
                </label>
                <textarea
                  rows={4}
                  value={settings.aboutText}
                  onChange={(e) => setSettings({ ...settings, aboutText: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  General Tournament Rules
                </label>
                <textarea
                  rows={4}
                  value={settings.rulesText}
                  onChange={(e) => setSettings({ ...settings, rulesText: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] text-xs text-white"
                />
              </div>
            </div>

            {/* FAQs List */}
            <div className="space-y-3 pt-3 border-t border-[#1E1E24]">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wide">
                  Frequently Asked Questions ({settings.faqList?.length || 0})
                </span>
                <button
                  type="button"
                  onClick={handleAddFaq}
                  className="px-3 py-1 text-xs rounded-lg bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 border border-amber-500/20 flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add FAQ</span>
                </button>
              </div>

              {settings.faqList?.map((faq, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl bg-[#0A0A0B] border border-[#1E1E24] space-y-2 relative"
                >
                  <button
                    type="button"
                    onClick={() => handleRemoveFaq(idx)}
                    className="absolute right-3 top-3 text-rose-400 hover:text-rose-300 p-1 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                  <input
                    type="text"
                    placeholder="Question..."
                    value={faq.question}
                    onChange={(e) => handleFaqChange(idx, 'question', e.target.value)}
                    className="w-[90%] px-3 py-1.5 rounded-lg bg-[#0F1115] border border-[#1E1E24] text-xs text-white font-semibold"
                  />
                  <textarea
                    rows={2}
                    placeholder="Answer..."
                    value={faq.answer}
                    onChange={(e) => handleFaqChange(idx, 'answer', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-[#0F1115] border border-[#1E1E24] text-xs text-slate-300"
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow-lg shadow-amber-500/20 flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Saving...' : 'Save Settings'}</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
