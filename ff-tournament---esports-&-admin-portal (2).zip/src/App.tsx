import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Sidebar } from './components/Sidebar';
import { Navbar } from './components/Navbar';
import { ActiveTab } from './types';

// Player Website & Admin Views
import { PlayerTournamentWebsite } from './views/PlayerTournamentWebsite';
import { AdminLoginView } from './views/AdminLoginView';
import { DashboardView } from './views/DashboardView';
import { TournamentsView } from './views/TournamentsView';
import { MatchesView } from './views/MatchesView';
import { RegistrationsView } from './views/RegistrationsView';
import { PaymentsView } from './views/PaymentsView';
import { WalletView } from './views/WalletView';
import { DepositsView } from './views/DepositsView';
import { WithdrawalsView } from './views/WithdrawalsView';
import { TransactionsView } from './views/TransactionsView';
import { RoomsView } from './views/RoomsView';
import { LeaderboardView } from './views/LeaderboardView';
import { ResultsView } from './views/ResultsView';
import { UsersView } from './views/UsersView';
import { CouponsView } from './views/CouponsView';
import { ReferralsView } from './views/ReferralsView';
import { BannersView } from './views/BannersView';
import { NotificationsView } from './views/NotificationsView';
import { SupportView } from './views/SupportView';
import { HomepageView } from './views/HomepageView';
import { SettingsView } from './views/SettingsView';
import { ReportsView } from './views/ReportsView';
import { LogsView } from './views/LogsView';
import { AdminsView } from './views/AdminsView';
import { AdminMasterMenuModal } from './components/AdminMasterMenuModal';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ArrowLeft, Globe, Grid } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { currentUser, isSuperAdmin, role, loading } = useAuth();
  const [viewMode, setViewMode] = useState<'player_website' | 'admin_panel' | 'admin_login'>('player_website');
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState<boolean>(false);
  const [isMasterMenuOpen, setIsMasterMenuOpen] = useState<boolean>(false);

  // Auto detect referral query parameter in URL (e.g., ?ref=FF123 or ?referral=FF123)
  React.useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const refCode = params.get('ref') || params.get('referral') || params.get('code');
      if (refCode && refCode.trim()) {
        const clean = refCode.trim().toUpperCase();
        localStorage.setItem('ff_pending_ref_code', clean);
      }
    } catch (e) {
      console.warn('URL referral check warning:', e);
    }
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-[#0A0A0B]">
        <LoadingSpinner text="Connecting to FF Tournament Firebase Server..." size="lg" />
      </div>
    );
  }

  // 1. If currently in Player Tournament Website Mode (Default view for visitors/players)
  if (viewMode === 'player_website') {
    return (
      <PlayerTournamentWebsite
        onOpenAdminPanel={() => {
          if (currentUser && (isSuperAdmin || role === 'SUPER_ADMIN' || role === 'TOURNAMENT_ADMIN')) {
            setViewMode('admin_panel');
          } else {
            setViewMode('admin_login');
          }
        }}
      />
    );
  }

  // 2. If Admin Login requested but not authenticated as admin
  if (viewMode === 'admin_login' && (!currentUser || (role !== 'SUPER_ADMIN' && role !== 'TOURNAMENT_ADMIN' && !isSuperAdmin))) {
    return (
      <AdminLoginView
        onBackToWebsite={() => setViewMode('player_website')}
      />
    );
  }

  // Render the currently selected tab component inside Admin Panel
  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView onNavigate={(tab) => setActiveTab(tab)} />;
      case 'tournaments':
        return <TournamentsView />;
      case 'matches':
        return <MatchesView />;
      case 'registrations':
        return <RegistrationsView />;
      case 'payments':
        return <PaymentsView />;
      case 'wallet':
        return <WalletView />;
      case 'deposits':
        return <DepositsView />;
      case 'withdrawals':
        return <WithdrawalsView />;
      case 'transactions':
        return <TransactionsView />;
      case 'rooms':
        return <RoomsView />;
      case 'leaderboard':
        return <LeaderboardView />;
      case 'results':
        return <ResultsView />;
      case 'users':
        return <UsersView />;
      case 'coupons':
        return <CouponsView />;
      case 'referrals':
        return <ReferralsView />;
      case 'banners':
        return <BannersView />;
      case 'notifications':
        return <NotificationsView />;
      case 'support':
        return <SupportView />;
      case 'homepage':
        return <HomepageView />;
      case 'settings':
        return <SettingsView />;
      case 'reports':
        return <ReportsView />;
      case 'logs':
        return <LogsView />;
      case 'admins':
        return <AdminsView />;
      default:
        return <DashboardView onNavigate={(tab) => setActiveTab(tab)} />;
    }
  };

  // 3. Full Production Admin Panel
  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#0A0A0B] text-slate-200">
      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isMobileOpen={isMobileSidebarOpen}
        setIsMobileOpen={setIsMobileSidebarOpen}
        onOpenMasterMenu={() => setIsMasterMenuOpen(true)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Switcher Banner to return to Player Website */}
        <div className="bg-gradient-to-r from-amber-600/20 via-zinc-900 to-zinc-950 border-b border-zinc-800/80 px-4 py-2 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-amber-300 font-bold">
            <span className="text-sm">🌐</span>
            <span>ADMIN MODE ACTIVE</span>
            <span className="text-[10px] text-zinc-400 font-normal hidden sm:inline">
              — All actions modify live Firestore database
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              id="btn-open-master-menu-topbar"
              onClick={() => setIsMasterMenuOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black transition cursor-pointer shadow-md shadow-amber-500/20"
            >
              <Grid className="w-3.5 h-3.5" />
              <span>All Admin Menu (24 Modules)</span>
            </button>
            <button
              id="btn-switch-to-player-view"
              onClick={() => setViewMode('player_website')}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white font-bold transition cursor-pointer hover:border-amber-500/40"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Switch to Tournament Website</span>
            </button>
          </div>
        </div>

        {/* Top Navbar */}
        <Navbar
          onToggleMobileMenu={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
          onOpenMasterMenu={() => setIsMasterMenuOpen(true)}
        />

        {/* Scrollable Workspace */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto pb-12">
            {renderActiveView()}
          </div>
        </main>
      </div>

      {/* Admin Master Menu & Complete Feature Controller Modal */}
      <AdminMasterMenuModal
        isOpen={isMasterMenuOpen}
        onClose={() => setIsMasterMenuOpen(false)}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          setIsMasterMenuOpen(false);
        }}
        activeTab={activeTab}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainAppContent />
    </AuthProvider>
  );
}

