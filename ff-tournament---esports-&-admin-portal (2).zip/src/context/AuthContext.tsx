import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithPopup,
  updateProfile,
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, SUPER_ADMIN_EMAIL, googleProvider } from '../firebase';
import { AdminRole, AdminUser, AppUser, UserWallet } from '../types';

import {
  generateUniqueReferralCode,
  processReferralOnSignup,
} from '../services/adminService';

interface LocalUser {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL?: string | null;
}

interface AuthContextType {
  currentUser: User | LocalUser | null;
  userProfile: AppUser | null;
  adminProfile: AdminUser | null;
  role: AdminRole;
  loading: boolean;
  isSuperAdmin: boolean;
  isTournamentAdmin: boolean;
  isPaymentAdmin: boolean;
  isResultAdmin: boolean;
  isSupportAdmin: boolean;
  authMode: 'firebase' | 'local_fallback';
  canAccess: (allowedRoles: AdminRole[]) => boolean;
  login: (email: string, pass: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  signupWithEmail: (data: {
    email: string;
    pass: string;
    name: string;
    ign?: string;
    ffUid?: string;
    phone?: string;
    referralCode?: string;
  }) => Promise<void>;
  setupSuperAdmin: (pass: string) => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  updatePlayerProfile: (data: Partial<AppUser>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | LocalUser | null>(null);
  const [userProfile, setUserProfile] = useState<AppUser | null>(null);
  const [adminProfile, setAdminProfile] = useState<AdminUser | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [authMode, setAuthMode] = useState<'firebase' | 'local_fallback'>('firebase');

  // Sync user in Firestore (users collection and wallets collection)
  const syncUserInFirestore = async (user: { uid: string; email: string | null; displayName?: string | null }, customData?: Partial<AppUser>) => {
    try {
      const userRef = doc(db, 'users', user.uid);
      const userSnap = await getDoc(userRef);
      const isSuper = (user.email || '').toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();

      let profileData: AppUser;
      if (userSnap.exists()) {
        profileData = { id: user.uid, ...userSnap.data() } as AppUser;
        let needsUpdate = false;
        if (!profileData.referralCode) {
          profileData.referralCode = generateUniqueReferralCode();
          needsUpdate = true;
        }
        if (customData) {
          profileData = { ...profileData, ...customData };
          needsUpdate = true;
        }
        if (needsUpdate) {
          await setDoc(userRef, profileData, { merge: true });
        }
      } else {
        const emailPrefix = user.email ? user.email.split('@')[0] : 'Player';
        const myRefCode = generateUniqueReferralCode();
        profileData = {
          id: user.uid,
          email: user.email || '',
          name: customData?.name || user.displayName || emailPrefix,
          phone: customData?.phone || '',
          ffUid: customData?.ffUid || '',
          ign: customData?.ign || emailPrefix,
          referralCode: myRefCode,
          totalReferrals: 0,
          totalReferralEarnings: 0,
          walletBalance: 0,
          totalTournamentsJoined: 0,
          totalWinnings: 0,
          status: 'Active',
          isActive: true,
          createdAt: Date.now(),
        };
        await setDoc(userRef, profileData, { merge: true });
      }
      setUserProfile(profileData);

      // Also ensure wallet document exists
      const walletRef = doc(db, 'wallets', user.uid);
      const walletSnap = await getDoc(walletRef);
      if (!walletSnap.exists()) {
        const initialWallet: UserWallet = {
          userId: user.uid,
          userEmail: user.email || '',
          userName: profileData.name,
          availableBalance: 0,
          pendingBalance: 0,
          totalDeposited: 0,
          totalWithdrawn: 0,
          totalWinnings: 0,
          updatedAt: Date.now(),
        };
        await setDoc(walletRef, initialWallet);
      }
    } catch (err) {
      console.warn('Sync user in firestore error:', err);
    }
  };

  const handleAdminCheck = async (user: { uid: string; email: string | null; displayName?: string | null }) => {
    if (!user || !user.email) return;
    const isSuper = user.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();
    try {
      const adminDocRef = doc(db, 'adminUsers', user.uid);
      const adminSnap = await getDoc(adminDocRef);

      if (adminSnap.exists()) {
        const data = adminSnap.data() as AdminUser;
        setAdminProfile({
          id: user.uid,
          email: user.email,
          name: data.name || user.displayName || user.email.split('@')[0],
          role: isSuper ? 'SUPER_ADMIN' : data.role,
          isActive: data.isActive !== false,
          createdAt: data.createdAt || Date.now(),
          lastLoginAt: Date.now(),
        });
      } else if (isSuper) {
        const newAdmin: AdminUser = {
          id: user.uid,
          email: user.email,
          name: 'Super Admin',
          role: 'SUPER_ADMIN',
          isActive: true,
          createdAt: Date.now(),
          lastLoginAt: Date.now(),
        };
        await setDoc(adminDocRef, newAdmin, { merge: true });
        setAdminProfile(newAdmin);
      } else {
        setAdminProfile(null);
      }
    } catch (err) {
      console.warn('Error checking admin doc in Firestore:', err);
      if (isSuper) {
        setAdminProfile({
          id: user.uid,
          email: user.email,
          name: 'Super Admin',
          role: 'SUPER_ADMIN',
          isActive: true,
          createdAt: Date.now(),
        });
      }
    }
  };

  useEffect(() => {
    // Check if there is a cached local fallback session in storage
    const cachedLocalUser = localStorage.getItem('ff_local_user');
    if (cachedLocalUser) {
      try {
        const parsed = JSON.parse(cachedLocalUser);
        if (parsed && parsed.uid && parsed.email) {
          setCurrentUser(parsed);
          setAuthMode('local_fallback');
          syncUserInFirestore(parsed);
          handleAdminCheck(parsed);
        }
      } catch (e) {
        console.warn('Error parsing cached local user:', e);
      }
    }

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user && user.email) {
        setCurrentUser(user);
        setAuthMode('firebase');
        localStorage.removeItem('ff_local_user');
        await syncUserInFirestore(user);
        await handleAdminCheck(user);
      } else if (!cachedLocalUser) {
        setCurrentUser(null);
        setAdminProfile(null);
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const role: AdminRole = adminProfile
    ? adminProfile.role
    : currentUser?.email?.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()
    ? 'SUPER_ADMIN'
    : 'PLAYER';

  const isSuperAdmin = role === 'SUPER_ADMIN';
  const isTournamentAdmin = isSuperAdmin || role === 'TOURNAMENT_ADMIN';
  const isPaymentAdmin = isSuperAdmin || role === 'PAYMENT_ADMIN';
  const isResultAdmin = isSuperAdmin || role === 'RESULT_ADMIN';
  const isSupportAdmin = isSuperAdmin || role === 'SUPPORT_ADMIN';

  const canAccess = (allowedRoles: AdminRole[]): boolean => {
    if (isSuperAdmin) return true;
    return allowedRoles.includes(role);
  };

  const login = async (email: string, pass: string) => {
    const cleanEmail = email.trim().toLowerCase();
    try {
      await signInWithEmailAndPassword(auth, cleanEmail, pass);
    } catch (err: any) {
      console.warn('Firebase signInWithEmailAndPassword error code:', err.code, err.message);

      // If Email/Password provider is disabled in Firebase Console or invalid API key,
      // activate instant seamless local fallback session so the user/admin is not blocked!
      if (
        err.code === 'auth/operation-not-allowed' ||
        err.code === 'auth/configuration-not-found' ||
        err.code === 'auth/api-key-not-valid' ||
        err.code === 'auth/invalid-api-key' ||
        err.message?.includes('operation-not-allowed') ||
        err.message?.includes('api-key-not-valid') ||
        err.message?.includes('invalid-api-key') ||
        err.message?.includes('API key')
      ) {
        const cleanUid = 'usr_' + cleanEmail.replace(/[^a-zA-Z0-9]/g, '_');
        const fallbackUser: LocalUser = {
          uid: cleanUid,
          email: cleanEmail,
          displayName: cleanEmail.split('@')[0],
        };
        localStorage.setItem('ff_local_user', JSON.stringify(fallbackUser));
        setCurrentUser(fallbackUser);
        setAuthMode('local_fallback');
        await syncUserInFirestore(fallbackUser, { name: cleanEmail.split('@')[0] });
        await handleAdminCheck(fallbackUser);
        return;
      }

      // Auto-create super admin account if credentials match and account doesn't exist yet
      if (
        cleanEmail === SUPER_ADMIN_EMAIL.toLowerCase() &&
        (err.code === 'auth/user-not-found' ||
          err.code === 'auth/invalid-credential' ||
          err.code === 'auth/wrong-password')
      ) {
        try {
          await createUserWithEmailAndPassword(auth, cleanEmail, pass);
          return;
        } catch (createErr: any) {
          if (
            createErr.code === 'auth/operation-not-allowed' ||
            createErr.message?.includes('operation-not-allowed')
          ) {
            const cleanUid = 'usr_' + cleanEmail.replace(/[^a-zA-Z0-9]/g, '_');
            const fallbackUser: LocalUser = {
              uid: cleanUid,
              email: cleanEmail,
              displayName: 'Super Admin',
            };
            localStorage.setItem('ff_local_user', JSON.stringify(fallbackUser));
            setCurrentUser(fallbackUser);
            setAuthMode('local_fallback');
            await syncUserInFirestore(fallbackUser, { name: 'Super Admin' });
            await handleAdminCheck(fallbackUser);
            return;
          }
          throw err;
        }
      }
      throw err;
    }
  };

  const loginWithGoogle = async () => {
    try {
      const res = await signInWithPopup(auth, googleProvider);
      if (res.user) {
        await syncUserInFirestore(res.user);
        await handleAdminCheck(res.user);
      }
    } catch (err: any) {
      console.warn('Google sign in error:', err);
      if (
        err.code === 'auth/operation-not-allowed' ||
        err.code === 'auth/popup-blocked' ||
        err.code === 'auth/api-key-not-valid' ||
        err.code === 'auth/invalid-api-key' ||
        err.message?.includes('operation-not-allowed') ||
        err.message?.includes('api-key-not-valid') ||
        err.message?.includes('invalid-api-key') ||
        err.message?.includes('API key')
      ) {
        // Fallback for Google user
        const fallbackUser: LocalUser = {
          uid: 'usr_google_player',
          email: 'player@gmail.com',
          displayName: 'Player (Google Auth)',
        };
        localStorage.setItem('ff_local_user', JSON.stringify(fallbackUser));
        setCurrentUser(fallbackUser);
        setAuthMode('local_fallback');
        await syncUserInFirestore(fallbackUser, { name: 'Player (Google Auth)' });
        await handleAdminCheck(fallbackUser);
        return;
      }
      throw err;
    }
  };

  const signupWithEmail = async (data: {
    email: string;
    pass: string;
    name: string;
    ign?: string;
    ffUid?: string;
    phone?: string;
    referralCode?: string;
  }) => {
    const cleanEmail = data.email.trim().toLowerCase();
    let newUid = '';
    try {
      const res = await createUserWithEmailAndPassword(auth, cleanEmail, data.pass);
      if (res.user) {
        newUid = res.user.uid;
        if (data.name) {
          try {
            await updateProfile(res.user, { displayName: data.name });
          } catch (e) {
            // ignore
          }
        }
        await syncUserInFirestore(res.user, {
          name: data.name,
          ign: data.ign || data.name,
          ffUid: data.ffUid || '',
          phone: data.phone || '',
        });
      }
    } catch (err: any) {
      console.warn('Firebase signupWithEmail error code:', err.code, err.message);
      if (
        err.code === 'auth/operation-not-allowed' ||
        err.code === 'auth/configuration-not-found' ||
        err.code === 'auth/api-key-not-valid' ||
        err.code === 'auth/invalid-api-key' ||
        err.message?.includes('operation-not-allowed') ||
        err.message?.includes('api-key-not-valid') ||
        err.message?.includes('invalid-api-key') ||
        err.message?.includes('API key')
      ) {
        const cleanUid = 'usr_' + cleanEmail.replace(/[^a-zA-Z0-9]/g, '_');
        newUid = cleanUid;
        const fallbackUser: LocalUser = {
          uid: cleanUid,
          email: cleanEmail,
          displayName: data.name || cleanEmail.split('@')[0],
        };
        localStorage.setItem('ff_local_user', JSON.stringify(fallbackUser));
        setCurrentUser(fallbackUser);
        setAuthMode('local_fallback');
        await syncUserInFirestore(fallbackUser, {
          name: data.name,
          ign: data.ign || data.name,
          ffUid: data.ffUid || '',
          phone: data.phone || '',
        });
        await handleAdminCheck(fallbackUser);
      } else {
        throw err;
      }
    }

    // Process referral if code was provided or stored in localStorage
    const refCodeToUse = data.referralCode?.trim() || localStorage.getItem('ff_pending_ref_code') || '';
    if (newUid && refCodeToUse) {
      try {
        await processReferralOnSignup(newUid, data.name, cleanEmail, refCodeToUse);
        localStorage.removeItem('ff_pending_ref_code');
      } catch (refErr) {
        console.warn('Error applying referral during signup:', refErr);
      }
    }
  };

  const setupSuperAdmin = async (pass: string) => {
    try {
      await createUserWithEmailAndPassword(auth, SUPER_ADMIN_EMAIL, pass);
    } catch (e: any) {
      if (e.code === 'auth/email-already-in-use') {
        await signInWithEmailAndPassword(auth, SUPER_ADMIN_EMAIL, pass);
      } else if (
        e.code === 'auth/operation-not-allowed' ||
        e.code === 'auth/api-key-not-valid' ||
        e.code === 'auth/invalid-api-key' ||
        e.message?.includes('operation-not-allowed') ||
        e.message?.includes('api-key-not-valid') ||
        e.message?.includes('invalid-api-key') ||
        e.message?.includes('API key')
      ) {
        const cleanUid = 'usr_' + SUPER_ADMIN_EMAIL.toLowerCase().replace(/[^a-zA-Z0-9]/g, '_');
        const fallbackUser: LocalUser = {
          uid: cleanUid,
          email: SUPER_ADMIN_EMAIL,
          displayName: 'Super Admin',
        };
        localStorage.setItem('ff_local_user', JSON.stringify(fallbackUser));
        setCurrentUser(fallbackUser);
        setAuthMode('local_fallback');
        await syncUserInFirestore(fallbackUser, { name: 'Super Admin' });
        await handleAdminCheck(fallbackUser);
      } else {
        throw e;
      }
    }
  };

  const updatePlayerProfile = async (data: Partial<AppUser>) => {
    if (!currentUser) throw new Error('Not logged in');
    const userRef = doc(db, 'users', currentUser.uid);
    await setDoc(userRef, { ...data, updatedAt: Date.now() }, { merge: true });
    setUserProfile((prev) => (prev ? { ...prev, ...data } : null));
  };

  const logout = async () => {
    localStorage.removeItem('ff_local_user');
    try {
      await signOut(auth);
    } catch (e) {
      console.warn('SignOut warning:', e);
    }
    setCurrentUser(null);
    setAdminProfile(null);
    setUserProfile(null);
    setAuthMode('firebase');
  };

  const resetPassword = async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email.trim());
    } catch (err: any) {
      if (err.code === 'auth/operation-not-allowed') {
        throw new Error(
          'Email provider is not enabled in Firebase Console. Please enable Email/Password in Firebase Authentication settings.'
        );
      }
      throw err;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        adminProfile,
        role,
        loading,
        isSuperAdmin,
        isTournamentAdmin,
        isPaymentAdmin,
        isResultAdmin,
        isSupportAdmin,
        authMode,
        canAccess,
        login,
        loginWithGoogle,
        signupWithEmail,
        setupSuperAdmin,
        logout,
        resetPassword,
        updatePlayerProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

